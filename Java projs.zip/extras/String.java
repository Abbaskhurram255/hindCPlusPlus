class lafz {
	String str;
	lafz(Object... objs) {
		for (Object o : objs) this.str = ""+o;
		trim();
	}
	lafz(Object o) {
		this.str = ""+o;
		trim();
	}
	public lafz sentCase() {
		this.str = (str.toUpperCase().substring(0, 1)
				 + str.toLowerCase().substring(1))
				.replaceAll("(?<!\\w)i(?!\\w)", "I");
		return this;
	}
	public String titleCase() {
		StringBuilder titleCased = new StringBuilder(str.length());
		boolean nextTitleCase = true;
		for (char c : str.toCharArray()) {
			if (Character.isSpaceChar(c)) {
				nextTitleCase = true;
			} else if (nextTitleCase) {
				c = Character.toTitleCase(c);
				nextTitleCase = false;
			}
			titleCased.append(c);
		}
		return titleCased.toString();
	}
	public lafz reverse() {
		this.str = new StringBuilder(str).reverse().toString();
		return this;
	}
	public int length() {
		return str.trim().length();
	}
	public int len() {
		return length();
	}
	public int size() {
		return length();
	}
	public int length = length();
	public int len = length();
	public int size = length();
	public String trim() {
		return str.trim();
	}
	public String toString() {
		return str;
	}
}


public class Main {
	public static lafz lafz(Object o) {
	    return new lafz(o);
    }
	public static void main(String[] args) {
		lafz salaam = lafz("hi");
		System.out.println(salaam.sentCase());
	}
}