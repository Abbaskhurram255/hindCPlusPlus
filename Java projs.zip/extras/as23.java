public class Employee {
    String name, address, phoneNumber;
    int age;
    char grade;
    
    Employee() {
        this.name = "Asia Basit";
        this.age = 27;
        this.phoneNumber = "+923037046918";
        this.address = "House #508, Muzaffar Lane, Landhi Town, Sindh 70082";
    }
    
    Employee(String name, int age, String phoneNumber, String address) {
        this.name = name;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }
    
    String isSenior() {
        return this.age > 50 ? "This employee is a senior" : "nope, a junior";
    }
    
    void displayDetails() {
        System.out.println("----------\nEmployee Name: "+this.name+"\nEmployee Age: "+this.age+"\nEmployee Phone Number: "+this.phoneNumber+"\nEmployee Address: "+this.address+"\nIs a senior: "+this.isSenior());
    }
}

class Main {
	public static void main(String[] args) {
		Employee employee1 = new Employee();
		Employee employee2 = new Employee("Kashif Ali", 62, "+923418955472", "Gulshan-e-Hadeed, Sindh 70050, Pakistan");
		employee1
		.displayDetails();
		employee2
		.displayDetails();
	}
}
/*
Documentation
1. The no-argument constructor initializes a new instance of the Employee class with the default parameters
2. The parametrized constructor here, differs in the way that it creates a new instance WITH YOUR OWN employee data. However, beware, it throws an error if only some of the parameters are passed, and not all of them
3. You'll likely be fronted with an error, if you missed any of the construction parameter fields while creating a new instance of the Employee class
4. Modify? You wouldn't need to, as long as the instances have unique variable names and there's no naming overlap/conflict. The  correct usage would be: employee1 for employee A, employee2 for employee B, like so.
5. 
  A. You would need to add a new variable to the Employee class, and that right after the initialization of (char)variable grade
  B. Further, add a new parameter to the constructor, and with that done, and `this.$newAttribute = $parameterName` to the end of the constructor. Make sure there are no type or naming conflicts.
  C. Pass that new parameter to all the present, and future instances of the Employee class
*/