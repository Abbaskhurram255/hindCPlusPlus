import java.util.*;

public class Dater {
    public String nthDay(int n) {
        String days[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        return days[n];
    }
    public String nthMonth(int n) {
        String months[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        return months[n];
    }
    public String formattedDate(Date dt) {
    	int dayOfWeek = dt.getDay(), monthOfYear = dt.getMonth();
        String day, month;
        String date = dt.toLocaleString();
        String ampm = date.substring(date.length() - 2);
        date = date.substring(0, date.length() - 6) + " " + ampm;
        month = nthMonth(monthOfYear);
        date = month + " " + date.substring(4);
        day = nthDay(dayOfWeek);
        date = day + ", " + date;
        return date;
    }
    public String now() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*(3600*1000))); //fix 5-hour bug
        String date = formattedDate(dt);
        return date;
    }
    public String getDate() {
      String parts[] = now().split(", ");
      return parts[1] + ", " + parts[2];
    }
    public String getDay() {
      return now().split(", ")[0];
    }
    public String getMonth() {
      return now().split(", ")[1].split(" ")[0];
    }
    public String getYear() {
      return now().split(", ")[2];
    }
    public String getTime() {
      return now().split(", ")[3];
    }
    public String yesterday() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime()-((int)36e5*24)); //decrement 24 hours or (3.6*10⁶)*24 milliseconds
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String dayBeforeYesterday() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime()-((int)72e5*24)); //decrement 48 hours or (7.2*10⁶)*24 milliseconds
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String twoDaysAgo() {
    	return new Dater().dayBeforeYesterday();
    }
    public String tomorrow() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)(36e2*1e3)))); //fix 5-hour bug
        dt.setTime(dt.getTime()+((int)36e5*24)); //increment 24 hours or (3.6*10⁶)*24 milliseconds
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String dayAfterTomorrow() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime()+((int)72e5*24)); //increment 48 hours or (7.2*10⁶)*24 milliseconds
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String twoDaysLater() {
    	return new Dater().dayAfterTomorrow();
    }
    public String lastMonth() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setMonth(dt.getMonth()-1); //decrement a month
        String date = formattedDate(dt);
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String lastMonthOf(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setMonth(dt.getMonth()-1); //decrement a month
        date = formattedDate(dt);
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String nextMonth() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setMonth(dt.getMonth()+1); //increment a month
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String nextMonthOf(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setMonth(dt.getMonth()+1); //increment a month
        date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String lastYear() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setYear(dt.getYear()-1); //decrement a year
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = date.split(", ")[2];
        return date;
    }
    public String lastYearOf(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setYear(dt.getYear()-1); //decrement a year
        date = formattedDate(dt);
        date = date.split(", ")[2];
        return date;
    }
    public String nextYear() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setYear(dt.getYear()+1); //increment a year
        String date = formattedDate(dt);
        date = date.split(", ")[2];
        return date;
    }
    public String nextYearOf(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setYear(dt.getYear()+1); //increment a year
        date = formattedDate(dt);
        date = date.split(", ")[2];
        return date;
    }
    public String age2bday(int age) {
        Date dt = new Date();
        //dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        String bday = ""+((dt.getYear()+1900) - age); //adding 1900 helps resolve a bug
        return bday;
    }
    public int bday2age(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        int age = new Date().getYear() - dt.getYear();
        return age;
    }
    public String date2day(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        date = formattedDate(dt);
        date = date.split(", ")[0];
        return date;
    }
    public String date2month(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        date = formattedDate(dt);
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String timeGreet() {
    	String greeting;
    	int h = new Date().getHours() + 5; //fix 5-hour bug along the way
        if (h >= 20) greeting = "Good night";
        else if (h >= 16) greeting = "Good evening";
        else if (h >= 12) greeting = "Good afternoon";
        else if (h >= 0 && h <= 4) greeting = "Good new day";
        else greeting = "Good morning";
        return greeting;
    }
    public String lastOfMonth(int m) {
        Date dt = new Date();
        Dater dt2 = new Dater();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug for better accuracy
        String result = ""+(""+dt2.nthMonth(m-1) + " " + new Date(new Date().getYear(), m, 0).getDate());
        return result;
    }
    public boolean isWeekend() {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
    	return dt.getDay() % 6 == 0;
    }
    public boolean isLeapYear() {
    	return (1900 + new Date().getYear()) % 4 == 0;
    }
    public int nextLeapYear() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug for better accuracy
        int i = 0;
        if (dt.getYear() % 4 == 0) dt.setYear(dt.getYear() + 1); //ignore current year, if it's leap
        while (dt.getYear() % 4 != 0) {
            dt.setYear((dt.getYear()) + i);
            i++;
        }
        int result = (1900+dt.getYear()); //comes with a bug fix
        return result;
    }
    public String before(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setDate(dt.getDate() - Math.abs(n));
        String date = new Dater().formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String minus(int n) {
    	return new Dater().before(n);
    }
    public String after(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setDate(dt.getDate() + Math.abs(n));
        String date = new Dater().formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String add(int n) {
    	return new Dater().after(n);
    }
    public String minsAgo(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime() - (n * (int)60e3));
        String time = new Dater().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String minsLater(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime() + (n * (int)60e3));
        String time = new Dater().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String hoursAgo(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //first fix the 5-hour bug
        dt.setTime(dt.getTime() - (n * (int)36e5));
        String time = new Dater().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String hoursLater(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //first fix the 5-hour bug
        dt.setTime(dt.getTime() + (n * (int)36e5));
        String time = new Dater().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String nthHour(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime() - (int)36e5 * dt.getHours() + (n * (int)36e5));
        String time = new Dater().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String Dater() {
    	return new Dater().now();
    }
    public static void main(String args[]) {
        Dater date = new Dater();
        System.out.println("\nNow: " + date.now());
        System.out.println("\nDate: " + date.getDate());
        System.out.println("\nDay: " + date.getDay());
        System.out.println("\nMonth: " + date.getMonth());
        System.out.println("\nYear: " + date.getYear());
        System.out.println("\nTime: " + date.getTime());
        System.out.println("---------\n\nYesterday: " + date.yesterday());
        System.out.println("\nDay before yesterday: " + date.twoDaysAgo());
        System.out.println("\nTomorrow: " + date.tomorrow());
        System.out.println("\nDay after tomorrow: " + date.dayAfterTomorrow());
        System.out.println("\nDate 2 Day <where input=\"Jan 24 2002\">: " + date.date2day("Jan 24 2002"));
        System.out.println("\nDate 2 Month <where input=\"01/24/2002\">: " + date.date2month("01/24/2002"));
        System.out.println("\nLast Month: " + date.lastMonth());
        System.out.println("\nNext Month: " + date.nextMonth());
        System.out.println("\nLast Year: " + date.lastYear());
        System.out.println("\nNext Year: " + date.nextYear());
        System.out.println("\nNext Leap Year: " + date.nextLeapYear());
        System.out.println("\nLast Month <of input=\"Jan 24 2002\">: " + date.lastMonthOf("Jan 24 2002"));
        System.out.println("\nNext Month <of input=\"Jan 24 2002\">: " + date.nextMonthOf("Jan 24 2002"));
        System.out.println("\nLast Year <of input=\"Jan 24 2002\">: " + date.lastYearOf("Jan 24 2002"));
        System.out.println("\nNext Year <of input=\"Jan 24 2002\">: " + date.nextYearOf("Jan 24 2002"));
        System.out.println("\nBday 2 Age <where input=\"Jan 24 2002\">: " + date.bday2age("Jan 24 2002"));
        System.out.println("\nAge 2 Bday <where input=23>: " + date.age2bday(23));
        System.out.println("\nLast of month <where input=2>: " + date.lastOfMonth(2));
        System.out.println("\nIs Weekend: " + (date.isWeekend() ? "yes" : "no"));
        System.out.println("\nIs Leap year: " + (date.isLeapYear() ? "yes" : "no <next Feb 29 will be seen in " + date.nextLeapYear() + ">"));
        System.out.println("\nDate n days ago <where n=5>: " + date.before(5));
        System.out.println("\nDate n days later <where n=5>: " + date.after(5));
        System.out.println("\n><><><><><><><><><");
        System.out.println("\nTime greet: " + date.timeGreet());
        System.out.println("\nMins ago <where n=5>: " + date.minsAgo(5));
        System.out.println("\nMins later <where n=5>: " + date.minsLater(5));
        System.out.println("\nHours ago <where n=5>: " + date.hoursAgo(5));
        System.out.println("\nHours later <where n=5>: " + date.hoursLater(5));
        System.out.println("\nNth hour <where n=5>: " + date.nthHour(5));
        
    }
}