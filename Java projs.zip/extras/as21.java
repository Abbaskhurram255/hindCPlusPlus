public class Student {
    String name, address;
    int rollNumber;
    char grade;
    
    Student(String name, int rollNumber, char grade, String address) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.grade = grade;
        this.address = address;
    }
    
    void displayDetails() {
        System.out.println("Student Name: "+this.name+"\nRoll Number: "+this.rollNumber+"\nGrade: "+this.grade+"\nAddress: "+this.address);
    }
}

class MainClass {
	public static void main(String[] args) {
		Student student1 = new Student("Kashif Ali", 62, 'A', "Gulshan-e-Hadeed, Sindh 70050, Pakistan");
		student1
		.displayDetails();
	}
}
/*
Documentation
1. The student class in this program is used to store student data like their enrollment number, the grade they got, where they live, among other things
2. The displayDetails method in this program helps display an organized copy of the student data
3. You'd obviously be fronted with an error, if you missed any of the construction fields while creating a new instance of the Student class
4. Modify? You wouldn't need to, as long as the instances have unique variable names and there's no naming overlap/conflict, like student1 for student A, student2 for student B, like so.
5. 
  A. You would need to add a new variable to the Student class, and that right after the initialization of (char)variable grade
  B. Further, add a new parameter to the constructor, and with that done, and `this.$newAttribute = $parameterName` to the end of the constructor. Make sure there are no type or naming conflicts.
  C. Pass that new parameter to all the present, and future instances of the Student class
*/