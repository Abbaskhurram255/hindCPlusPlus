public class Main {
	public static void main(String args[]) {
		Student student1 = new Student("Ayesha Mehnaaz", 16, 2530144, 'A', "BBSUL Chakiwara");
		System.out.println("Name: " + student1.name + "\nBatch: " + student1.batch + "\nRoll: B" + student1.getRoll() + "\nSection: " + student1.getSection() + "\nCampus: " + student1.getCampus());
	}
}

class Student {
	String name, campus;
	char section;
	int batch, roll;
	
	Student(String name, int batch, int roll, char section, String campus) {
		this.name = name;
		this.batch = batch;
		this.roll = roll;
		this.section = section;
		this.campus = campus;
	}

	String getName() {
		return this.name;
	}
	void setName(String name) {
		this.name = name;
	}

	int getBatch() {
		return this.batch;
	}
	void setBatch(int batch) {
		this.batch = batch;
	}

	int getRoll() {
		return this.roll;
	}
	void setRoll(int roll) {
		this.roll = roll;
	}

	char getSection() {
		return this.section;
	}
	void setSection(char section) {
		this.section = section;
	}
	String getCampus() {
		return this.campus;
	}
	void setCampus(String campus) {
		this.campus = campus;
	}
}