public class Book {
    String title, author;
    int yearPublished;
    double price;
    
    Book(String title, String author, int price, int yearPublished) {
        this.title = title;
        this.author = author;
        this.price = price;
        this.yearPublished = yearPublished;
    }
    
    void applyDiscount(double n) {
        double discount = this.price*n/100;
        this.price -= discount;
        System.out.println("As per the request, PKR " + discount + " have been discounted");
    }
    
    
    void displayDetails() {
        System.out.println("Book Title: "+this.title+"\nAuthor: "+this.author+"\nPrice: PKR "+this.price+"\nYear Published: "+this.yearPublished);
    }
}

class MainClass {
	public static void main(String[] args) {
		Book book1 = new Book("The Subtle Art", "Mark Manson", 1100, 2007);
		book1.applyDiscount(10);
		book1
		.displayDetails();
	}
}
/*
Documentation
1. The Book class in this program is used to store book data like the title, the publisher, and the year it was released
2. The displayDetails method in this program helps display an organized copy of the book instance
3. You'd obviously be fronted with an error, if you missed any of the construction fields while creating a new instance of the Book class. The displayDetails method would throw an exception/error if that were the case.
4. Modify? You wouldn't need to, as long as the instances have unique variable names and there's no naming overlap/conflict, like book1 for book A, book2 for book B, like so.
5. 
  A. You would need to add a new variable to the Book class, and that right after the initialization of (char)variable grade
  B. Further, add a new parameter to the constructor, and with that done, and `this.$newAttribute = $parameterName` to the end of the constructor. Make sure there are no type or naming conflicts.
  C. Pass that new parameter to all the present, and future instances of the Book class
*/