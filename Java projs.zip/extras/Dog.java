class Animal {
	String name,
	  breed;
	int age;
	
	Animal() {
		this.name = "anonymous";
		this.breed = "anonymous";
		this.age = 0;
	}
	Animal(String name, String breed, int age) {
		this.name = name;
		this.breed = breed;
		this.age = age;
	}
}
class Dog extends Animal {
	Dog() {
		this.name = name;
		this.breed = breed;
		this.age = age;
	}
	Dog(String name, String breed, int age) {
		this.name = name;
		this.breed = breed;
		this.age = age;
	}
	public void bark(int n_times) {
		for (; n_times>0; n_times--) System.out.println("Dogs bark, other animals don't!");
	}
	public void bark() {
		bark(1);
	}
}
    

public class Main {
	public static void main(String[] args) {
		Animal elephant = new Animal("elephant", "jigsaw", 8);
		Dog dog = new Dog("Fenny", "Chihuahua", 6);
		
		dog.bark();
	}
}