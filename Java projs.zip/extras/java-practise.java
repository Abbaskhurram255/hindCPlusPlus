public class Obj {
	int num, num2;
	Obj(int num, int num2) {
		this.num = num;
		this.num2 = num2;
	}
}

class Main {
	public static void main(String[] args) {
	    Obj myObj = new Obj(5, 0);
		System.out.println("h"+myObj.num+"llo w"+myObj.num2+"rld");
	}
}