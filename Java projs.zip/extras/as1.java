class Main {
	//1
	public static String iseven(int n) {
	    return n%2==0 ? "even" : "odd";
	}
	//2
	public static int max(int n1, int n2) {
	    if (n1>n2) return n1;
	    else return n2;
	}
	//3
	public static int maxBwThree(int n1, int n2, int n3) {
	    if (n1>n2 && n1>n3) return n1;
	    else if (n2>n1 && n2>n3) return n2;
	    else return n3;
	}
	//4
	public static String isPos(int n) {
	    if (n>0) return "positive";
	    else if (n<0) return "negative";
	    return "neither, it's a zero";
	}
	//5
	public static boolean divBy5And11(int n) {
	    if (n % 5 == 0 && n % 11 == 0) return true;
	    return false;
	}
	
	//6
	public static boolean isLeapYear(int y) {
	    return y%4==0;
	}
    
    //7
    public static String isVowel(char c) {
        c = Character.toLowerCase(c);
        char vowels[] = {'a', 'e', 'i', 'o', 'u'};
        for (char vowel : vowels) {
            if (c == vowel) return "vowel";
        }
        return "consonant";
    }
	
	//8
	public static String isAlpha(char c) {
	    if (c >= 48 && c <= 57) return "digit";
	    else if (c >= 65 && c <= 122) return "alpha";
	    return "special";
	}
	
	//9
	public static String isUpper(char c) {
	    if (Character.isUpperCase(c)) return "The char is in its uppercase form";
	    return "The char is in the lowercase form";
	}
	
	//10
	public static boolean isPrime(int n)
    {
        for (int i = 2; i <= n/2; i++)
        {
            if (n % i == 0)
            {
                return false;
            }
        }
        return true;
    }
    
    //11
    public static void printDayOfWeekSwitch(int n) {
        switch (n) {
            case 1: System.out.println("Sunday"); break;
            case 2: System.out.println("Monday"); break;
            case 3: System.out.println("Tuesday"); break;
            case 4: System.out.println("Wednesday"); break;
            case 5: System.out.println("Thursday"); break;
            case 6: System.out.println("Friday"); break;
            default: System.out.println("Saturday");
        }
    }
    
    //12
    public static void printDayOfWeekIf(int n) {
        if (n == 1) System.out.println("Sunday");
        else if (n == 2) System.out.println("Monday");
        else if (n == 3) System.out.println("Tuesday");
        else if (n == 4) System.out.println("Wednesday");
        else if (n == 5) System.out.println("Thursday");
        else if (n == 6) System.out.println("Friday");
        else System.out.println("Saturday");
    }
	
	//13
	public static String detectSeason(String m) {
	    m = m.toLowerCase();
	    if (m == "may" || m == "jun" || m == "jul" || m == "aug") return "Summer";
	    else if (m == "sep" || m == "oct") return "Spring";
	    else if (m == "nov" || m == "dec" || m == "jan" || m == "feb") return "Winter";
	    else return "Fall/Autumn";
	}
	
	//14
	public static String genHalfTriangle() {
	    String str = "";
    	for (int i=1; i<=5; i++) {
            for (int j=1; j<=i; j++) {
                str += "* ";
            }
            str += "\n";
        }
        return str;
	}
	
	//15
	public static String genPyramid() {
	    String str = "";
    	for (int i=0; i<=10; i++) {
            for (int j=15; j>i; j--) {
                str += " ";
            }
            for (int k=0; k<=i; k++) str += "* ";
            str += "\n";
        }
        return str;
	}
	
	//16
	public static void printDiamond() {
	    int i, j, n=7, space = 1;
        space = n - 1;
        for (j = 1; j <= n; j++) 
        {
            for (i = 1; i <= space; i++) 
            {
                System.out.print(" ");
            }
            space--;
            for (i = 1; i <= 2 * j - 1; i++) 
            {
                System.out.print("*");                
            }
            System.out.println("");
        }
        space = 1;
        for (j = 1; j <= n - 1; j++) 
        {
            for (i = 1; i <= space; i++) 
            {
                System.out.print(" ");
            }
            space++;
            for (i = 1; i <= 2 * (n - j) - 1; i++) 
            {
                System.out.print("*");
            }
            System.out.println("");
        }
	}
	
	//17
  public static void fibonacci(int n) {
    int firstTerm = 0, secondTerm = 1;
    System.out.println("Fibonacci sequence upto " + n + ": ");
    while (firstTerm <= n) {
      System.out.print(firstTerm + ", ");
      int nextTerm = firstTerm + secondTerm;
      firstTerm = secondTerm;
      secondTerm = nextTerm;
    }
  }
	
	//18
	public static void primesUpTo(int n)
    {
        for (int i=2; i<=n; i++) {
            if (isPrime(i)) System.out.println(i);
        }
    }
	
	
	
	public static void main(String[] args) {
		//fibonacci (7);
		printDiamond();
		System.out.println(detectSeason("apr"));
		printDayOfWeekSwitch(7);
		//primesUpTo(22);
	}
}