public class Calculator {
    int n;
    int square = 2,
      cube = 3;
    
    Calculator() {
        System.out.println("Inside default constructor");
    }
    Calculator(int n) {
        System.out.println("Inside parameterized constructor");
        this.n = n;
    }
    
    
    int calcSquare(int x) {
        return x*x;
    }
    int calcCube(int x) {
        return x*x*x;
    }
    int calcFactorial(int x) {
        int result = 1;
        for (int i=x; i>0; i--) {
            result *= i;
        }
        return result;
    }
    String generateTable(int n) {
        String result = "Square: "+calcSquare(n)+"\nCube: "+calcCube(n)+"\nFactorial: "+calcFactorial(n);
        return result;
    }
    
}

class Main {
	public static void main(String[] args) {
		Calculator calc = new Calculator();
		Calculator calc2 = new Calculator(3);
		System.out.println("With default constructor\n"+calc.generateTable(5));
	}
}