import java.util.*;

class Error extends Throwable  {
    Error(String msg) {
        super(msg);
    }
}

class Object_S extends HashMap<String, String> {
    Object_S() {
        super();
    }
    Object_S(String k1, String v1, String k2, String v2, String k3, String v3, String k4, String v4, String k5, String v5) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
        super.put(k5, v5);
    }
    Object_S(String k1, String v1, String k2, String v2, String k3, String v3, String k4, String v4) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
    }
    Object_S(String k1, String v1, String k2, String v2, String k3, String v3) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
    }
    Object_S(String k1, String v1, String k2, String v2) {
        super.put(k1, v1);
        super.put(k2, v2);
    }
    Object_S(String k1, String v1) {
        super.put(k1, v1);
    }
    String key(String k) {
        return super.get(k);
    }
    String k(String k) {
        return super.get(k);
    }
    String val(String k) {
        return super.get(k);
    }
    String v(String k) {
        return super.get(k);
    }
    void add(String k, String v) {
        super.put(k, v);
    }
    String delete(String k) {
        String v = super.get(k);
        super.remove(k);
        return v;
    }
    void push(String k, String v) {
        add(k, v);
    }
    String pop(String k) {
        return delete(k);
    }
    boolean hasKey(String k) {
        return super.containsKey(k);
    }
    boolean hasValue(String v) {
        return super.containsValue(v);
    }
    void set(String k, String v) {
        if (!super.containsKey(k)) super.put(k, v);
        else super.replace(k, v);
    }
    void update(String k, String v) {
        set(k, v);
    }
    Set<String> keys() {
        return super.keySet();
    }
    Set<Map.Entry<String, String>> entries() {
        return super.entrySet();
    }
    void printMap() {
        System.out.println(super.clone());
    }
}
class Object_I extends HashMap<String, Integer> {
    Object_I() {
        super();
    }
    Object_I(String k1, Integer v1, String k2, Integer v2, String k3, Integer v3, String k4, Integer v4, String k5, Integer v5) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
        super.put(k5, v5);
    }
    Object_I(String k1, Integer v1, String k2, Integer v2, String k3, Integer v3, String k4, Integer v4) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
    }
    Object_I(String k1, Integer v1, String k2, Integer v2, String k3, Integer v3) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
    }
    Object_I(String k1, Integer v1, String k2, Integer v2) {
        super.put(k1, v1);
        super.put(k2, v2);
    }
    Object_I(String k, Integer v) {
        super.put(k, v);
    }
    int key(String k) {
        return super.get(k);
    }
    int k(String k) {
        return super.get(k);
    }
    int val(String k) {
        return super.get(k);
    }
    int v(String k) {
        return super.get(k);
    }
    void add(String k, Integer v) {
        super.put(k, v);
    }
    int delete(String k) {
        int v = super.get(k);
        super.remove(k);
        return v;
    }
    void push(String k, int v) {
        add(k, v);
    }
    int pop(String k) {
        return delete(k);
    }
    boolean hasKey(String k) {
        return super.containsKey(k);
    }
    boolean hasValue(Integer v) {
        return super.containsValue(v);
    }
    void set(String k, Integer v) {
        if (!super.containsKey(k)) super.put(k, v);
        else super.replace(k, v);
    }
    void update(String k, Integer v) {
        set(k, v);
    }
    Set<String> keys() {
        return super.keySet();
    }
    Set<Map.Entry<String, Integer>> entries() {
        return super.entrySet();
    }
    void printMap() {
        System.out.println(super.clone());
    }
}
class Object_L extends HashMap<String, Long> {
    Object_L() {
        super();
    }
    Object_L(String k1, Long v1, String k2, Long v2, String k3, Long v3, String k4, Long v4, String k5, Long v5) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
        super.put(k5, v5);
    }
    Object_L(String k1, Long v1, String k2, Long v2, String k3, Long v3, String k4, Long v4) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
    }
    Object_L(String k1, Long v1, String k2, Long v2, String k3, Long v3) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
    }
    Object_L(String k1, Long v1, String k2, Long v2) {
        super.put(k1, v1);
        super.put(k2, v2);
    }
    Object_L(String k, Long v) {
        super.put(k, v);
    }
    long key(String k) {
        return super.get(k);
    }
    long k(String k) {
        return super.get(k);
    }
    long val(String k) {
        return super.get(k);
    }
    long v(String k) {
        return super.get(k);
    }
    void add(String k, Long v) {
        super.put(k, v);
    }
    long delete(String k) {
        long v = super.get(k);
        super.remove(k);
        return v;
    }
    void push(String k, long v) {
        add(k, v);
    }
    long pop(String k) {
        return delete(k);
    }
    boolean hasKey(String k) {
        return super.containsKey(k);
    }
    boolean hasValue(Long v) {
        return super.containsValue(v);
    }
    void set(String k, Long v) {
        if (!super.containsKey(k)) super.put(k, v);
        else super.replace(k, v);
    }
    void update(String k, Long v) {
        set(k, v);
    }
    Set<String> keys() {
        return super.keySet();
    }
    Set<Map.Entry<String, Long>> entries() {
        return super.entrySet();
    }
    void printMap() {
        System.out.println(super.clone());
    }
}
class Object_F extends HashMap<String, Float> {
    Object_F() {
        super();
    }
    Object_F(String k1, Float v1, String k2, Float v2, String k3, Float v3, String k4, Float v4, String k5, Float v5) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
        super.put(k5, v5);
    }
    Object_F(String k1, Float v1, String k2, Float v2, String k3, Float v3, String k4, Float v4) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
    }
    Object_F(String k1, Float v1, String k2, Float v2, String k3, Float v3) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
    }
    Object_F(String k1, Float v1, String k2, Float v2) {
        super.put(k1, v1);
        super.put(k2, v2);
    }
    Object_F(String k1, Float v1) {
        super.put(k1, v1);
    }
    float key(String k) {
        return super.get(k);
    }
    float k(String k) {
        return super.get(k);
    }
    float val(String k) {
        return super.get(k);
    }
    float v(String k) {
        return super.get(k);
    }
    void add(String k, Float v) {
        super.put(k, v);
    }
    float delete(String k) {
        float v = super.get(k);
        super.remove(k);
        return v;
    }
    void push(String k, float v) {
        add(k, v);
    }
    float pop(String k) {
        return delete(k);
    }
    boolean hasKey(String k) {
        return super.containsKey(k);
    }
    boolean hasValue(Float v) {
        return super.containsValue(v);
    }
    void set(String k, Float v) {
        if (!super.containsKey(k)) super.put(k, v);
        else super.replace(k, v);
    }
    void update(String k, Float v) {
        set(k, v);
    }
    Set<String> keys() {
        return super.keySet();
    }
    Set<Map.Entry<String, Float>> entries() {
        return super.entrySet();
    }
    void printMap() {
        System.out.println(super.clone());
    }
}
class Object_D extends HashMap<String, Double> {
    Object_D() {
        super();
    }
    Object_D(String k1, Double v1, String k2, Double v2, String k3, Double v3, String k4, Double v4, String k5, Double v5) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
        super.put(k5, v5);
    }
    Object_D(String k1, Double v1, String k2, Double v2, String k3, Double v3, String k4, Double v4) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
    }
    Object_D(String k1, Double v1, String k2, Double v2, String k3, Double v3) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
    }
    Object_D(String k1, Double v1, String k2, Double v2) {
        super.put(k1, v1);
        super.put(k2, v2);
    }
    Object_D(String k, Double v) {
        super.put(k, v);
    }
    double key(String k) {
        return super.get(k);
    }
    double k(String k) {
        return super.get(k);
    }
    double val(String k) {
        return super.get(k);
    }
    double v(String k) {
        return super.get(k);
    }
    void add(String k, Double v) {
        super.put(k, v);
    }
    double delete(String k) {
        double v = super.get(k);
        super.remove(k);
        return v;
    }
    void push(String k, double v) {
        add(k, v);
    }
    double pop(String k) {
        return delete(k);
    }
    boolean hasKey(String k) {
        return super.containsKey(k);
    }
    boolean hasValue(Double v) {
        return super.containsValue(v);
    }
    void set(String k, Double v) {
        if (!super.containsKey(k)) super.put(k, v);
        else super.replace(k, v);
    }
    void update(String k, Double v) {
        set(k, v);
    }
    Set<String> keys() {
        return super.keySet();
    }
    Set<Map.Entry<String, Double>> entries() {
        return super.entrySet();
    }
    void printMap() {
        System.out.println(super.clone());
    }
}
class Object_B extends HashMap<String, Boolean> {
    Object_B() {
        super();
    }
    Object_B(String k1, Boolean v1, String k2, Boolean v2, String k3, Boolean v3, String k4, Boolean v4, String k5, Boolean v5) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
        super.put(k5, v5);
    }
    Object_B(String k1, Boolean v1, String k2, Boolean v2, String k3, Boolean v3, String k4, Boolean v4) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
        super.put(k4, v4);
    }
    Object_B(String k1, Boolean v1, String k2, Boolean v2, String k3, Boolean v3) {
        super.put(k1, v1);
        super.put(k2, v2);
        super.put(k3, v3);
    }
    Object_B(String k1, Boolean v1, String k2, Boolean v2) {
        super.put(k1, v1);
        super.put(k2, v2);
    }
    Object_B(String k, Boolean v) {
        super.put(k, v);
    }
    boolean key(String k) {
        return super.get(k);
    }
    boolean k(String k) {
        return super.get(k);
    }
    boolean val(String k) {
        return super.get(k);
    }
    boolean v(String k) {
        return super.get(k);
    }
    void add(String k, Boolean v) {
        super.put(k, v);
    }
    boolean delete(String k) {
        boolean v = super.get(k);
        super.remove(k);
        return v;
    }
    void push(String k, Boolean v) {
        add(k, v);
    }
    boolean pop(String k) {
        return delete(k);
    }
    boolean hasKey(String k) {
        return super.containsKey(k);
    }
    boolean hasValue(Boolean v) {
        return super.containsValue(v);
    }
    void set(String k, Boolean v) {
        if (!super.containsKey(k)) super.put(k, v);
        else super.replace(k, v);
    }
    void update(String k, Boolean v) {
        set(k, v);
    }
    Set<String> keys() {
        return super.keySet();
    }
    Set<Map.Entry<String, Boolean>> entries() {
        return super.entrySet();
    }
    void printMap() {
        System.out.println(super.clone());
    }
}

class Main {
  public static void main(String[] args) {

    // Creating a HashMap
    Object_S languages = new Object_S("key", "value", "fruit", "banana", "car", "Porsche");
    Object_D constants = new Object_D("g", 9.8);
    constants.add("pi", 3.15);
    constants.set("pi", 3.16);
    constants.update("pi", 3.14);
    constants.printMap();
    languages.add("Java", "Enterprise");
    languages.add("Python", "ML/AI");
    languages.add("JavaScript", "Frontend");
    languages.printMap();

    // iterating through key/value mappings
    System.out.print("Entries: {");
    for(Map.Entry entry: languages.entries()) {
      System.out.print(entry.getKey()+": \""+entry.getValue()+"\"");
      System.out.print(", ");
    }
    System.out.println("}");

    // iterating through keys
    System.out.print("\nKeys: ");
    for(String key: languages.keys()) {
      System.out.print(key);
      System.out.print(", ");
    }

    // iterating through values
    System.out.print("\nValues: ");
    for(String value: languages.values()) {
      System.out.print(value);
      System.out.print(", ");
    }
    System.out.println("\n"+languages.get("Java"));
  }
}
