class Main {
	public static void countdownWithRecursion(int n) {
	    if (n < 0) return;
	    System.out.println(n);
	    countdownWithRecursion(n-1);
	}
	public static void countdownWithForLoop(int n) {
	    for (; n>0; n--) {
	        System.out.println(n);
	    }
	}
	public static void main(String[] args) {
		int n=8;
		countdownWithRecursion(n);
		System.out.println("\nVS\n");
		countdownWithForLoop(n);
	}
}