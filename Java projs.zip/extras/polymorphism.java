class Radio {
    String name,
      artist;
    public void play() {
        System.out.println("The radio boots...");
    }
}

class Song extends Radio {
    Song(String name, String artist) {
        this.name = name;
        this.artist = artist;
    }
    
    public void play()
    {
        System.out.println(name + " by " + artist + "\nis playing on the Radio...");
    }
}

class Main {
	public static void main(String[] args) {
		Radio myRadio = new Radio();
		myRadio.play();
		Radio song1 = new Song("I Love You Like A Song", "Selena Gomez");
		song1.play();
	}
}