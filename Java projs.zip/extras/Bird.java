class Bird {
    public void makeSound() {
        System.out.println("Every bird makes sound...");
    }
}

/* polymorphism */
class Crow extends Bird {
    public void makeSound() {
        System.out.println("A crow makes: \"kaa... kaa\"");
    }
}
class Sparrow extends Bird {
    public void makeSound() {
        System.out.println("The sparrow makes: \"chir chir chir chi chich\"");
    }
}
class Pigeon extends Bird {
    public void makeSound() {
        System.out.println("The pigeon makes: \"hmmm, hmmm\"");
    }
}
class Hawk extends Bird {
    public void makeSound() {
        System.out.println("The hawk makes: \"chee... chee\"");
    }
}

class Main {
    public static void main(String[] args) {
        Bird unidentifiableBird = new Bird();
        Bird crow = new Crow();
        Bird sparrow = new Sparrow();
        Bird pigeon = new Pigeon();
        Bird hawk = new Hawk();
        
        //print the sound each of the declared birds make
        unidentifiableBird.makeSound();
        System.out.println();
        crow.makeSound();
        sparrow.makeSound();
        pigeon.makeSound();
        hawk.makeSound();
    }
}