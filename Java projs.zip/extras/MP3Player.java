import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class Mp3Player {
    private AudioInputStream audioInputStream;
    private SourceDataLine sourceDataLine;
    private boolean isPlaying = false;
    private boolean isPaused = false;
    private float volume = 1.0f;

    // Simple MP3 decoder (only supports basic MP3 files)
    private byte[] decodeMp3(byte[] mp3Data) {
        // This is a very basic implementation and may not work for all MP3 files
        // In a real-world implementation, you would need to handle more complex MP3 file structures
        byte[] pcmData = new byte[mp3Data.length * 2]; // Assume 16-bit PCM
        int pcmIndex = 0;
        for (int i = 0; i < mp3Data.length; i += 2) {
            // Simple decoding logic (not actual MP3 decoding)
            short sample = (short) ((mp3Data[i] & 0xFF) | (mp3Data[i + 1] << 8));
            pcmData[pcmIndex++] = (byte) (sample & 0xFF);
            pcmData[pcmIndex++] = (byte) ((sample >> 8) & 0xFF);
        }
        byte[] trimmedPcmData = new byte[pcmIndex];
        System.arraycopy(pcmData, 0, trimmedPcmData, 0, pcmIndex);
        return trimmedPcmData;
    }

    public void play(String filePath) throws IOException, LineUnavailableException {
        File audioFile = new File(filePath);
        byte[] mp3Data = new byte[(int) audioFile.length()];
        java.io.FileInputStream fis = new java.io.FileInputStream(audioFile);
        fis.read(mp3Data);
        fis.close();

        byte[] pcmData = decodeMp3(mp3Data);

        AudioFormat format = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, 44100, 16, 2, 4, 44100, false);
        audioInputStream = new AudioInputStream(new java.io.ByteArrayInputStream(pcmData), format, pcmData.length / format.getFrameSize());
        sourceDataLine = AudioSystem.getSourceDataLine(format);
        sourceDataLine.open(format);
        sourceDataLine.start();
        isPlaying = true;

        Thread playbackThread = new Thread(() -> {
            try {
                int bytesRead;
                byte[] buffer = new byte[1024];
                while ((bytesRead = audioInputStream.read(buffer, 0, buffer.length)) != -1) {
                    if (isPaused) {
                        while (isPaused) {
                            Thread.sleep(10);
                        }
                    }
                    sourceDataLine.write(buffer, 0, bytesRead);
                }
            } catch (IOException | InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                sourceDataLine.drain();
                sourceDataLine.close();
                isPlaying = false;
            }
        });
        playbackThread.start();
    }

    public void pause() {
        isPaused = true;
    }

    public void resume() {
        isPaused = false;
    }

    public void stop() {
        isPlaying = false;
        sourceDataLine.stop();
        sourceDataLine.close();
    }

    public void volumeUp() {
        volume += 0.1f;
        if (volume > 1.0f) {
            volume = 1.0f;
        }
        FloatControl volumeControl = (FloatControl) sourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);
        float dB = (float) (Math.log(volume) / Math.log(10.0) * 20.0);
        volumeControl.setValue(dB);
    }

    public void volumeDown() {
        volume -= 0.1f;
        if (volume < 0.0f) {
            volume = 0.0f;
        }
        FloatControl volumeControl = (FloatControl) sourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);
        float dB = (float) (Math.log(volume) / Math.log(10.0) * 20.0);
        volumeControl.setValue(dB);
    }

    public void mute() {
        volume = 0.0f;
        FloatControl volumeControl = (FloatControl) sourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);
        volumeControl.setValue(-80.0f); // Mute
    }

    public void unmute() {
        volume = 1.0f;
        FloatControl volumeControl = (FloatControl) sourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);
        volumeControl.setValue(0.0f);
    }
    public static void main(String[] args) throws IOException, LineUnavailableException {
        Mp3Player player = new Mp3Player();
        String filePath = "/storage/emulated/0/Download/Java projs/m.mp3"; // replace with your file path
        player.play(filePath);

        // Example usage of player controls
        // player.pause();
        // player.resume();
        // player.stop();
        // player.volumeUp();
        // player.volumeDown();
        // player.mute();
        // player.unmute();
    }
}