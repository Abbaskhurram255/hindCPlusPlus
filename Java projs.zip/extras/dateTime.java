import java.util.*;

class Main {
	public static void main(String[] args) {
		Date dt = new Date();
		dt.setTime(dt.getTime()+(5*3600000));
		int dayAsANumber = new Date().getDay();
		String day;
		switch (dayAsANumber) {
			case 0:
			day = "Sunday";
			break;
			case 1:
			day = "Monday";
			break;
			case 2:
			day = "Tuesday";
			break;
			case 3:
			day = "Wednesday";
			break;
			case 4:
			day = "Thursday";
			break;
			case 5:
			day = "Friday";
			break;
			default:
			day = "Saturday";
			break;
		}
		String date = dt.toLocaleString();
		date = day+", "+date;
		String parts[] = date.split(":");
		date = parts[0]+":"+parts[1]+" "+date.substring(date.length() - 2);
		System.out.println(date);
	}
}