import java.util.*;
//use `import java.util.Scanner;` to only import the Scanner
import java.util.concurrent.*;
import java.security.SecureRandom;


class KL {
  //Date functions
  public String nthDay(int n) {
        String days[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        return days[n];
    }
    public String nthMonth(int n) {
        String months[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        return months[n];
    }
    public String formattedDate(Date dt) {
    	int dayOfWeek = dt.getDay(), monthOfYear = dt.getMonth();
        String day, month;
        String date = dt.toLocaleString();
        String ampm = date.substring(date.length() - 2);
        date = date.substring(0, date.length() - 6) + " " + ampm;
        month = nthMonth(monthOfYear);
        date = month + " " + date.substring(4);
        day = nthDay(dayOfWeek);
        date = day + ", " + date;
        return date;
    }
    public String now() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*(3600*1000))); //fix 5-hour bug
        String date = formattedDate(dt);
        return date;
    }
    public String getDate() {
      String parts[] = now().split(", ");
      return parts[1] + ", " + parts[2];
    }
    public String getDay() {
      return now().split(", ")[0];
    }
    public String getMonth() {
      return now().split(", ")[1].split(" ")[0];
    }
    public String getYear() {
      return now().split(", ")[2];
    }
    public String getTime() {
      return now().split(", ")[3];
    }
    public String yesterday() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime()-((int)36e5*24)); //decrement 24 hours or (3.6*10⁶)*24 milliseconds
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String dayBeforeYesterday() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime()-((int)72e5*24)); //decrement 48 hours or (7.2*10⁶)*24 milliseconds
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String twoDaysAgo() {
    	return new KL().dayBeforeYesterday();
    }
    public String tomorrow() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)(36e2*1e3)))); //fix 5-hour bug
        dt.setTime(dt.getTime()+((int)36e5*24)); //increment 24 hours or (3.6*10⁶)*24 milliseconds
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String dayAfterTomorrow() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime()+((int)72e5*24)); //increment 48 hours or (7.2*10⁶)*24 milliseconds
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String twoDaysLater() {
    	return new KL().dayAfterTomorrow();
    }
    public String lastMonth() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setMonth(dt.getMonth()-1); //decrement a month
        String date = formattedDate(dt);
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String lastMonthOf(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setMonth(dt.getMonth()-1); //decrement a month
        date = formattedDate(dt);
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String nextMonth() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setMonth(dt.getMonth()+1); //increment a month
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String nextMonthOf(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setMonth(dt.getMonth()+1); //increment a month
        date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String lastYear() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setYear(dt.getYear()-1); //decrement a year
        String date = formattedDate(dt);
        String parts[] = date.split(", ");
        date = date.split(", ")[2];
        return date;
    }
    public String lastYearOf(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setYear(dt.getYear()-1); //decrement a year
        date = formattedDate(dt);
        date = date.split(", ")[2];
        return date;
    }
    public String nextYear() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setYear(dt.getYear()+1); //increment a year
        String date = formattedDate(dt);
        date = date.split(", ")[2];
        return date;
    }
    public String nextYear(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setYear(dt.getYear()+1); //increment a year
        date = formattedDate(dt);
        date = date.split(", ")[2];
        return date;
    }
    public String age2bday(int age) {
        Date dt = new Date();
        //dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        String bday = ""+((dt.getYear()+1900) - age); //adding 1900 helps resolve a bug
        return bday;
    }
    public int bday2age(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        int age = new Date().getYear() - dt.getYear();
        return age;
    }
    public String date2day(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        date = formattedDate(dt);
        date = date.split(", ")[0];
        return date;
    }
    public String date2month(String date) {
        Date dt = new Date(date);
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        date = formattedDate(dt);
        date = date.split(", ")[1].split(" ")[0];
        return date;
    }
    public String timeGreet() {
    	String greeting;
    	int h = new Date().getHours() + 5; //fix 5-hour bug along the way
        if (h >= 20) greeting = "Good night";
        else if (h >= 16) greeting = "Good evening";
        else if (h >= 12) greeting = "Good afternoon";
        else if (h >= 0 && h <= 4) greeting = "Good new day";
        else greeting = "Good morning";
        return greeting;
    }
    public String lastOfMonth(int m) {
        Date dt = new Date();
        KL dt2 = new KL();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug for better accuracy
        String result = ""+(""+dt2.nthMonth(m-1) + " " + new Date(new Date().getYear(), m, 0).getDate());
        return result;
    }
    public boolean isWeekend() {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
    	return dt.getDay() % 6 == 0;
    }
    public boolean isLeapYear() {
    	return (1900 + new Date().getYear()) % 4 == 0;
    }
    public int nextLeapYear() {
        Date dt = new Date();
        dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug for better accuracy
        int i = 0;
        if (dt.getYear() % 4 == 0) dt.setYear(dt.getYear() + 1); //ignore current year, if it's leap
        while (dt.getYear() % 4 != 0) {
            dt.setYear((dt.getYear()) + i);
            i++;
        }
        int result = (1900+dt.getYear()); //comes with a bug fix
        return result;
    }
    public String dateBefore(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setDate(dt.getDate() - Math.abs(n));
        String date = new KL().formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String dateAfter(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setDate(dt.getDate() + Math.abs(n));
        String date = new KL().formattedDate(dt);
        String parts[] = date.split(", ");
        date = parts[0] + ", " + parts[1] + ", " + parts[2];
        return date;
    }
    public String minsAgo(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime() - (n * (int)60e3));
        String time = new KL().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String minsLater(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime() + (n * (int)60e3));
        String time = new KL().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String hoursAgo(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //first fix the 5-hour bug
        dt.setTime(dt.getTime() - (n * (int)36e5));
        String time = new KL().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String hoursLater(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //first fix the 5-hour bug
        dt.setTime(dt.getTime() + (n * (int)36e5));
        String time = new KL().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String nthHour(int n) {
    	Date dt = new Date();
    	dt.setTime(dt.getTime()+(5*((int)36e5))); //fix 5-hour bug
        dt.setTime(dt.getTime() - (int)36e5 * dt.getHours() + (n * (int)36e5));
        String time = new KL().formattedDate(dt);
        time = time.split(", ")[3];
        return time;
    }
    public String date() {
    	return new KL().now();
    }
  
    //utilities
	public static void print(String... args) {
		System.out.print("\n");
		String arguments = String.join(" ", args);
		System.out.print(arguments);
	}
	public static void print(int... args) {
		System.out.print("\n");
		for (int arg : args) {
			System.out.print(arg);
		}
	}
	public static void print(float... args) {
		System.out.print("\n");
		for (float arg : args) {
			System.out.print(arg);
		}
	}
	public static void print(double... args) {
		System.out.print("\n");
		for (double arg : args) {
			System.out.print(arg);
		}
	}
	public static void println(String... args) {
		String arguments = String.join(" ", args);
		System.out.print(arguments);
	}
	public static void println(int... args) {
		for (int arg : args) {
			System.out.print(arg);
		}
	}
	public static void println(float... args) {
		for (float arg : args) {
			System.out.print(arg);
		}
	}
	public static void println(double... args) {
		for (double arg : args) {
			System.out.print(arg);
		}
	}
	public static void printb(int... args) {
		System.out.print("\n");
		for (int arg : args) {
			System.out.print(arg == 1 ? "true" : "false");
		}
	}
	public static void printbln(int... args) {
		for (int arg : args) {
			System.out.print(arg == 1 ? "true" : "false");
		}
	}
	public static String scan(String s) {
		print(s);
		Scanner input = new Scanner(System.in);
		String x = input.nextLine();
		//input.close();
		return x;
	}
	public static int scani(String s) {
		print(s);
		Scanner input = new Scanner(System.in);
		int x = input.nextInt();
		return x;
	}
	public static double scanf(String s) {
		print(s);
		Scanner input = new Scanner(System.in);
		double x = input.nextDouble();
		return x;
	}
	public static double scann(String s) {
		print(s);
		Scanner input = new Scanner(System.in);
		double x = input.nextDouble();
		return x;
	}
	public static void br(int n) {
		for (; n>0; n--) print("\n");
	}
	public static void br() {
		br(1);
	}
	public static void next() {
		br(1);
	}
	public static String Str(double arg) {
		String x[] = ("" + arg).split("(?<=\\d)\\.\\d+");
		return x[0];
	}
	public static String join(String[] stringedArray, String with) {
		String returnValue = String.join(with, stringedArray);
		return returnValue;
	}
	public static int Int(String arg) {
		try {
			return Integer.parseInt(Str(Integer.parseInt(arg)));
		} catch (Exception err) {
			return 0;
		}
	}
	public static float Flt(String arg) {
		try {
			return Float.parseFloat(arg);
		} catch (Exception err) {
			return 0;
		}
	}
	public static double sum(double... ns) {
		double acc = 0;
		for (int next = 0; next < ns.length; next++) acc += ns[next];
		return acc;
	}
	public static double diff(double... ns) {
		double acc = ns[0];
		for (int next = 1; next < ns.length; next++) acc -= ns[next];
		return acc;
	}
	public static double prd(double... ns) {
		double acc = ns[0];
		for (int next = 1; next < ns.length; next++) acc *= ns[next];
		return acc;
	}
	public static double quo(double... ns) {
		double acc = ns[0];
		for (int next = 1; next < ns.length; next++) acc /= ns[next];
		return acc;
	}
	public static double pow(double n, double power) {
		return Math.pow(n, power);
	}
	public static double sq(double n) {
		return n * n;
	}
	public static double cb(double n) {
		return sq(n) * n;
	}
	public static double area(double w, double h) {
		return w * h;
	}
	public static double rect(double w, double h) {
		return area(w, h);
	}
	public static double tria(double w, double h) {
		return .5 * rect(w, h);
	}
	public static double getMax(double n1, double n2) {
		return Math.max(n1, n2);
	}
	public static double getMin(double n1, double n2) {
		return Math.min(n1, n2);
	}
	public static double mod(double n1, double n2) {
		if (n2 > n1) {
			double temp = n1;
			n1 = n2;
			n2 = temp;
		}
		return Math.abs(n1 % n2);
	}
	public static int isperfmod(double n1, double n2) {
		return mod(n1, n2) == 0 ? 1 : 0;
	}
	public static double pct(double n1, double n2) {
		if (n1 < n2) return Math.round(n1 / n2 * 100.0) / 100.0;
		else return Math.round(n1 * (n2 * .01) * 100.0) / 100.0;
	}
	public static int iseven(double n) {
		return isperfmod(n, 2);
	}
	public static int isodd(double n) {
		return isperfmod(n, 2) != 1 ? 1 : 0;
	}
	public static int isprime(int n) {
		for (int i = 2; i <= n / 2; i++) {
			if (n % i == 0) return 0;
		}
		return 1;
	}
	public static int randInt() {
		int number = ThreadLocalRandom.current().nextInt(0, 199);
		return number;
	}
	public static int randInt(int end) {
		int number = ThreadLocalRandom.current().nextInt(0, end);
		return number;
	}
	public static int randInt(int start, int end) {
		int number = ThreadLocalRandom.current().nextInt(start, end);
		return number;
	}
	public static String randStr() {
		int len = randInt(8, 32);
		final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		SecureRandom rnd = new SecureRandom();

		StringBuilder sb = new StringBuilder(len);
		for (int i = 0; i < len; i++)
			sb.append(AB.charAt(rnd.nextInt(AB.length())));
		return sb.toString();
	}
	public static String randStr(int len) {
		final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		SecureRandom rnd = new SecureRandom();
		StringBuilder sb = new StringBuilder(len);
		for (int i = 0; i < len; i++)
			sb.append(AB.charAt(rnd.nextInt(AB.length())));
		return sb.toString();
	}
	public static int randItInt(int arr[]) {
		return arr[randInt(50, 50000) % arr.length];
	}
	public static double randItDbl(double arr[]) {
		return arr[randInt(50, 50000) % arr.length];
	}
	public static float randItFlt(float arr[]) {
		return arr[randInt(50, 50000) % arr.length];
	}
	public static String randItStr(String arr[]) {
		return arr[randInt(50, 50000) % arr.length];
	}
	public static String replace(String str, String to_replace, String to_replace_with) {
		return str.replaceFirst(to_replace, to_replace_with);
	}
	public static String replaceAll(String str, String to_replace, String to_replace_with) {
		return str.replaceAll(to_replace, to_replace_with);
	}
	public static int strcmp(String strA, String strB) {
		return strA.compareToIgnoreCase(strB) == 0 ? 1 : 0;
	}
	String slice(String str, int start) {
		return str.substring(start, str.length());
	}
	String slice(String str, int start, int end) {
		return str.substring(start, end);
	}
	String sliceEnd(String str, int end) {
		return str.substring(0, str.length()-end);
	}
	String trim(String str, int start) {
		return str.substring(start, str.length());
	}
	String trim(String str, int start, int end) {
		return str.substring(start, end);
	}
	String trimEnd(String str, int end) {
		return str.substring(0, str.length()-end);
	}
	public static int test(String str, String re) {
		return str.toLowerCase().matches(re.toLowerCase()) ? 1 : 0;
	}
	public static String upper(String s) {
		s = s.toUpperCase();
		return s;
	}
	public static String lower(String s) {
		s = s.toLowerCase();
		return s;
	}
	public static int len(String str) {
	    return str.length();
	}
	public static int len(String arr[]) {
	    return arr.length;
	}
	public static int len(int arr[]) {
	    return arr.length;
	}
	public static int len(float arr[]) {
	    return arr.length;
	}
	public static int len(double arr[]) {
	    return arr.length;
	}
	public static void bubbleSort(int arr[]) {
	    int size = arr.length;
	    for (int i : arr) {
	        boolean swappingNeeded = false;
	        for (int j=0; j<size-i-1; j++) {
	            if (arr[j] > arr[j + 1]) {
	                swappingNeeded = true;
	                int temp = arr[j];
	                arr[j] = arr[j+1];
	                arr[j+1] = temp;
	            }
	        }
	        if (!swappingNeeded) break;
	    }
	}
	public static void bubbleSort(float arr[]) {
	    int size = arr.length;
	    for (float i : arr) {
	        boolean swappingNeeded = false;
	        for (int j=0; j<size-i-1; j++) {
	            if (arr[j] > arr[j + 1]) {
	                swappingNeeded = true;
	                float temp = arr[j];
	                arr[j] = arr[j+1];
	                arr[j+1] = temp;
	            }
	        }
	        if (!swappingNeeded) break;
	    }
	}
	public static void bubbleSort(double arr[]) {
	    int size = arr.length;
	    for (double i : arr) {
	        boolean swappingNeeded = false;
	        for (int j=0; j<size-i-1; j++) {
	            if (arr[j] > arr[j + 1]) {
	                swappingNeeded = true;
	                double temp = arr[j];
	                arr[j] = arr[j+1];
	                arr[j+1] = temp;
	            }
	        }
	        if (!swappingNeeded) break;
	    }
	}
	public static void printArr(String arr[]) {
	    for (String str : arr) print(str);
	}
	public static void printArr(int arr[]) {
	    for (int n : arr) print(n);
	}
	public static void printArr(float arr[]) {
	    for (float n : arr) print(n);
	}
	public static void printArr(double arr[]) {
	    for (double n : arr) print(n);
	}
	public static void printAll(String arr[]) {
	    for (String str : arr) print(str);
	}
	public static void printAll(int arr[]) {
	    for (int n : arr) print(n);
	}
	public static void printAll(float arr[]) {
	    for (float n : arr) print(n);
	}
	public static void printAll(double arr[]) {
	    for (double n : arr) print(n);
	}
	public static void printEach(String arr[]) {
	    for (String str : arr) print(str);
	}
	public static void printEach(int arr[]) {
	    for (int n : arr) print(n);
	}
	public static void printEach(float arr[]) {
	    for (float n : arr) print(n);
	}
	public static void printEach(double arr[]) {
	    for (double n : arr) print(n);
	}
	public static void main(String[] args) {
		String name = scan("Please enter your name: ");
		next();
		int age = scani("And age? ");
		next();
		print("---- * ----");
		next();
		print("Name:", name, "\nAge:", Str(age));
		String arrayOfTextChunks[] = {"hi", "this", "is", "me"};
		int nums[] = {1, 2, 5, 3, 6, 7, 8, 4, 9, 10};
		bubbleSort(nums);
		String collectedChunks = join(arrayOfTextChunks, "+");
		print(collectedChunks);
		print(randInt());

	    print(randItStr(arrayOfTextChunks));
        //print(len(nums));
        printArr(nums);
	}
}