public class Student {
	String name;
	int age;
	void printName() {
		System.out.println("___New Student___\nName: " + name + "\nAge: " + ("" + age));
	}
	Student(String name, int age) {
		this.name = name;
		this.age = age;
	}
}
class Main {
	public static void main(String args[]) {
		Student student1 = new Student("Muhammad Ali", 29);
		Student student2 = new Student("Fareeda Naseer", 26);
		Student student3 = new Student("Khurram Ali", 22);
		String names[] = {student1.name, student2.name, student3.name};
		int ages[] = {student1.age, student2.age, student3.age};

		student1.printName();
		student2.printName();
		student3.printName();

		System.out.println("\n\nAll names: ");
		for (String name : names) System.out.println(name);
		System.out.println("\nTheir ages: ");
		for (int age : ages) System.out.println(age);
	}
}