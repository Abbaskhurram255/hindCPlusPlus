class Main {
  public static void main(String[] args) {
    System.out.println("*Books in the shelf*\n");
    Book book1 = new Book("The Fundamentals of HindC", "Khurram Ali", 2025);
    Book book2 = new Book("The Subtle Art", "Mark Manson", 2009);
    book1.printBookData();
    book2.printBookData();
  }
}

class Book {
  String name, author;
  int released;
  Book() {
    this.name = "unknown";
    this.author = "unknown";
    this.released = 1970;
  }
  Book(String name, String author, int released) {
    this.name = name;
    this.author = author;
    this.released = released;
  }
  void printBookData() {
    System.out.println("---------\nName: "+this.name+"\nAuthor: "+this.author+"\nReleased: "+this.released+"\n");
  }
}