class Bird {
    public void makeSound() {
        System.out.println("Every bird makes sound...");
    }
}

/* polymorphism */
class Crow extends Bird {
    @Override public void makeSound() {
        System.out.println("Crow makes: \"kaa kaa\"");
    }
}
class Sparrow extends Bird {
    @Override public void makeSound() {
        System.out.println("The Sparrow makes: \"chich-chich-chich-chichichichi-chich\"");
    }
}
class Pigeon extends Bird {
    @Override public void makeSound() {
        System.out.println("The pigeon makes: \"hmmm hmmm\"");
    }
}
class Hawk extends Bird {
    @Override public void makeSound() {
        System.out.println("The hawk makes: \"chee... chee\"");
    }
}

class Main {
    public static void main(String[] args) {
        Bird unidentifiableBird = new Bird();
        Bird crow = new Crow();
        Bird sparrow = new Sparrow();
        Bird pigeon = new Pigeon();
        Bird hawk = new Hawk();
        
        //print the sound each of the declared birds make
        unidentifiableBird.makeSound();
        System.out.println();
        crow.makeSound();
        sparrow.makeSound();
        pigeon.makeSound();
        hawk.makeSound();
    }
}