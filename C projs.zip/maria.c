#include <stdio.h>

void printName() {
    //M
    printf("\t*                  *\n");
    printf("\t* *               *  *\n");
    printf("\t*  *             *   *\n");
    printf("\t*    *          *    *\n");
    printf("\t*      *       *     *\n");
    printf("\t*        *    *      *\n");
    printf("\t*          * *       *\n");
    for (int i=0; i<6; i++) printf("\t*                    *\n");
    
    //I
    printf("\n\t       * * * ** * * *                    \n");
	printf("\t              *          \n");
	printf("\t              *          \n");
	printf("\t              *          \n");
	printf("\t              *          \n");
	printf("\t              *          \n");
	printf("\t              *                 \n");
	printf("\t              *                     \n");
	printf("\t              *                         \n");
	printf("\t              *                    \n");    printf("\t       * * * ** * * *                    \n\n");
	
	//S
	printf("\t        * * * * * * *  \n");
	printf("\t        * \n");
	printf("\t        * \n");
	printf("\t        * \n");
	printf("\t        * \n");
	printf("\t        * * * * * * * \n");
	printf("\t                     * \n");
	printf("\t                     * \n");
	printf("\t                     * \n");
	printf("\t                     * \n");
	printf("\t        * * * * * * * \n\n");
	
	//S
	printf("\t        * * * * * * *  \n");
	printf("\t        * \n");
	printf("\t        * \n");
	printf("\t        * \n");
	printf("\t        * \n");
	printf("\t        * * * * * * * \n");
	printf("\t                     * \n");
	printf("\t                     * \n");
	printf("\t                     * \n");
	printf("\t                     * \n");
	printf("\t        * * * * * * * \n\n\n");
    
    //M
    printf("\n\t*                  *\n");
    printf("\t* *               *  *\n");
    printf("\t* *              *   *\n");
    printf("\t*    *          *    *\n");
    printf("\t*      *       *     *\n");
    printf("\t*        *    *      *\n");
    printf("\t*          * *       *\n");
    for (int i=0; i<6; i++) printf("\t*                    *\n");
    
    
    //A
    printf("\t              *          \n");
	printf("\t             *  *        \n");
	printf("\t            *     *       \n");
	printf("\t           *        *       \n");
	printf("\t        * * * * * * * * *    \n");
	printf("\t     * * * *         * * * *   \n");
	printf("\t    * * * *           * * * *    \n");
	printf("\t  * * * * *           * * * * *    \n");
	printf("\t* * * * * *           * * * * * *    \n\n");
    
    //R
	printf("\t       * * * * * *                    \n");
	printf("\t       *          *                \n");
	printf("\t       *         *                \n");
	printf("\t       *        *                \n");
	printf("\t       *       *                \n");
	printf("\t       *      *                \n");
	printf("\t       *    *                \n");
	printf("\t       * * *                \n");
	printf("\t       *    *                \n");
	printf("\t       *     *                \n");
	printf("\t       *      *                \n");
	printf("\t       *        *                \n");
	printf("\t       *          *                \n");
	printf("\t       *            *                \n");
	
	printf("\t       *                    \n\n");
	
	//I
	printf("\t       * * * ** * * *                    \n");
	printf("\t              *          \n");
	printf("\t              *          \n");
	printf("\t              *          \n");
	printf("\t              *          \n");
	printf("\t              *          \n");
	printf("\t              *                 \n");
	printf("\t              *                     \n");
	printf("\t              *                         \n");
	printf("\t              *                    \n");    printf("\t       * * * ** * * *                    \n\n");
	
	//A
	printf("\t              *          \n");
	printf("\t             *  *        \n");
	printf("\t            *     *       \n");
	printf("\t           *        *       \n");
	printf("\t        * * * * * * * * *    \n");
	printf("\t     * * * *         * * * *   \n");
	printf("\t    * * * *           * * * *    \n");
	printf("\t  * * * * *           * * * * *    \n");
	printf("\t* * * * * *           * * * * * *    \n");
	
}
int main()
{
	printName();
}