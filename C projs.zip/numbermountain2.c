#include "stdio.h"

int main() {
    for (int i=1; i<=10; i++) {
        for (int j=15; j>i; j--) {
            printf(" ");
        }
        for (int k=1; k<=i; k++) printf("%d ", k);
        printf("\n");
    }
}