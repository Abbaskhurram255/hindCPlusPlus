#include <stdio.h>

int main()
{
    int attendance[4][6] = {{1, 0, 1, 1, 0, 0}, {1, 0, 1, 0, 1, 1}, {0, 0, 1, 0, 1, 1}, {1, 1, 0, 0, 1, 0}};
    int absence = 0, presence = 0;
    int size = sizeof(attendance)/sizeof(attendance[0]);
    for (int i=0; i<size; i++) {
        for (int j=0; j<sizeof(attendance[i])/sizeof(attendance[i][0]); j++) {
            if (attendance[i][j]) presence += 1;
            else absence += 1;
        }
    }
    int okay = 0;
    if (presence > 22) okay = 1;
    printf("Presence: %d days\nAbsence: %d days\nIs it okay to take a day off? %s", presence, absence, okay ? "Okay" : "No!");
}