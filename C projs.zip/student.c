#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
typedef struct {
	int rollno, percentage, marksObtained;
	char* name;
	char* grade;
	bool pass;
} student;
student new_student(char* name, int marksObtained, int rollno) {
	student student;
    student.name = name;
	student.rollno = rand()%9999;
	/*
	if (marksObtained > 5000) {
		marksObtained = 0;
		return student;
	}
	*/
	student.marksObtained = marksObtained;
	int marksRequiredToPass = 800;
	float score = student.marksObtained/marksRequiredToPass*100;
	//printf("%.1f", score);
	if (score >= 90) student.grade = "A1";
	else if (score >= 80) student.grade = "A-plus";
	else if (score >= 70) student.grade = "A";
	else if (score >= 60) student.grade = "B";
	else if (score >= 50) student.grade = "C";
	else if (score >= 40) student.grade = "D";
	else if (score >= 33) student.grade = "E";
	else student.grade = "F";
	return student;
}
void display(const char *args, ...) {
	printf(args);
	printf("\n");
}
int main(int argc, char *argv[])
{
	student student1, student2;
	student1 = new_student("Khurram Ali", 570, 0);
	student2 = new_student("Kamran Ali", 413, 0);
	display("---\nName: %s\nRoll no: %i\nMarks Acquired: %i\nGrade: %s\n---", student1.name, student1.rollno, student1.marksObtained, student1.grade);
	//display("%s", student2.name);
}