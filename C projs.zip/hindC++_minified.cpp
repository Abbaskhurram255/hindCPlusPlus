#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <cstring>
#include <stdbool.h>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include <iostream>
#include <algorithm>
#define SkrXiXGu namespace
#define f6a6mdFj =
#define A3xRaAfu lafz
#define GZlQRPQw bool;
#define CNHaJrvc jumlo
#define QTvhD7OB std;
#define LXOfEhJm flt
#define DJ8Qx91d char;
#define CdT2gPIh lafz;
#define ZSeBQjB2 ch
#define TZs5ckVo char*;
#define LfDBPvxM dbl
#define m6R4bW4M jumla
#define Ws15bcZm nr
#define wYbt6o7O str
#define hd55R1aq float;
#define RciQHUoq nr;
#define RNNPvTmh jumla;
#define fPYJ7Rd7 double;
#define aEUuP2Ml using
#define X8G30xhP haal
aEUuP2Ml SkrXiXGu QTvhD7OB aEUuP2Ml m6R4bW4M f6a6mdFj TZs5ckVo aEUuP2Ml CNHaJrvc f6a6mdFj RNNPvTmh 
aEUuP2Ml A3xRaAfu f6a6mdFj RNNPvTmh aEUuP2Ml wYbt6o7O f6a6mdFj CdT2gPIh aEUuP2Ml Ws15bcZm f6a6mdFj 
fPYJ7Rd7 aEUuP2Ml LfDBPvxM f6a6mdFj RciQHUoq aEUuP2Ml LXOfEhJm f6a6mdFj hd55R1aq aEUuP2Ml ZSeBQjB2 
f6a6mdFj DJ8Qx91d aEUuP2Ml X8G30xhP f6a6mdFj GZlQRPQw 
#define out std::cout <<
#define farmaiye out
#define or_farmaiye out
#define farmao out
#define or_farmao out
#define keh out
#define or_keh out
#define kahie out
#define or_kahie out
#define kahen out
#define or_kahen out
#define bolie out
#define or_bolie out
#define bolen out
#define or_bolen out
#define farmayo out
#define aen_farmayo out
#define farmae out
#define aen_farmae out
#define chao out
#define aen_chao out
#define chau out
#define aen_chau out
#define ke "" <<
#define yar "" <<
#define or_yar << " " <<
#define aen_yar << " " <<
#define aur << " " <<
#define aen << " " <<
#define aage << " " <<
#define agya << " " <<
#define or_age << " " <<
#define aen_agya << " " <<
#define or_aage << " " <<
#define aen_agyo << " " <<
#define bas endl
#define or_bas or_age bas
#define age_bas or_bas
#define aage_bas or_bas
#define bas_re or_bas
#define aen_bas aen_agya bas
#define agya_bas aen_bas
#define agyo_bas aen_bas
#define akhir_me aen_bas
#define falaana ""
#define falaano ""
#define falaani ""
#define yes true
#define sach true
#define han true
#define hau true
#define no false
#define jhoot false
#define koor false
#define na false
#define nahi == false
#define nahe == false
#define na_ahe == false
#define agar_sach == true
#define agar_jhoot ""
#define agar_koor ""
#define nata_wari ""
#define bana =
#define bani =
#define bane =
#define be =
#define is_now =
#define ab =
#define ab_he =
#define hare =
#define hare_ahe =
#define he_ab =
#define ahe_hare
#define into =
#define exchange swap
#define hera_pheri swap
#define adla_badli swap
#define exists !!
#define mojood !!
#define sath ,
#define gad ,
#define gaddu ,
#define or_sath &&
#define or_to_or &&
#define aur_to_aur &&
#define aen_gad &&
#define aen_ta_aen &&
#define gado_gad &&
#define par &&
#define para &&
#define karo do
#define kar do
#define ye {
#define hee {
#define sab }
#define jabtak while (
#define jesitae while (
#define jasitore while (
#define tabtak {
#define tesitae {
#define tesitore {
#define then {
#define to {
#define ta {
#define tab {
#define tadhen {
#define abbas }
#define hare_bas }
#define basab }
#define bas_hare }
#define khatm }
#define khatam }
#define ant }
#define ruko break
#define skip continue
#define phere for (
#define phera for (
#define jab_tak true&&
#define jesi_tae true&&
#define jesi_tore true&&
#define har for (
#define ek auto
#define each for (auto
#define har_ek for (auto
#define harEk for (auto
#define for_each for (auto
#define forEach for (auto
#define from :
#define jo_hissa :
#define jeko_hisso :
#define jeki_hisso :
#define ka_he ) {
#define ki_he ) {
#define jo_ahe ) {
#define ke_lie ) {
#define lae ) {
#define je_lae ) {
#define karie )
#define keejye )
#define kario )
#define kayo )
#define kajo )
#define ka )
#define ko )
#define jo )
#define khe )
#define of (
#define or_run {
#define or_karo {
#define aen_kar {
#define agar if (
#define cha if (
#define he )
#define hen )
#define ahe )
#define ahin )
#define nahi_to_agar } else if (
#define nahi_to } else {
#define nata_agar } else if (
#define nata } else {
#define agar_koi_na } else {
#define agar_sab_galat } else {
#define me_izafa +=
#define me_dalo +=
#define me_dala +=
#define me_barha +=
#define me_barhao +=
#define me_gaya +=
#define me_ghata -=
#define me_ghatao -=
#define se_gaya -=
#define se_ghata -=
#define se_ghatao -=
#define me_izafo +=
#define me_wij +=
#define me_wadhae +=
#define me_wadhio +=
#define me_wadhaiyo +=
#define me_wayo +=
#define me_ghatio -=
#define me_ghaato -=
#define me_ghato -=
#define kha_wayo -=
#define kha_ghatio -=
#define kha_ghataiyo -=
#define kha_ghatae -=
#define ma_wayo -=
#define ma_ghatio -=
#define ma_ghaato -=
#define ma_ghatyo -=
#define ma_ghataiyo -=
#define ma_ghatae -=
#define ma_kad -=
#define ma_kaddu -=
#define ma_wanyan -=
#define ma_nikto -=
#define ma_nikta -=
#define ma_nikre -=
#define ma_nikriya -=
#define ma_nikran -=
#define kha_nikto -=
#define kha_nikta -=
#define kha_nikre -=
#define kha_nikriya -=
#define kha_nikran -=
#define kha_wayo -=
#define kha_kad -=
#define kha_kaddu -=
#define koshish try
#define rukawat catch (...)
#define na_kami catch (...)
#define newError throw
#define nayaError throw
#define halat switch (
#define haalat switch (
#define ki ) {
#define wari ) {
#define surat case
#define basurat case
#define barabar =
#define me :
#define is ==
#define wakai_barabar ==
#define nahi_barabar !=
#define na_barabar !=
#define zyada_ya_barabar >=
#define gharo_ya_barabar >=
#define ghano_ya_barabar >=
#define ghara_ya_barabar >=
#define ghana_ya_barabar >=
#define bara_ya_barabar >=
#define wado_ya_barabar >=
#define bare_ya_barabar >=
#define wada_ya_barabar >=
#define kam_ya_barabar <=
#define ghat_ya_barabar <=
#define chota_ya_barabar <=
#define nandho_ya_barabar <=
#define nandhro_ya_barabar <=
#define chote_ya_barabar <=
#define nandha_ya_barabar <=
#define nandhra_ya_barabar <=
#define se_bara <
#define se_bare <
#define se_bari <
#define se_chota >
#define se_chote >
#define se_choti >
#define kha_wado <
#define kha_wada <
#define kha_wadi <
#define kha_gharo <
#define kha_ghano <
#define kha_ghara <
#define kha_ghana <
#define kha_ghari <
#define kha_ghani <
#define kha_nandho >
#define kha_nandhro >
#define kha_nandha >
#define kha_nandhra >
#define kha_nandhi >
#define kha_nandhri >
#define se )
#define kha )
#define ma )
#define mau )
#define var auto
#define let auto
#define fn auto
#define func auto
#define farz auto
#define mano auto
#define re ;
#define ri ;
#define love ;
#define pyari ;
#define ji ;
#define object typedef struct
#define Object typedef struct
#define on int main() {
#define off }
#define shuru int main() {
#define shurwat int main() {
#define hind int main() {
#define sind int main() {
#define C }
#define co int main() {
#define de }
#define aye int main() {
#define sha }
#define haare ;std::cout<<"";
#define je ;std::cout<<"";
#define set ;std::cout<<"";
#define hua ;std::cout<<"";
#define hui ;std::cout<<"";
#define hue ;std::cout<<"";
#define aap ;std::cout<<"";
#define tum ;std::cout<<"";
#define tu ;std::cout<<"";
#define tussi ;std::cout<<"";
#define larki ;std::cout<<"";
#define chori ;std::cout<<"";
#define behen ;std::cout<<"";
#define behna ;std::cout<<"";
#define baji ;std::cout<<"";
#define didi ;std::cout<<"";
#define kuri ;std::cout<<"";
#define kurio ;std::cout<<"";
#define kurie ;std::cout<<"";
#define yara ;std::cout<<"";
#define yaara ;std::cout<<"";
#define tawheen ;std::cout<<"";
#define tawhan ;std::cout<<"";
#define adi ;std::cout<<"";
#define bhen ;std::cout<<"";
#define penji ;std::cout<<"";
#define aap ;std::cout<<"";
#define bhau ;std::cout<<"";
#define pagli ;std::cout<<"";
#define ba ;std::cout<<"";
#define baba ;std::cout<<"";
#define meri_jan ;std::cout<<"";
#define ayesha ;std::cout<<"";
#if defined __has_include
#if __has_include (<conio.h>)
#include <conio.h>
#define XcdlAfww kaaro
#define hoN3k9oQ gaaro,
#define GsIHUDgo saao
#define Y2DZSSah yellow
#define pZpZ1s84 sufed,
#define gX3WjrP0 _def
#define AUYs5rYJ asmaani;
#define c8WpCfbT clrscr();
#define gj5nNrHE kala
#define VU9MwMLP backgr(int
#define jGB0MpVO red,
#define BCAss1WG bg(int
#define obXU7Z29 saao,
#define NwTYR0Pk WHITE,
#define k8n2kLRQ shurwati
#define maK9qrJi textbackground(new_bg_color);
#define gKG8k3e0 YELLOW,
#define hA69gWhw blue,
#define xMAub0qX safed
#define ATu76haZ white,
#define hMVpFAQT cyan;
#define UmH5n27L black,
#define Yh0tT2OH kaala,
#define kXmql0Ma nira
#define gFHIxw52 niro,
#define khWRVyMv }
#define pJDFqOQS blue
#define viWiRscD kala,
#define aYN2k77W yellow,
#define SYQwGMPq acho,
#define qeMl7DA4 red
#define hZSDkgw1 textcolor(new_color);
#define xU5yZP3Z green,
#define ykLT6EVh int
#define BlryocRQ shurwati,
#define ncbVhZZt sufed
#define Yr4YOlVJ void
#define m8vYmkGu BLUE,
#define EXVop0wa niro
#define BFL4xpoG peelo,
#define RA2DVLhc samandari
#define y7em51ZZ kaala
#define EJ1C02to cyan
#define vASPE4VN safed,
#define okbUiLnQ gaaro
#define KiQwNUI9 peelo
#define Q6Fo2rkx RED,
#define N8ZOjuif lal
#define A0Ni6gGb CYAN;
#define wCsk4KBP acho
#define xQyo9WuK laal,
#define QBxoKmq4 laal
#define MANpP4tl BLACK,
#define U8o1dhdf green
#define LJ9D1C3B asmaani
#define PLRXE4Kq peela,
#define jgU0qeOK cls()
#define tT8QSC3C neera,
#define sTtfUSI0 new_bg_color)
#define OD7HJ62G lal,
#define b4EuyvOq clr(int
#define CEaiQArf {
#define cNYlePX2 samandari;
#define x8e9lsui cyan,
#define ACT0RkhX neero
#define bNkiPsJm _def,
#define G50naald neera
#define nZAqFdVP hara
#define nSTepHTy neero,
#define b3icxQaO new_color)
#define eFrLqWM7 white
#define LMLXkXM0 hara,
#define SE2dbgvA peela
#define egO59A3q kaaro,
#define dG37Yvf9 recognize_colors()
#define w7a7tVG1 GREEN,
#define bL8DweT0 bgclr(int
#define V6JVLUwM nira,
#define U0fDUuk1 black
ykLT6EVh U0fDUuk1 f6a6mdFj MANpP4tl qeMl7DA4 f6a6mdFj 
Q6Fo2rkx Y2DZSSah f6a6mdFj gKG8k3e0 U8o1dhdf f6a6mdFj 
w7a7tVG1 pJDFqOQS f6a6mdFj m8vYmkGu eFrLqWM7 f6a6mdFj 
NwTYR0Pk EJ1C02to f6a6mdFj A0Ni6gGb ykLT6EVh viWiRscD 
Yh0tT2OH OD7HJ62G xQyo9WuK PLRXE4Kq LMLXkXM0 V6JVLUwM 
tT8QSC3C pZpZ1s84 vASPE4VN BlryocRQ bNkiPsJm cNYlePX2 
ykLT6EVh egO59A3q hoN3k9oQ BFL4xpoG obXU7Z29 gFHIxw52 
nSTepHTy SYQwGMPq AUYs5rYJ Yr4YOlVJ dG37Yvf9 CEaiQArf 
gj5nNrHE f6a6mdFj y7em51ZZ f6a6mdFj UmH5n27L N8ZOjuif 
f6a6mdFj QBxoKmq4 f6a6mdFj jGB0MpVO SE2dbgvA f6a6mdFj 
aYN2k77W nZAqFdVP f6a6mdFj xU5yZP3Z kXmql0Ma f6a6mdFj 
G50naald f6a6mdFj hA69gWhw xMAub0qX f6a6mdFj ncbVhZZt 
f6a6mdFj k8n2kLRQ f6a6mdFj gX3WjrP0 f6a6mdFj ATu76haZ 
RA2DVLhc f6a6mdFj x8e9lsui XcdlAfww f6a6mdFj UmH5n27L 
okbUiLnQ f6a6mdFj jGB0MpVO KiQwNUI9 f6a6mdFj aYN2k77W 
GsIHUDgo f6a6mdFj xU5yZP3Z EXVop0wa f6a6mdFj ACT0RkhX 
f6a6mdFj hA69gWhw wCsk4KBP f6a6mdFj k8n2kLRQ f6a6mdFj 
gX3WjrP0 f6a6mdFj ATu76haZ LJ9D1C3B f6a6mdFj hMVpFAQT 
khWRVyMv Yr4YOlVJ b4EuyvOq b3icxQaO CEaiQArf hZSDkgw1 
khWRVyMv Yr4YOlVJ BCAss1WG sTtfUSI0 CEaiQArf maK9qrJi 
khWRVyMv Yr4YOlVJ bL8DweT0 sTtfUSI0 CEaiQArf maK9qrJi 
khWRVyMv Yr4YOlVJ VU9MwMLP sTtfUSI0 CEaiQArf maK9qrJi 
khWRVyMv Yr4YOlVJ jgU0qeOK CEaiQArf c8WpCfbT khWRVyMv 
#endif
#endif
#define len strlen
#define lambai strlen
#define arrlen(arr) (sizeof(arr) / sizeof(arr[0]))
#define QTmhV27O void
#define lUXdPJNo char
#define PSsxshPD }
#define tfqgG1Bs ...)
#define monDb1fj print(const
#define dfxsDMlD {
#define nVhyZ3Ps print_inline(const
#define w5KC3pLX *args,
#define iVcBNuRd printf("\n");
#define p6xPXqxR printf("%s", args);
QTmhV27O monDb1fj lUXdPJNo w5KC3pLX tfqgG1Bs dfxsDMlD p6xPXqxR iVcBNuRd PSsxshPD QTmhV27O nVhyZ3Ps lUXdPJNo 
w5KC3pLX tfqgG1Bs dfxsDMlD p6xPXqxR PSsxshPD 
#define print_nobr print_inline
#define print_sameln print_inline
#define printStr print
#define printStrInline print_inline
#define kaho print
#define kaho_inline print_inline
#define kaho_nobr print_inline
#define kaho_sameln print_inline
#define tjgg9GYT printf("%i", args);
#define dG2NpvHC args,
#define LWpwTeQp int
#define mBrYxsVh print_i(const
#define jC25aJIv print_i_inline(const
QTmhV27O mBrYxsVh LWpwTeQp dG2NpvHC tfqgG1Bs dfxsDMlD tjgg9GYT iVcBNuRd PSsxshPD 
QTmhV27O jC25aJIv LWpwTeQp dG2NpvHC tfqgG1Bs dfxsDMlD tjgg9GYT PSsxshPD 
#define print_i_nobr print_i_inline
#define print_i_sameln print_i_inline
#define printInt print_i
#define printIntInline print_i_inline
#define kaho_i print_i
#define kaho_i_inline print_i_inline
#define kaho_i_nobr print_i_inline
#define kaho_i_sameln print_i_inline
#define qbFvWhli printf("%.1f", args);
#define g6EOqMtr print_f(const
#define iPSJvYNF print_f_inline(const
#define NsnnPxFq float
QTmhV27O g6EOqMtr NsnnPxFq dG2NpvHC tfqgG1Bs dfxsDMlD qbFvWhli iVcBNuRd PSsxshPD QTmhV27O iPSJvYNF NsnnPxFq dG2NpvHC 
tfqgG1Bs dfxsDMlD qbFvWhli PSsxshPD 
#define print_f_nobr print_f_inline
#define print_f_sameln print_f_inline
#define printFlt print_f
#define printFltInline print_f_inline
#define kaho_f print_f
#define kaho_f_inline print_f_inline
#define kaho_f_nobr print_f_inline
#define kaho_f_sameln print_f_inline
#define print_n print_f
#define print_n_inline print_f_inline
#define print_n_nobr print_f_inline
#define print_n_sameln print_f_inline
#define printN print_f
#define printNInline print_f_inline
#define kaho_n print_f
#define kaho_n_inline print_f_inline
#define kaho_n_nobr print_f_inline
#define kaho_n_sameln print_f_inline
#define JsJ69LyD printf("%s", !args ? "false" : "true");
#define XvxGMLu7 print_b(const
#define ITvfkP1p print_b_inline(const
QTmhV27O XvxGMLu7 LWpwTeQp dG2NpvHC tfqgG1Bs dfxsDMlD JsJ69LyD iVcBNuRd PSsxshPD QTmhV27O ITvfkP1p LWpwTeQp dG2NpvHC tfqgG1Bs dfxsDMlD 
JsJ69LyD PSsxshPD 
#define print_b_nobr print_b_inline
#define print_b_sameln print_b_inline
#define printBool print_b
#define printBoolInline print_b_inline
#define kaho_b print_b
#define kaho_b_inline print_b_inline
#define kaho_b_nobr print_b_inline
#define kaho_b_sameln print_b_inline
#define kFrOUJGr string
#define pLvlTaLb x;
#define OgBplH6A std::cin
#define l0KP5c0t returnValue;
#define vC0Hpy4n std::string
#define A2JJZmxH return
#define RVjN2mBm puchoWord(string
#define VlOZONSQ x)
#define W8Aj4T1v std::cout
#define qSMvh2NF <<
#define FvKHSYNF returnValue
#define ioL9ef5P >>
#define HIWfhxS0 "";
kFrOUJGr RVjN2mBm VlOZONSQ dfxsDMlD vC0Hpy4n FvKHSYNF f6a6mdFj HIWfhxS0 W8Aj4T1v qSMvh2NF pLvlTaLb OgBplH6A 
ioL9ef5P l0KP5c0t A2JJZmxH l0KP5c0t PSsxshPD 
#define puchoLafz puchoWord
#define puchLafz puchoWord
#define puchWord puchoWord
#define puchuLafz puchoWord
#define puchuWord puchoWord
#define sw9w2O0c pucho(string
#define jqooiaA4 returnValue);
#define RHgqjY4N getline(std::cin,
kFrOUJGr sw9w2O0c VlOZONSQ dfxsDMlD vC0Hpy4n FvKHSYNF f6a6mdFj HIWfhxS0 W8Aj4T1v qSMvh2NF pLvlTaLb RHgqjY4N jqooiaA4 A2JJZmxH 
l0KP5c0t PSsxshPD 
#define puch pucho
#define askline pucho
#define saveline pucho
#define askWord puchoWord
#define XFH0go1F y
#define I5WQZEGA printf("\n%s\n", x);
#define JZKN4o6N pucho_f(char
#define sEqrGNEc scanf("%i", &y);
#define kyk8EVWG scanf("%f", &y);
#define eLORH483 *x)
#define TCL9kocg pucho_c(char
#define BJcPGExy y;
#define WGUu4cgY pucho_i(char
#define h04smGYE 0;
#define sSJYHmeg scanf("%s", &y);
LWpwTeQp WGUu4cgY eLORH483 dfxsDMlD LWpwTeQp XFH0go1F f6a6mdFj h04smGYE I5WQZEGA 
sEqrGNEc A2JJZmxH BJcPGExy PSsxshPD lUXdPJNo TCL9kocg eLORH483 dfxsDMlD lUXdPJNo 
BJcPGExy I5WQZEGA sSJYHmeg A2JJZmxH BJcPGExy PSsxshPD NsnnPxFq JZKN4o6N eLORH483 
dfxsDMlD NsnnPxFq XFH0go1F f6a6mdFj h04smGYE I5WQZEGA kyk8EVWG A2JJZmxH BJcPGExy 
PSsxshPD 
#define puch_i pucho_i
#define puch_c pucho_c
#define puch_f pucho_f
#define puchu_i pucho_i
#define puchu_c pucho_c
#define puchu_f pucho_f
#define X8ONWa4e pucho_c(x);
#define qyhcc973 pucho_i(x);
#define fTJN6bXl puchoCh(char
#define g8diNtag puchoFlt(char
#define Q2sVc18e puchoInt(char
#define Hei1xyKZ pucho_f(x);
LWpwTeQp Q2sVc18e eLORH483 dfxsDMlD A2JJZmxH 
qyhcc973 PSsxshPD lUXdPJNo fTJN6bXl eLORH483 
dfxsDMlD A2JJZmxH X8ONWa4e PSsxshPD NsnnPxFq 
g8diNtag eLORH483 dfxsDMlD A2JJZmxH Hei1xyKZ 
PSsxshPD 
#define puchInt puchoInt
#define puchCh puchoCh
#define puchFlt puchoFlt
#define scan pucho
#define scanWord puchoWord
#define wiKsAJ8O scan_i(char
#define JuPFDVxN scan_f(char
#define sLGOK1IY scan_c(char
LWpwTeQp wiKsAJ8O eLORH483 dfxsDMlD A2JJZmxH qyhcc973 PSsxshPD lUXdPJNo 
sLGOK1IY eLORH483 dfxsDMlD A2JJZmxH X8ONWa4e PSsxshPD NsnnPxFq JuPFDVxN 
eLORH483 dfxsDMlD A2JJZmxH Hei1xyKZ PSsxshPD 
#define ask pucho
#define askWord puchoWord
#define uooD4Din <
#define UNKkh1CQ (int
#define X6Fu3svq (;
#define fvyqODFd printf("%.1f", h);
#define kpB4YLWa n--)
#define K4RwGtsq repeat_b(int
#define vJgHo8RH print_inline("%s", !h ? "false" : "true");
#define k7WFOMIK i++)
#define NgPXS7pm repeat_i_inline(int
#define QufD6Bgh ask_c(char
#define dG5n0nqA for
#define CmxZ6pki ask_i(char
#define gshrREIG print_inline("%.1f", h);
#define cyOci3Cv n;
#define sg7U9y2D linechoro(1);
#define APetmjBa askint(char
#define sRTQhWBT printf("%i", h);
#define gSbluaEi repeat(char
#define Q0c5BqVG print_inline("%i", h);
#define uP9YWqA5 br(int
#define HXV9capG agline()
#define pnQ14658 cout
#define bwhTZTWj h,
#define TfXGkGX8 repeat_f_inline(float
#define ISGwMwDf askch(char
#define muJ3ugN6 n)
#define WmXyYE3e tb(int
#define bOGajn3U j;
#define xbdHEIo9 repeat_f(float
#define eHDEPsJn repeat_inline(char
#define Z9Nn13Q8 ask_f(char
#define EysHZ3DA endl;
#define mafwLDuh repeat_b_inline(int
#define U8JwaqZi printf("\t");
#define tSKRfwDG kaho(h);
#define GEohdfSE linechoro(int
#define TEGngHFR j)
#define Tb9wfKA2 linechoro(n);
#define xKBoKRbv *h,
#define NkjyOuAd repeat_i(int
#define Px7NB5TF print_inline(h);
#define enbKBy0G printf("%s", !h ? "false" : "true");
#define hNrG30qq askflt(char
#define r5FVjltx i
LWpwTeQp CmxZ6pki eLORH483 dfxsDMlD 
A2JJZmxH qyhcc973 PSsxshPD lUXdPJNo 
QufD6Bgh eLORH483 dfxsDMlD A2JJZmxH 
X8ONWa4e PSsxshPD NsnnPxFq Z9Nn13Q8 
eLORH483 dfxsDMlD A2JJZmxH Hei1xyKZ 
PSsxshPD LWpwTeQp APetmjBa eLORH483 
dfxsDMlD A2JJZmxH qyhcc973 PSsxshPD 
lUXdPJNo ISGwMwDf eLORH483 dfxsDMlD 
A2JJZmxH X8ONWa4e PSsxshPD NsnnPxFq 
hNrG30qq eLORH483 dfxsDMlD A2JJZmxH 
Hei1xyKZ PSsxshPD QTmhV27O GEohdfSE 
muJ3ugN6 dfxsDMlD dG5n0nqA X6Fu3svq 
cyOci3Cv kpB4YLWa pnQ14658 qSMvh2NF 
EysHZ3DA PSsxshPD QTmhV27O HXV9capG 
dfxsDMlD sg7U9y2D PSsxshPD QTmhV27O 
uP9YWqA5 muJ3ugN6 dfxsDMlD Tb9wfKA2 
PSsxshPD QTmhV27O WmXyYE3e muJ3ugN6 
dfxsDMlD dG5n0nqA UNKkh1CQ r5FVjltx 
f6a6mdFj h04smGYE r5FVjltx uooD4Din 
cyOci3Cv k7WFOMIK U8JwaqZi PSsxshPD 
QTmhV27O gSbluaEi xKBoKRbv LWpwTeQp 
TEGngHFR dfxsDMlD dG5n0nqA UNKkh1CQ 
r5FVjltx f6a6mdFj h04smGYE r5FVjltx 
uooD4Din bOGajn3U k7WFOMIK tSKRfwDG 
PSsxshPD QTmhV27O eHDEPsJn xKBoKRbv 
LWpwTeQp TEGngHFR dfxsDMlD dG5n0nqA 
UNKkh1CQ r5FVjltx f6a6mdFj h04smGYE 
r5FVjltx uooD4Din bOGajn3U k7WFOMIK 
Px7NB5TF PSsxshPD QTmhV27O xbdHEIo9 
bwhTZTWj LWpwTeQp TEGngHFR dfxsDMlD 
dG5n0nqA UNKkh1CQ r5FVjltx f6a6mdFj 
h04smGYE r5FVjltx uooD4Din bOGajn3U 
k7WFOMIK fvyqODFd PSsxshPD QTmhV27O 
TfXGkGX8 bwhTZTWj LWpwTeQp TEGngHFR 
dfxsDMlD dG5n0nqA UNKkh1CQ r5FVjltx 
f6a6mdFj h04smGYE r5FVjltx uooD4Din 
bOGajn3U k7WFOMIK gshrREIG PSsxshPD 
QTmhV27O NkjyOuAd bwhTZTWj LWpwTeQp 
TEGngHFR dfxsDMlD dG5n0nqA UNKkh1CQ 
r5FVjltx f6a6mdFj h04smGYE r5FVjltx 
uooD4Din bOGajn3U k7WFOMIK sRTQhWBT 
PSsxshPD QTmhV27O NgPXS7pm bwhTZTWj 
LWpwTeQp TEGngHFR dfxsDMlD dG5n0nqA 
UNKkh1CQ r5FVjltx f6a6mdFj h04smGYE 
r5FVjltx uooD4Din bOGajn3U k7WFOMIK 
Q0c5BqVG PSsxshPD QTmhV27O K4RwGtsq 
bwhTZTWj LWpwTeQp TEGngHFR dfxsDMlD 
dG5n0nqA UNKkh1CQ r5FVjltx f6a6mdFj 
h04smGYE r5FVjltx uooD4Din bOGajn3U 
k7WFOMIK enbKBy0G PSsxshPD QTmhV27O 
mafwLDuh bwhTZTWj LWpwTeQp TEGngHFR 
dfxsDMlD dG5n0nqA UNKkh1CQ r5FVjltx 
f6a6mdFj h04smGYE r5FVjltx uooD4Din 
bOGajn3U k7WFOMIK vJgHo8RH PSsxshPD 
#define duhrao repeat
#define duhrao_inline repeat_inline
#define duhrao_i repeat_i
#define duhrao_i_inline repeat_i_inline
#define duhrao_f repeat_f
#define duhrao_f_inline repeat_f_inline
#define duhrao_b repeat_b
#define duhrao_b_inline repeat_b_inline
#define duhrae duhrao
#define duhrae_inline duhrao_inline
#define duhrae_i duhrao_i
#define duhrae_i_inline duhrao_i_inline
#define duhrae_f duhrao_f
#define duhrae_f_inline duhrao_f_inline
#define duhrae_b duhrao_b
#define duhrae_b_inline duhrao_b_inline
#define my484KR1 s[j]
#define gaGd6w5H *str,
#define KmphXyRx k;
#define RXXSxygO "");
#define Ib4QMtG3 *keepLast(char
#define LAl6T9Rb j--)
#define eeQmfpRM with);
#define ARJt0ftF const
#define bGCL5Qtl if
#define PB0e5irO '\0';
#define Z1AY2Xmg i;
#define epMQxhex strappend(char
#define plsjKn64 end);
#define MYFJv1Dw *trim(char
#define CNfy6EPG result[i]
#define XnWdKmr3 s[i]
#define MaDQhHOx result[max
#define kYy3dcq8 max;
#define oFOXE2sQ s[l]
#define GOJxd8xu '0';
#define HEup60Md sizeof(ALLOWED)
#define Grnl1W21 end;
#define A1ryEDTD rand()
#define Bnu1bZ5P start++,
#define VActIhdZ nbAllowed;
#define ubqLLOw1 *org
#define qFhPHWSj *a,
#define nSo5JgBj *result
#define rbebj9HO strcpy(str,
#define tSvA8lbr slice(result,
#define jIpK7Wdo strlen(s)
#define LTfHMZGi c
#define WAdJQS2m start,
#define fwoNbg9l end)
#define e0NXtOen strtok(NULL,
#define OAQXqKB6 size
#define T2oZphrr j
#define c5hKydW6 strtok(str,
#define LOQc3evd reverseStr(s);
#define eRA1qEk1 n,
#define Rh8SXuy9 ((n
#define Igl69J4W s[l
#define qyRm6qNB -
#define Gwk0SrWQ slice(str,
#define N5dnVBjC (i
#define Nj3uUVwZ -n;
#define AQymmx3q 800;
#define pjcoD0m2 10
#define UJtW5pZR nbAllowed
#define u4OV0H0y 10)
#define c7j8Msrk "abcdefghijklmnopqrstuvwxyz1234567890";
#define ntFhNlop org);
#define sWFqmfwu /=
#define ds8tI79B >
#define munW3q0V 1]
#define hR1xuB9l strlen(str);
#define haMp1fPR c;
#define EDKbAEVA 0)
#define Edt8yg6y sign;
#define P2xfomIM start;
#define j0f6ceIa *keepAfter(char
#define J28ivlBZ token
#define SsAtOIB4 len)
#define k1AAGmiV 1;
#define JYIiEAPA strlen(s);
#define oAnqiGE1 *token;
#define k1uBEHLK l
#define sYDjSOlY *slice(char
#define B9JTwEae *with)
#define MgsystQI ALLOWED[c];
#define wJxPg2MF (sign
#define J4PAD4P3 0,
#define mEeFXu3p *str)
#define Z9aYLcS1 len);
#define JWrvSfp9 toupper(str[i]);
#define KuUGjhuQ ((sign
#define ap42i0Vy i,
#define o2oxFI5i i++,
#define Q391khPk end
#define kjU8vBH0 %
#define h28GH05i do
#define ZLDeos4X srand(time(NULL));
#define Du200em2 output;
#define QZwVLXAQ (char
#define YDwAYtkY 0);
#define EwHInOSS c)
#define BoshkMmH max
#define NQHdA2UY *output
#define jkBIgVIi *upper(char
#define yAGAIrCq result;
#define sWXdnJam ALLOWED[]
#define tqRZw8Hq start
#define xliUcIXZ reverseStr(char
#define a40vBLWg *s,
#define Y3GkdNXc *randstr(int
#define vIRhqrYB while
#define gvpLabCK s[j];
#define hbSI21nK output[i]
#define uectrQ2S *b)
#define GW4EFV6X '-';
#define KC44Ot2o n
#define PjeXcDos k
#define yuwRXLfQ str[start];
#define jiYdfSXR output[size]
#define NAR5SA8A strstr(a,
#define C35pbRo3 +
#define ZYmoWkJV *
#define rroXb2A8 b);
#define RIv5Bqoy str;
#define cnuoeu5q 1];
#define MbF4DCJ5 <=
#define SSlG3MPR itoa(int
#define M97gD6GR str[i]
#define w6MNUW40 s[])
#define gaHPTqIC s[i++]
#define JIpSxeqY *keepFirst(char
#define dMq7BcKb s[i];
#define sNATs5DY *)malloc(size
#define YJ9TvlN1 sizeof(char));
lUXdPJNo JIpSxeqY gaGd6w5H lUXdPJNo B9JTwEae dfxsDMlD lUXdPJNo ubqLLOw1 
f6a6mdFj RIv5Bqoy lUXdPJNo nSo5JgBj f6a6mdFj c5hKydW6 eeQmfpRM rbebj9HO 
RXXSxygO rbebj9HO ntFhNlop A2JJZmxH yAGAIrCq PSsxshPD lUXdPJNo Ib4QMtG3 
gaGd6w5H lUXdPJNo B9JTwEae dfxsDMlD lUXdPJNo oAnqiGE1 J28ivlBZ f6a6mdFj 
c5hKydW6 eeQmfpRM lUXdPJNo nSo5JgBj f6a6mdFj J28ivlBZ f6a6mdFj e0NXtOen 
eeQmfpRM A2JJZmxH yAGAIrCq PSsxshPD lUXdPJNo j0f6ceIa qFhPHWSj lUXdPJNo 
uectrQ2S dfxsDMlD lUXdPJNo nSo5JgBj f6a6mdFj NAR5SA8A rroXb2A8 A2JJZmxH 
yAGAIrCq PSsxshPD lUXdPJNo sYDjSOlY gaGd6w5H LWpwTeQp WAdJQS2m LWpwTeQp 
fwoNbg9l dfxsDMlD LWpwTeQp Z1AY2Xmg LWpwTeQp OAQXqKB6 f6a6mdFj Q391khPk 
qyRm6qNB P2xfomIM lUXdPJNo NQHdA2UY f6a6mdFj QZwVLXAQ sNATs5DY ZYmoWkJV 
YJ9TvlN1 dG5n0nqA N5dnVBjC f6a6mdFj h04smGYE tqRZw8Hq MbF4DCJ5 Grnl1W21 
Bnu1bZ5P k7WFOMIK dfxsDMlD hbSI21nK f6a6mdFj yuwRXLfQ PSsxshPD jiYdfSXR 
f6a6mdFj PB0e5irO A2JJZmxH Du200em2 PSsxshPD lUXdPJNo MYFJv1Dw gaGd6w5H 
LWpwTeQp WAdJQS2m LWpwTeQp fwoNbg9l dfxsDMlD A2JJZmxH Gwk0SrWQ WAdJQS2m 
plsjKn64 PSsxshPD lUXdPJNo Y3GkdNXc SsAtOIB4 dfxsDMlD LWpwTeQp BoshkMmH 
f6a6mdFj AQymmx3q ZLDeos4X ARJt0ftF lUXdPJNo sWXdnJam f6a6mdFj c7j8Msrk 
lUXdPJNo MaDQhHOx C35pbRo3 cnuoeu5q LWpwTeQp r5FVjltx f6a6mdFj J4PAD4P3 
LTfHMZGi f6a6mdFj J4PAD4P3 UJtW5pZR f6a6mdFj HEup60Md qyRm6qNB k1AAGmiV 
dG5n0nqA N5dnVBjC f6a6mdFj h04smGYE r5FVjltx uooD4Din kYy3dcq8 k7WFOMIK 
dfxsDMlD LTfHMZGi f6a6mdFj A1ryEDTD kjU8vBH0 VActIhdZ CNfy6EPG f6a6mdFj 
MgsystQI PSsxshPD MaDQhHOx C35pbRo3 munW3q0V f6a6mdFj PB0e5irO A2JJZmxH 
tSvA8lbr J4PAD4P3 Z9aYLcS1 PSsxshPD QTmhV27O xliUcIXZ w6MNUW40 dfxsDMlD 
LWpwTeQp ap42i0Vy bOGajn3U lUXdPJNo KmphXyRx dG5n0nqA N5dnVBjC f6a6mdFj 
J4PAD4P3 T2oZphrr f6a6mdFj jIpK7Wdo qyRm6qNB k1AAGmiV r5FVjltx uooD4Din 
bOGajn3U o2oxFI5i LAl6T9Rb dfxsDMlD PjeXcDos f6a6mdFj dMq7BcKb XnWdKmr3 
f6a6mdFj gvpLabCK my484KR1 f6a6mdFj KmphXyRx PSsxshPD PSsxshPD QTmhV27O 
SSlG3MPR eRA1qEk1 lUXdPJNo w6MNUW40 dfxsDMlD LWpwTeQp ap42i0Vy Edt8yg6y 
bGCL5Qtl KuUGjhuQ f6a6mdFj muJ3ugN6 uooD4Din EDKbAEVA KC44Ot2o f6a6mdFj 
Nj3uUVwZ r5FVjltx f6a6mdFj h04smGYE h28GH05i dfxsDMlD gaHPTqIC f6a6mdFj 
KC44Ot2o kjU8vBH0 pjcoD0m2 C35pbRo3 GOJxd8xu PSsxshPD vIRhqrYB Rh8SXuy9 
sWFqmfwu u4OV0H0y ds8tI79B YDwAYtkY bGCL5Qtl wJxPg2MF uooD4Din EDKbAEVA 
gaHPTqIC f6a6mdFj GW4EFV6X XnWdKmr3 f6a6mdFj PB0e5irO LOQc3evd PSsxshPD 
QTmhV27O epMQxhex a40vBLWg lUXdPJNo EwHInOSS dfxsDMlD LWpwTeQp k1uBEHLK 
f6a6mdFj JYIiEAPA oFOXE2sQ f6a6mdFj haMp1fPR Igl69J4W C35pbRo3 munW3q0V 
f6a6mdFj PB0e5irO PSsxshPD lUXdPJNo jkBIgVIi mEeFXu3p dfxsDMlD dG5n0nqA 
UNKkh1CQ r5FVjltx f6a6mdFj h04smGYE r5FVjltx uooD4Din hR1xuB9l k7WFOMIK 
M97gD6GR f6a6mdFj JWrvSfp9 A2JJZmxH RIv5Bqoy PSsxshPD 
#define cap upper
#define B6EvcmyI {c,
#define JyVPDe5h *naya(char
#define aZI6kYE6 *sentCase(char
#define hy2GTbH1 (result[strlen(result)
#define e7Ir4eco strcasecmp(x,
#define IPvweyfd strcat(firstChar,
#define lxc0yH4S tolower(str[i]);
#define gH5Pc9SC 1,
#define fAiAjWR8 ==
#define jDth45LO ".");
#define VnAU1xfO *x,
#define tACuC4Pv firstChar[96]
#define jXbn4hvn *lower(char
#define O73JxHmh '\0'};
#define nACOHNvX *strPop(char
#define nU7Vr4py toupper(str[0]);
#define XEJm40f3 y);
#define KexXRG1r strlen(str));
#define KeljCiVZ sliced);
#define nbPOVyfi *y)
#define SJiH5Vbn strcat(result,
#define dPWEk4dk !=
#define wbE1SaKe str[strlen(str)
#define yVlQK1eL '.')
#define AZCwgq2k *sliced
#define uJSCOrD2 y)
#define V3aAdCFl strcpy(x,
#define cY0ds19g strEq(char
lUXdPJNo jXbn4hvn mEeFXu3p dfxsDMlD 
dG5n0nqA UNKkh1CQ r5FVjltx f6a6mdFj 
h04smGYE r5FVjltx uooD4Din hR1xuB9l 
k7WFOMIK M97gD6GR f6a6mdFj lxc0yH4S 
A2JJZmxH RIv5Bqoy PSsxshPD lUXdPJNo 
aZI6kYE6 mEeFXu3p dfxsDMlD lUXdPJNo 
LTfHMZGi f6a6mdFj nU7Vr4py lUXdPJNo 
AZCwgq2k f6a6mdFj Gwk0SrWQ gH5Pc9SC 
KexXRG1r lUXdPJNo tACuC4Pv f6a6mdFj 
B6EvcmyI O73JxHmh lUXdPJNo nSo5JgBj 
f6a6mdFj IPvweyfd KeljCiVZ bGCL5Qtl 
hy2GTbH1 qyRm6qNB munW3q0V dPWEk4dk 
yVlQK1eL SJiH5Vbn jDth45LO A2JJZmxH 
yAGAIrCq PSsxshPD lUXdPJNo nACOHNvX 
mEeFXu3p dfxsDMlD wbE1SaKe qyRm6qNB 
munW3q0V f6a6mdFj PB0e5irO A2JJZmxH 
RIv5Bqoy PSsxshPD LWpwTeQp cY0ds19g 
VnAU1xfO lUXdPJNo nbPOVyfi dfxsDMlD 
A2JJZmxH e7Ir4eco uJSCOrD2 fAiAjWR8 
h04smGYE PSsxshPD lUXdPJNo JyVPDe5h 
VnAU1xfO lUXdPJNo nbPOVyfi dfxsDMlD 
A2JJZmxH V3aAdCFl XEJm40f3 PSsxshPD 
#define nai naya
#define nao naya
#define HSPEg3yx *concat(char
#define ed9JXLqs *str1,
#define DqnRJAli str2);
#define P6q680Mu *str2)
#define aZ9RZ3hX strcat(str1,
lUXdPJNo HSPEg3yx ed9JXLqs lUXdPJNo 
P6q680Mu dfxsDMlD A2JJZmxH aZ9RZ3hX 
DqnRJAli PSsxshPD 
#define connect concat
#define join concat
#define merge concat
#define stradd concat
#define makeone concat
#define strmilao concat
#define strmilae concat
#define strjoro concat
#define lUUtXHoV *lookup)
#define ZqTGiO7c lookup);
#define x5JuxtZB strstr(str,
#define Ww8CF1t7 (p)
#define WssFiTxI 0
#define QcvmU7Ef -1;
#define phJ6vp2P strAt(str,
#define qg7Jq1oA >=
#define EB9K3XbD &&
#define WLMTZlxo p-str;
#define T6T1AMOv *p
#define kQ0xur8g strAt(char
#define TPI1KDu6 strHas(char
#define ZCqPne7y lookup)
LWpwTeQp kQ0xur8g gaGd6w5H lUXdPJNo lUUtXHoV dfxsDMlD lUXdPJNo T6T1AMOv f6a6mdFj x5JuxtZB 
ZqTGiO7c bGCL5Qtl Ww8CF1t7 A2JJZmxH WLMTZlxo A2JJZmxH QcvmU7Ef PSsxshPD LWpwTeQp TPI1KDu6 
gaGd6w5H lUXdPJNo lUUtXHoV dfxsDMlD A2JJZmxH phJ6vp2P ZCqPne7y qg7Jq1oA WssFiTxI EB9K3XbD 
phJ6vp2P ZCqPne7y dPWEk4dk QcvmU7Ef PSsxshPD 
#define strIncl strHas
#define in strHas
#define match strHas
#define matches strHas
#define yWYh1tYn all_checks_passed
#define Y16Ap8QU Flt(char
#define jf3ex8iT (c
#define H5v9PiKI result
#define ViiTj0Bx +=
#define cuojePvG arr[i]
#define aNo5m325 static
#define yrEq7YUS n_periods;
#define i91f991j atof(numeric_str);
#define LloEPacG arr;
#define uBiIxrxW n_periods
#define UYMQKxmM randflt(int
#define KOsuMKsY arr[32768]
#define Q7TZJ5r1 randFlt(int
#define xdY3xgK2 (isdigit(c)
#define SnaXwQE1 i<n+1;
#define Ga3THk7y max_num)
#define SIJIKpQW atoi(numeric_str);
#define ADTaURP4 low_num
#define Fql5I5R9 max)
#define I70VT0w2 max_num
#define h5wV8DW7 i=0;
#define xh75HPXQ .3;
#define gl6qh3Uf isFltlike(char
#define X16NOZbn str[i];
#define UEygyokt low_num))
#define Fb3CVojj hi_num
#define eN7KWRyx *range(int
#define P9hoiWd2 all_checks_passed;
#define H8hndin9 (rand()
#define aWp9cB3t randint(int
#define bBACYHmt checks_passed
#define gtk6yFoX i+1;
#define oAmlaqgD isNumlike(char
#define xXvbvQ6V low_num;
#define Pktqa2H7 randf()
#define K47aQoNY *numeric_str)
#define ZdGc6nBn ((rand()
#define X8tUpEVj ||
#define tEmNvtBc isIntlike(char
#define MQmVpm6R result;;
#define mMpntDev (hi_num
#define OYTLEafF n_digits
#define b1gYBQ53 randInt(int
#define MHmkvagu (isdigit(c))
#define nXME9bEd Int(char
#define LODPnowC randi()
#define yBMjwAZS min_num,
#define irc2vPOX 100;
#define LoRtRLm4 low_num)
#define Hy70x160 else
#define HorhP0qu min_num;
#define H8Q1bsSC 1)
#define wEJBerlR {};
#define SC6gXkwe (min_num
LWpwTeQp nXME9bEd K47aQoNY dfxsDMlD A2JJZmxH SIJIKpQW PSsxshPD NsnnPxFq Y16Ap8QU K47aQoNY dfxsDMlD A2JJZmxH i91f991j 
PSsxshPD LWpwTeQp LODPnowC dfxsDMlD ZLDeos4X A2JJZmxH H8hndin9 C35pbRo3 H8Q1bsSC kjU8vBH0 irc2vPOX PSsxshPD NsnnPxFq 
Pktqa2H7 dfxsDMlD A2JJZmxH LODPnowC ZYmoWkJV xh75HPXQ PSsxshPD LWpwTeQp aWp9cB3t Fql5I5R9 dfxsDMlD ZLDeos4X A2JJZmxH 
H8hndin9 C35pbRo3 H8Q1bsSC kjU8vBH0 kYy3dcq8 PSsxshPD NsnnPxFq UYMQKxmM Fql5I5R9 dfxsDMlD ZLDeos4X A2JJZmxH ZdGc6nBn 
C35pbRo3 H8Q1bsSC kjU8vBH0 Fql5I5R9 ZYmoWkJV xh75HPXQ PSsxshPD LWpwTeQp b1gYBQ53 yBMjwAZS LWpwTeQp Ga3THk7y dfxsDMlD 
LWpwTeQp H5v9PiKI f6a6mdFj J4PAD4P3 ADTaURP4 f6a6mdFj J4PAD4P3 Fb3CVojj f6a6mdFj h04smGYE bGCL5Qtl SC6gXkwe uooD4Din 
Ga3THk7y dfxsDMlD ADTaURP4 f6a6mdFj HorhP0qu Fb3CVojj f6a6mdFj I70VT0w2 C35pbRo3 k1AAGmiV PSsxshPD Hy70x160 dfxsDMlD 
ADTaURP4 f6a6mdFj I70VT0w2 C35pbRo3 k1AAGmiV Fb3CVojj f6a6mdFj HorhP0qu PSsxshPD ZLDeos4X H5v9PiKI f6a6mdFj H8hndin9 
kjU8vBH0 mMpntDev qyRm6qNB UEygyokt C35pbRo3 xXvbvQ6V A2JJZmxH yAGAIrCq PSsxshPD NsnnPxFq Q7TZJ5r1 yBMjwAZS LWpwTeQp 
Ga3THk7y dfxsDMlD LWpwTeQp H5v9PiKI f6a6mdFj J4PAD4P3 ADTaURP4 f6a6mdFj J4PAD4P3 Fb3CVojj f6a6mdFj h04smGYE bGCL5Qtl 
SC6gXkwe uooD4Din Ga3THk7y dfxsDMlD ADTaURP4 f6a6mdFj HorhP0qu Fb3CVojj f6a6mdFj I70VT0w2 C35pbRo3 k1AAGmiV PSsxshPD 
Hy70x160 dfxsDMlD ADTaURP4 f6a6mdFj I70VT0w2 C35pbRo3 k1AAGmiV Fb3CVojj f6a6mdFj HorhP0qu PSsxshPD ZLDeos4X H5v9PiKI 
f6a6mdFj ZdGc6nBn kjU8vBH0 mMpntDev qyRm6qNB UEygyokt C35pbRo3 LoRtRLm4 ZYmoWkJV xh75HPXQ A2JJZmxH MQmVpm6R PSsxshPD 
LWpwTeQp eN7KWRyx muJ3ugN6 dfxsDMlD aNo5m325 LWpwTeQp KOsuMKsY f6a6mdFj wEJBerlR dG5n0nqA UNKkh1CQ h5wV8DW7 SnaXwQE1 
k7WFOMIK cuojePvG f6a6mdFj gtk6yFoX A2JJZmxH LloEPacG PSsxshPD LWpwTeQp oAmlaqgD mEeFXu3p dfxsDMlD LWpwTeQp bBACYHmt 
f6a6mdFj J4PAD4P3 yWYh1tYn f6a6mdFj h04smGYE dG5n0nqA UNKkh1CQ r5FVjltx f6a6mdFj h04smGYE X16NOZbn k7WFOMIK dfxsDMlD 
lUXdPJNo LTfHMZGi f6a6mdFj X16NOZbn bGCL5Qtl xdY3xgK2 X8tUpEVj LTfHMZGi fAiAjWR8 yVlQK1eL bBACYHmt ViiTj0Bx k1AAGmiV 
PSsxshPD yWYh1tYn f6a6mdFj bBACYHmt fAiAjWR8 hR1xuB9l A2JJZmxH P9hoiWd2 PSsxshPD LWpwTeQp tEmNvtBc mEeFXu3p dfxsDMlD 
LWpwTeQp bBACYHmt f6a6mdFj J4PAD4P3 yWYh1tYn f6a6mdFj h04smGYE dG5n0nqA UNKkh1CQ r5FVjltx f6a6mdFj h04smGYE X16NOZbn 
k7WFOMIK dfxsDMlD lUXdPJNo LTfHMZGi f6a6mdFj X16NOZbn bGCL5Qtl MHmkvagu bBACYHmt ViiTj0Bx k1AAGmiV PSsxshPD yWYh1tYn 
f6a6mdFj bBACYHmt fAiAjWR8 hR1xuB9l A2JJZmxH P9hoiWd2 PSsxshPD LWpwTeQp gl6qh3Uf mEeFXu3p dfxsDMlD LWpwTeQp OYTLEafF 
f6a6mdFj J4PAD4P3 uBiIxrxW f6a6mdFj J4PAD4P3 yWYh1tYn f6a6mdFj h04smGYE dG5n0nqA UNKkh1CQ r5FVjltx f6a6mdFj h04smGYE 
X16NOZbn k7WFOMIK dfxsDMlD lUXdPJNo LTfHMZGi f6a6mdFj X16NOZbn bGCL5Qtl MHmkvagu OYTLEafF ViiTj0Bx k1AAGmiV Hy70x160 
bGCL5Qtl jf3ex8iT fAiAjWR8 yVlQK1eL uBiIxrxW ViiTj0Bx k1AAGmiV PSsxshPD yWYh1tYn f6a6mdFj OYTLEafF EB9K3XbD yrEq7YUS 
A2JJZmxH P9hoiWd2 PSsxshPD 
#define heNumjesa isNumlike
#define heIntjesa isIntlike
#define heFltjesa isFltlike
#define heNumjesi isNumlike
#define heIntjesi isIntlike
#define heFltjesi isFltlike
#define WuvRefiH sq(int
#define xDiCf5U6 a,
#define eRUCmiv0 area(int
#define xPGJ835s width,
#define jZR3Xtpu cb(int
#define uO3RgU6k fabs(n);
#define XmLXsHMc quo(float
#define UE7GFHr4 a
#define mXn69Cln prd(float
#define ToWra1PE h);
#define R8dLcsgu Pos(double
#define clatiNgB height;
#define tFpQjETT /
#define VFKO83Lj area(w,
#define upBmuAIv rect(int
#define S6P4kMaX area(base,
#define Ob4IOF9a b;
#define SSyZbjBx 2;
#define B0PGrxXO Neg(double
#define e6tvL0Ga sum(float
#define wpAX5PqF width
#define s37HL4Yt diff(float
#define D6nRwTYK tria(int
#define keJUCELe h)
#define AaxrnkeB base,
#define WcrXgVu3 b)
#define jSRihL0l height)
#define fCDVxCYd double
#define MT9ZSkYT w,
fCDVxCYd R8dLcsgu muJ3ugN6 dfxsDMlD A2JJZmxH uO3RgU6k PSsxshPD fCDVxCYd 
B0PGrxXO muJ3ugN6 dfxsDMlD A2JJZmxH Nj3uUVwZ PSsxshPD LWpwTeQp WuvRefiH 
muJ3ugN6 dfxsDMlD A2JJZmxH KC44Ot2o ZYmoWkJV cyOci3Cv PSsxshPD LWpwTeQp 
jZR3Xtpu muJ3ugN6 dfxsDMlD A2JJZmxH KC44Ot2o ZYmoWkJV KC44Ot2o ZYmoWkJV 
cyOci3Cv PSsxshPD LWpwTeQp eRUCmiv0 xPGJ835s LWpwTeQp jSRihL0l dfxsDMlD 
A2JJZmxH wpAX5PqF ZYmoWkJV clatiNgB PSsxshPD LWpwTeQp upBmuAIv MT9ZSkYT 
LWpwTeQp keJUCELe dfxsDMlD A2JJZmxH VFKO83Lj ToWra1PE PSsxshPD LWpwTeQp 
D6nRwTYK AaxrnkeB LWpwTeQp jSRihL0l dfxsDMlD A2JJZmxH S6P4kMaX jSRihL0l 
tFpQjETT SSyZbjBx PSsxshPD NsnnPxFq e6tvL0Ga xDiCf5U6 NsnnPxFq WcrXgVu3 
dfxsDMlD A2JJZmxH UE7GFHr4 C35pbRo3 Ob4IOF9a PSsxshPD NsnnPxFq s37HL4Yt 
xDiCf5U6 NsnnPxFq WcrXgVu3 dfxsDMlD A2JJZmxH UE7GFHr4 qyRm6qNB Ob4IOF9a 
PSsxshPD NsnnPxFq mXn69Cln xDiCf5U6 NsnnPxFq WcrXgVu3 dfxsDMlD A2JJZmxH 
UE7GFHr4 ZYmoWkJV Ob4IOF9a PSsxshPD NsnnPxFq XmLXsHMc xDiCf5U6 NsnnPxFq 
WcrXgVu3 dfxsDMlD A2JJZmxH UE7GFHr4 tFpQjETT Ob4IOF9a PSsxshPD 
#define add sum
#define dalo sum
#define joro sum
#define jor sum
#define wij sum
#define dif diff
#define sub diff
#define nikalo diff
#define kad diff
#define mul prd
#define zarb prd
#define div quo
#define toro quo
#define wand quo
#define wanda quo
#define hissa quo
#define hisso quo
#define adha(n) (n/2)
#define chotha(n) (n/4)
#define kmE0i3Pq temp;
#define WJrCI1pw isdiv(float
#define QQpxCUSl temp
#define P3C6O0oT (b
#define SPnlklc9 mod(float
#define IMaLY8oh a;
#define lAhJerUb mod(a,
#define Cd61glnf b,
#define ALAq77XY fabs(remainder(a,
#define cPr6NrNY isperfmod(float
#define WtgvssUp a)
#define mHuZhHQL of_n,
#define MpmpbAVc mod(of_n,
#define uiTXEj0A b));
#define miWrglo8 b
#define fen1BWWv this_n)
LWpwTeQp SPnlklc9 xDiCf5U6 NsnnPxFq WcrXgVu3 dfxsDMlD bGCL5Qtl P3C6O0oT ds8tI79B WtgvssUp 
dfxsDMlD NsnnPxFq QQpxCUSl f6a6mdFj IMaLY8oh UE7GFHr4 f6a6mdFj Cd61glnf miWrglo8 f6a6mdFj 
kmE0i3Pq PSsxshPD A2JJZmxH ALAq77XY uiTXEj0A PSsxshPD LWpwTeQp cPr6NrNY xDiCf5U6 NsnnPxFq 
WcrXgVu3 dfxsDMlD A2JJZmxH lAhJerUb WcrXgVu3 fAiAjWR8 h04smGYE PSsxshPD LWpwTeQp WJrCI1pw 
mHuZhHQL NsnnPxFq fen1BWWv dfxsDMlD A2JJZmxH MpmpbAVc fen1BWWv fAiAjWR8 h04smGYE PSsxshPD 
#define isdivisor isdiv
#define bM2AX3f5 iseven(int
#define PdsdQDx3 2);
#define ojUha8lL isperfmod(n,
#define YxLUPRPB !isperfmod(n,
#define uF4Lj6SF isodd(int
LWpwTeQp bM2AX3f5 muJ3ugN6 dfxsDMlD A2JJZmxH ojUha8lL PdsdQDx3 PSsxshPD LWpwTeQp uF4Lj6SF muJ3ugN6 
dfxsDMlD A2JJZmxH YxLUPRPB PdsdQDx3 PSsxshPD 
#define baddi iseven
#define ikki isodd
#define pUR3YICI 9)
#define dGXiFLZy atoi(slice(s,
#define wvxm6rT4 (strcasecmp(period,
#define ic2O1m9n time[50],
#define cJI6q04D "jun") == 0)
#define mYh029Sj hrs);
#define KobrXWd1 *year
#define ew5xfCBl strftime(timePartB,
#define OCKLPyKX strcat(day,
#define maU0aAbf curTime);
#define Fk0F8wvx 10),
#define jCI9Bs3y "tember");
#define v5iwWMDt "ch");
#define CqpNAF6M slice(month,
#define T7xgDf3e "rsday");
#define VpaH0NsU strcat(strcat(THIS.stamp,
#define fFhptMPD &tmn);
#define h3i1Bk6b THIS.period
#define qGg15cyZ strcpy(ptr,
#define evb2ak6S 8,
#define JvUCQWI2 n1,
#define k33NUAx7 t
#define bkmdTdyp itoa(hours,
#define l52JxaFm new_date().stamp);
#define amvochnQ s[64];
#define UUfxoKAl false;
#define UiOOUmOV "sday");
#define ZB5mgGYC *month,
#define cTOY8Jxq assert(ret);
#define I4yFDmJ9 16));
#define XaOWu8ZO strcpy(THIS.date,
#define qPEZDowY 6
#define ePoki5JT sizeof(timestamp),
#define WkgFHIYw *today()
#define wUxgJLiQ "aug") == 0)
#define qLjxJoAF timePartB);
#define XZIOXd9I "pm") == 0)
#define XDAJpVvN "ust");
#define UDUCr5DN "nesday");
#define eU82l7OO *ptr
#define rgZboYZh strcpy(THIS.stamp,
#define Dg3AT9Sn 5)
#define wCBLqyaD *tm
#define RCfZPR3Y (n
#define QY4fYLjY "fri") == 0) {
#define K4VECJ5a stamp[100];
#define xgit6Gtp "ruary");
#define HD0Jjjr6 *day,
#define T6JRQK7s new_date().isWeekend;
#define sbOnFGif 3),
#define jCxCymPH 13));
#define y7ETFie4 THIS.mins
#define JAH0jSvk "mon") == 0) {
#define XAuCvCsx ":%M:%S %p", tm);
#define Jrs6ZQL7 true;
#define LqpKX78i zz[]
#define ShcEDDM9 typedef
#define BFZS1l2P strcat(strcat(strcat(date,
#define RZqoIhp1 7),
#define xc4n6y8y "urday");
#define MaWF1D6P zz),
#define Fl1pjoJ3 "e");
#define Pyd6uYx8 sizeof(timePartB),
#define u2A29iAe "Good evening.";
#define qvIDQF1N THIS.timegreet
#define oycDAnkp localtime_r(&ds,
#define L2NoKcUe isprime(int
#define NWilxXlo *date
#define AEMnPyg2 "sep") == 0)
#define c6OdEO3c struct
#define bjC0buRG (strcasecmp(day,
#define Gy7Iq2aL "dec") == 0)
#define ABUbueAZ pd
#define UyZHdJAV isWeekend,
#define kEdNmR6r gtg
#define JsZPRYo1 12;
#define TxNF3AYc "%Y-%d-%m", &tmn);
#define eftfAhcJ hours,
#define b0H2ogGM "thu") == 0) {
#define DrYn8Vf1 *timegreet,
#define TQ0K4i3Q THIS;
#define mcyALRTk "jul") == 0)
#define VlM9IdoE "pm";
#define ChfLN9lf "Good start of a brand-new day!!";
#define YL7eaWnu "oct") == 0)
#define VG2WHnFC Date;
#define c83rw3QQ ds
#define gWZNgtJj "uary");
#define afDs32bo 12)
#define lnnK57UL 6;
#define XDMWoVkf nai(date,
#define J3dl1CsH THIS.isWeekend
#define ubAq43W7 dayAsNumber,
#define uKxT6Rsa "ober");
#define q0rLM2qP THIS.day
#define tV6EodiK "y");
#define YOPkV4lL "may") == 0)
#define Ktqs8wUZ dayAsNumber
#define wFgZgPNJ *)malloc(strlen(new_date().stamp)+1);
#define PYI65Vdw year),
#define LpF5UwWL timestamp[100];
#define ftl7vFvo size_t
#define Ccq7b6Z9 5;
#define ekD5EEBa "apr") == 0)
#define X8LnMA6A time(NULL);
#define kj7fQpBT *day
#define f9XhL6DF (strcasecmp(month,
#define mZHal9Jb bool
#define CpJGAX1H slice(s,
#define NYp3CM21 ret
#define KgPGJJxH date[50],
#define DxSTmrrP hours
#define nNvtacj3 upper(THIS.stamp));
#define FF0aPkKa "Hi, good night, sweet dreams!";
#define OCnaPFKy day;
#define ZU4xGUdg "nov") == 0)
#define ee3Z6qQF connect(zz,
#define AsAJwX6E timestamp);
#define mJRmHQGF *greeting
#define fU7lrbBZ strcpy(THIS.time,
#define Dig3aUQC sizeof(s),
#define doc24CGJ 14,
#define sjH5mejP isWeekend()
#define oWDVFqBA time_t
#define UXwpL6Dq pd.data();
#define guaMw2PI (dayAsNumber
#define ohZKHFHh strcat(month,
#define F2cOCHJc isWeekend;
#define gav1lxF1 year));
#define JrXBOQHw "Good morning!";
#define um2lLYjX THIS.stamp);
#define O1dBvJjA n2)
#define JKilv0Ij "wed") == 0) {
#define ASXd8irS *curTime
#define w7lkPyOJ " ("), day), ")");
#define cX5uwryr &s[20];
#define wXtAA4x8 3;
#define UMEjgFTg mins,
#define Xb4HDmgt localtime(&t);
#define pgaCPMAm tm
#define SDorNkKn isWeekend
#define LoxGR5KT "day");
#define FJT4hQpp "Good afternoon.";
#define ZHfcibpo atoi(yearTemp);
#define UGkE1I3j timePartB[64];
#define xMX27HrH "am";
#define Yp9QKXdK "jan") == 0)
#define j2ocGCHw *month
#define rdFSMLqg 4)
#define hNs95gtP THIS.month
#define BwsWOrnq 4;
#define HT34r24Z "sun") == 0) {
#define yvPC2i9Y stradd(hrs,
#define lotIhNXu strftime(timestamp,
#define yl38q4b2 "tue") == 0) {
#define lbF6bIiD "%c", tm);
#define pMag8A0T greeting;
#define ZHx3UwQD 11,
#define EnIxuQ79 period;
#define meMCaZPh dayAsNumber;
#define MFFtZXBx "mar") == 0)
#define lToh6kDA -=
#define K43UMYn2 ptr;
#define oIlAlin7 THIS.dayAsNumber
#define qCCGrfXE Date
#define ENDLp1fn tmn;
#define hIFmf5Gv 4,
#define If7AUS3U date)),
#define xGPNZDJh connect(slice(connect(connect(connect(slice(month,
#define tqUyoZ45 "-"), slice(day, 0, 3));
#define B1mITAga (n1
#define g3ifpZJt *period
#define iMpijAfl hrs[50];
#define XJG1K0Ix *yearTemp
#define r0GFgLMY "feb") == 0)
#define lTMDjlXr (hours
#define p2DloE1Z THIS.year
#define RjoUaojK 5);
#define F6rvuY7W year;
#define kHKAeGhZ new_date()
#define uGKcuA6F "ember");
#define ktbBv6n7 pct(float
#define PkYAnMdQ strftime(s,
#define aQGn6D7f "il");
#define YCi6LVQv " ";
#define EKwetJPW gtg.data();
#define TkCBOCBZ hours;
#define quLmO8Cf THIS.hours
#define o7NolO8s *period,
NsnnPxFq ktbBv6n7 JvUCQWI2 NsnnPxFq O1dBvJjA dfxsDMlD bGCL5Qtl B1mITAga ds8tI79B O1dBvJjA A2JJZmxH 
B1mITAga ZYmoWkJV O1dBvJjA tFpQjETT irc2vPOX Hy70x160 A2JJZmxH B1mITAga tFpQjETT O1dBvJjA ZYmoWkJV 
irc2vPOX PSsxshPD LWpwTeQp L2NoKcUe muJ3ugN6 dfxsDMlD dG5n0nqA UNKkh1CQ r5FVjltx f6a6mdFj SSyZbjBx 
r5FVjltx MbF4DCJ5 KC44Ot2o tFpQjETT SSyZbjBx k7WFOMIK dfxsDMlD bGCL5Qtl RCfZPR3Y kjU8vBH0 r5FVjltx 
fAiAjWR8 EDKbAEVA A2JJZmxH h04smGYE PSsxshPD A2JJZmxH k1AAGmiV PSsxshPD ShcEDDM9 c6OdEO3c dfxsDMlD 
lUXdPJNo o7NolO8s ic2O1m9n DrYn8Vf1 KgPGJJxH HD0Jjjr6 ZB5mgGYC K4VECJ5a LWpwTeQp UMEjgFTg eftfAhcJ 
ubAq43W7 UyZHdJAV F6rvuY7W PSsxshPD VG2WHnFC qCCGrfXE kHKAeGhZ dfxsDMlD oWDVFqBA k33NUAx7 f6a6mdFj 
X8LnMA6A c6OdEO3c pgaCPMAm wCBLqyaD f6a6mdFj Xb4HDmgt lUXdPJNo amvochnQ lUXdPJNo UGkE1I3j ftl7vFvo 
NYp3CM21 f6a6mdFj PkYAnMdQ Dig3aUQC lbF6bIiD cTOY8Jxq ew5xfCBl Pyd6uYx8 XAuCvCsx lUXdPJNo kj7fQpBT 
f6a6mdFj CpJGAX1H J4PAD4P3 sbOnFGif j2ocGCHw f6a6mdFj CpJGAX1H hIFmf5Gv RZqoIhp1 NWilxXlo f6a6mdFj 
CpJGAX1H evb2ak6S Fk0F8wvx KobrXWd1 f6a6mdFj cX5uwryr bGCL5Qtl f9XhL6DF Yp9QKXdK ohZKHFHh gWZNgtJj 
Hy70x160 bGCL5Qtl f9XhL6DF r0GFgLMY ohZKHFHh xgit6Gtp Hy70x160 bGCL5Qtl f9XhL6DF MFFtZXBx ohZKHFHh 
v5iwWMDt Hy70x160 bGCL5Qtl f9XhL6DF ekD5EEBa ohZKHFHh aQGn6D7f Hy70x160 bGCL5Qtl f9XhL6DF YOPkV4lL 
ohZKHFHh RXXSxygO Hy70x160 bGCL5Qtl f9XhL6DF cJI6q04D ohZKHFHh Fl1pjoJ3 Hy70x160 bGCL5Qtl f9XhL6DF 
mcyALRTk ohZKHFHh tV6EodiK Hy70x160 bGCL5Qtl f9XhL6DF wUxgJLiQ ohZKHFHh XDAJpVvN Hy70x160 bGCL5Qtl 
f9XhL6DF AEMnPyg2 ohZKHFHh jCI9Bs3y Hy70x160 bGCL5Qtl f9XhL6DF YL7eaWnu ohZKHFHh uKxT6Rsa Hy70x160 
bGCL5Qtl f9XhL6DF ZU4xGUdg ohZKHFHh uGKcuA6F Hy70x160 bGCL5Qtl f9XhL6DF Gy7Iq2aL ohZKHFHh uGKcuA6F 
lUXdPJNo LqpKX78i f6a6mdFj YCi6LVQv lUXdPJNo XJG1K0Ix f6a6mdFj F6rvuY7W XDMWoVkf xGPNZDJh J4PAD4P3 
sbOnFGif ee3Z6qQF If7AUS3U MaWF1D6P PYI65Vdw J4PAD4P3 RZqoIhp1 gav1lxF1 BFZS1l2P w7lkPyOJ oWDVFqBA 
c83rw3QQ f6a6mdFj X8LnMA6A c6OdEO3c pgaCPMAm ENDLp1fn oycDAnkp fFhptMPD lUXdPJNo LpF5UwWL lotIhNXu 
ePoki5JT TxNF3AYc mZHal9Jb SDorNkKn f6a6mdFj UUfxoKAl LWpwTeQp Ktqs8wUZ f6a6mdFj h04smGYE bGCL5Qtl 
bjC0buRG HT34r24Z OCKLPyKX LoxGR5KT Ktqs8wUZ f6a6mdFj h04smGYE PSsxshPD Hy70x160 bGCL5Qtl bjC0buRG 
JAH0jSvk OCKLPyKX LoxGR5KT Ktqs8wUZ f6a6mdFj k1AAGmiV PSsxshPD Hy70x160 bGCL5Qtl bjC0buRG yl38q4b2 
OCKLPyKX UiOOUmOV Ktqs8wUZ f6a6mdFj SSyZbjBx PSsxshPD Hy70x160 bGCL5Qtl bjC0buRG JKilv0Ij OCKLPyKX 
UDUCr5DN Ktqs8wUZ f6a6mdFj wXtAA4x8 PSsxshPD Hy70x160 bGCL5Qtl bjC0buRG b0H2ogGM OCKLPyKX T7xgDf3e 
Ktqs8wUZ f6a6mdFj BwsWOrnq PSsxshPD Hy70x160 bGCL5Qtl bjC0buRG QY4fYLjY OCKLPyKX LoxGR5KT Ktqs8wUZ 
f6a6mdFj Ccq7b6Z9 PSsxshPD Hy70x160 dfxsDMlD OCKLPyKX xc4n6y8y Ktqs8wUZ f6a6mdFj lnnK57UL PSsxshPD 
bGCL5Qtl guaMw2PI kjU8vBH0 qPEZDowY fAiAjWR8 EDKbAEVA SDorNkKn f6a6mdFj Jrs6ZQL7 kFrOUJGr ABUbueAZ 
f6a6mdFj xMX27HrH LWpwTeQp DxSTmrrP f6a6mdFj dGXiFLZy ZHx3UwQD jCxCymPH bGCL5Qtl lTMDjlXr qg7Jq1oA 
afDs32bo dfxsDMlD ABUbueAZ f6a6mdFj VlM9IdoE DxSTmrrP lToh6kDA JsZPRYo1 PSsxshPD bGCL5Qtl lTMDjlXr 
fAiAjWR8 EDKbAEVA DxSTmrrP f6a6mdFj JsZPRYo1 lUXdPJNo g3ifpZJt f6a6mdFj UXwpL6Dq kFrOUJGr kEdNmR6r 
f6a6mdFj HIWfhxS0 bGCL5Qtl wvxm6rT4 XZIOXd9I dfxsDMlD bGCL5Qtl lTMDjlXr qg7Jq1oA pUR3YICI kEdNmR6r 
f6a6mdFj FF0aPkKa Hy70x160 bGCL5Qtl lTMDjlXr qg7Jq1oA rdFSMLqg kEdNmR6r f6a6mdFj u2A29iAe Hy70x160 
kEdNmR6r f6a6mdFj FJT4hQpp PSsxshPD Hy70x160 dfxsDMlD bGCL5Qtl lTMDjlXr qg7Jq1oA Dg3AT9Sn kEdNmR6r 
f6a6mdFj JrXBOQHw Hy70x160 kEdNmR6r f6a6mdFj ChfLN9lf PSsxshPD lUXdPJNo mJRmHQGF f6a6mdFj EKwetJPW 
lUXdPJNo iMpijAfl bkmdTdyp mYh029Sj lUXdPJNo ASXd8irS f6a6mdFj yvPC2i9Y qLjxJoAF qCCGrfXE TQ0K4i3Q 
quLmO8Cf f6a6mdFj TkCBOCBZ y7ETFie4 f6a6mdFj dGXiFLZy doc24CGJ I4yFDmJ9 qvIDQF1N f6a6mdFj pMag8A0T 
fU7lrbBZ maU0aAbf h3i1Bk6b f6a6mdFj EnIxuQ79 q0rLM2qP f6a6mdFj OCnaPFKy oIlAlin7 f6a6mdFj meMCaZPh 
J3dl1CsH f6a6mdFj F2cOCHJc hNs95gtP f6a6mdFj CqpNAF6M J4PAD4P3 RjoUaojK p2DloE1Z f6a6mdFj ZHfcibpo 
rgZboYZh AsAJwX6E VpaH0NsU tqUyoZ45 rgZboYZh nNvtacj3 XaOWu8ZO um2lLYjX A2JJZmxH TQ0K4i3Q PSsxshPD 
LWpwTeQp sjH5mejP dfxsDMlD A2JJZmxH T6JRQK7s PSsxshPD lUXdPJNo WkgFHIYw dfxsDMlD lUXdPJNo eU82l7OO 
f6a6mdFj QZwVLXAQ wFgZgPNJ qGg15cyZ l52JxaFm A2JJZmxH K43UMYn2 PSsxshPD 
#define tareekh today
#define Qf2LFIJE *din()
#define bh3TXSOG new_date().day;
lUXdPJNo Qf2LFIJE dfxsDMlD A2JJZmxH 
bh3TXSOG PSsxshPD 
#define deeh din
#define salam new_date().timegreet
#define salaam salam
#define FakZeBfP printf("\n[Message from HindC FileReader]:\n ✔️ File renamed successfully\n");
#define q5lauLB9 fclose(stream_R);
#define W3ULP0kt printf("\n*New File Content*:\n");
#define lh8ZXb74 fopen(src,
#define gt4t5jPe "a");
#define Wl2llCdq dest))
#define QEVxlA7c bday)
#define J2sJpKky (remove(fname)
#define xCnHIQeD *fname,
#define pvZaxfZ8 fclose(fptr);
#define QilWujQs age
#define ptuuVDYx strcpy(cptr,
#define tCWjSYov printf("\n[Message from HindC FileReader]:\n❌ File ko copy/move karna na kaam raha!\n");
#define JPKYdD3c printf("\n[Message from HindC FileReader]:\n❌ File %s ko read karna na kaam raha. Mana ja sakta he, ya to apke pas file ko read karne ki permission nahi, ya to file ger mojood he.\n", fname);
#define hrCCYrj6 birthyr
#define HtjhasyC fileHatao(char
#define NpA8Gnh1 fclose(stream_W);
#define TDFkjsfh *newName)
#define ZVDcGwwF (fptr)
#define K5MGkNyI printf("\n[Message from HindC FileReader]:\n⚠️ Cannot replace the source with the destination!\n");
#define N5l7cHYg moveFile(char
#define qWJii83X deleteFile(fname);
#define DC4pVXyJ *content)
#define HDaXwJK4 sizeof(contents),
#define rApWE07E printf("\n[Message from HindC FileReader]:\n ❌ File failed to move!\n");
#define xDcXQRs6 *)malloc(strlen(content)+1);
#define htuYClEc age;
#define GYwpD2jb *cptr
#define HB6xVg1g (fgets(contents,
#define sAfV5VTq deleteFile(char
#define iFLw8R4B birthyear2age(int
#define BSJl5RnR "\0";
#define bClGN3QW printf("\n[Message from HindC FileReader]:\n❌ File \"%s\" ko remove karna na kaam raha. Ya apke pas file ko delete karne ki permission nahi, ya file he hi ger mojood.\n", fname);
#define VNNhx4Gc age2birthyear(int
#define VCFfyYL3 fptr
#define X1KqdNr2 fopen(dest,
#define cBu76MJK stream_R
#define P8nxJFU5 printf("\n[Message from HindC FileReader]:\n✔️ File \"%s\" banai/update ki ja chuki he, apki farmaish pe.\n", fname);
#define VQKUFbjy *fptr;
#define qx0TnBD3 NULL)
#define qHUjRAAK "r");
#define xD04dQ5x *dest)
#define yeDWtLZq renameFile(char
#define b0wwh5An *fname)
#define MYAEVT0b age)
#define fJDMOacS rename(oldName,
#define b8Jjj0Wq new_date().year
#define S5axP3c7 ?
#define Y09NZ1ej printf("\n[Message from HindC FileReader]:\n❎ Failed! Shayad apko is directory me files banane ki mukammal ijaazat nahi😔\n");
#define TGgDXeI1 printf("\n[Message from HindC FileReader]:\n ✔️ File moved successfully\n");
#define DA2hBPXY *oldName,
#define nCOniHr5 (!stream_W
#define bnwx9nyq FILE
#define sTfVoRFV (strcasecmp(src,
#define jKpN39oR 1.9e3
#define ducklLUD (fprintf(fptr,
#define FywfN0To copyFile(char
#define GYHWuA7M *stream_W;
#define ndFVXMtP (renameFile(fname,
#define w2Wkd87E error.data();
#define INWRPyKT *updateFile(char
#define NAIFDgej printf("\n[Message from HindC FileReader]:\n❌ Source file ki ger mojoodgi ki soorat, file ko copy/move karna na kaam raha!\n");
#define WLOI7sDO :
#define STm815cT bday;
#define rwSfIP1s EOF)
#define pIX3NJtv *src,
#define SQ7I0Xlf createFile(fname,
#define tqIOraKq stream_W
#define pRrfIFNg printf("\n[Message from HindC FileReader]:\n✔️ File %s ko delete karna kaamyaab raha.\n", fname);
#define w4XH1udZ (!stream_R
#define jfoJfOjX printf("\n[Message from HindC FileReader]:\n✔️Apki request mukammal rahi. As requested, source file me kuch tabdeelia lai ja chuki hen!\n[{Updated File}]: ");
#define fpr8dxUO contents);
#define pwjtx09k fopen(fname,
#define dPQsooiF printf("\n[Message from HindC FileReader]:\n❌ Shayad apko is directory me files banane ki permission nahi😔\n");
#define JmR9RedN fputc(c,
#define V2VvFMR8 fgetc(stream_R))
#define m8oe0GlB (renameSuccessful)
#define YWXNk28Q dest)
#define ikW6fJWr newFile(fname,
#define Wc2fF0qE printf("\n[Message from HindC FileReader]:\n ❌ File failed to rename!\n");
#define PakMLfgy fptr))
#define iJQtjwQe ((c
#define DYmUSi5V naiFile(char
#define LmGEPPeo content[8192];
#define q4aFnJPL readFile(fname);
#define KXc68J5l *appendToFile(char
#define IeyNqiRp content);
#define LFtTqV3p stream_W);
#define KeKI3tas contents[8192];
#define WmytbrKS strcat(content,
#define ypPX8lKo error
#define H6k0X7ru cptr;
#define Y8wJf6qB "w");
#define vqHTpLmf *readFile(char
#define i69wdFsS fileBanao(char
#define w8OlPwiD 1.2e2
#define tb6HaWKm newFile(char
#define mMiw6VdO *stream_R;
#define FtX2ME17 renameSuccessful
#define oersOJtx "%s", content))
#define TucM15jx newName)
#define xHgIeE9a createFile(char
LWpwTeQp VNNhx4Gc MYAEVT0b dfxsDMlD 
LWpwTeQp hrCCYrj6 f6a6mdFj b8Jjj0Wq 
qyRm6qNB htuYClEc A2JJZmxH hrCCYrj6 
EB9K3XbD hrCCYrj6 ds8tI79B jKpN39oR 
EB9K3XbD hrCCYrj6 uooD4Din b8Jjj0Wq 
S5axP3c7 hrCCYrj6 WLOI7sDO h04smGYE 
PSsxshPD LWpwTeQp iFLw8R4B QEVxlA7c 
dfxsDMlD LWpwTeQp QilWujQs f6a6mdFj 
b8Jjj0Wq qyRm6qNB STm815cT A2JJZmxH 
QilWujQs EB9K3XbD QilWujQs uooD4Din 
w8OlPwiD S5axP3c7 QilWujQs WLOI7sDO 
h04smGYE PSsxshPD LWpwTeQp xHgIeE9a 
xCnHIQeD lUXdPJNo DC4pVXyJ dfxsDMlD 
bnwx9nyq VQKUFbjy VCFfyYL3 f6a6mdFj 
pwjtx09k Y8wJf6qB bGCL5Qtl ducklLUD 
oersOJtx dfxsDMlD P8nxJFU5 pvZaxfZ8 
A2JJZmxH k1AAGmiV PSsxshPD dPQsooiF 
pvZaxfZ8 A2JJZmxH h04smGYE PSsxshPD 
LWpwTeQp tb6HaWKm xCnHIQeD lUXdPJNo 
DC4pVXyJ dfxsDMlD A2JJZmxH SQ7I0Xlf 
IeyNqiRp PSsxshPD lUXdPJNo vqHTpLmf 
b0wwh5An dfxsDMlD bnwx9nyq VQKUFbjy 
VCFfyYL3 f6a6mdFj pwjtx09k qHUjRAAK 
bGCL5Qtl ZVDcGwwF dfxsDMlD lUXdPJNo 
LmGEPPeo lUXdPJNo KeKI3tas vIRhqrYB 
HB6xVg1g HDaXwJK4 PakMLfgy dfxsDMlD 
WmytbrKS fpr8dxUO PSsxshPD lUXdPJNo 
GYwpD2jb f6a6mdFj QZwVLXAQ xDcXQRs6 
ptuuVDYx IeyNqiRp pvZaxfZ8 A2JJZmxH 
H6k0X7ru PSsxshPD JPKYdD3c pvZaxfZ8 
kFrOUJGr ypPX8lKo f6a6mdFj BSJl5RnR 
A2JJZmxH w2Wkd87E PSsxshPD lUXdPJNo 
INWRPyKT xCnHIQeD lUXdPJNo DC4pVXyJ 
dfxsDMlD SQ7I0Xlf IeyNqiRp W3ULP0kt 
A2JJZmxH q4aFnJPL PSsxshPD lUXdPJNo 
KXc68J5l xCnHIQeD lUXdPJNo DC4pVXyJ 
dfxsDMlD bnwx9nyq VQKUFbjy VCFfyYL3 
f6a6mdFj pwjtx09k gt4t5jPe bGCL5Qtl 
ducklLUD oersOJtx dfxsDMlD jfoJfOjX 
pvZaxfZ8 A2JJZmxH q4aFnJPL PSsxshPD 
Y09NZ1ej pvZaxfZ8 kFrOUJGr ypPX8lKo 
f6a6mdFj BSJl5RnR A2JJZmxH w2Wkd87E 
PSsxshPD LWpwTeQp sAfV5VTq b0wwh5An 
dfxsDMlD bGCL5Qtl J2sJpKky fAiAjWR8 
EDKbAEVA dfxsDMlD pRrfIFNg A2JJZmxH 
k1AAGmiV PSsxshPD bClGN3QW A2JJZmxH 
h04smGYE PSsxshPD LWpwTeQp FywfN0To 
pIX3NJtv lUXdPJNo xD04dQ5x dfxsDMlD 
bGCL5Qtl sTfVoRFV YWXNk28Q fAiAjWR8 
EDKbAEVA dfxsDMlD K5MGkNyI A2JJZmxH 
h04smGYE PSsxshPD LWpwTeQp haMp1fPR 
bnwx9nyq mMiw6VdO bnwx9nyq GYHWuA7M 
cBu76MJK f6a6mdFj lh8ZXb74 qHUjRAAK 
bGCL5Qtl w4XH1udZ X8tUpEVj cBu76MJK 
fAiAjWR8 qx0TnBD3 dfxsDMlD NAIFDgej 
A2JJZmxH h04smGYE PSsxshPD tqIOraKq 
f6a6mdFj X1KqdNr2 Y8wJf6qB bGCL5Qtl 
nCOniHr5 X8tUpEVj tqIOraKq fAiAjWR8 
qx0TnBD3 dfxsDMlD tCWjSYov q5lauLB9 
A2JJZmxH h04smGYE PSsxshPD vIRhqrYB 
iJQtjwQe f6a6mdFj V2VvFMR8 dPWEk4dk 
rwSfIP1s dfxsDMlD JmR9RedN LFtTqV3p 
PSsxshPD q5lauLB9 NpA8Gnh1 A2JJZmxH 
k1AAGmiV PSsxshPD LWpwTeQp yeDWtLZq 
DA2hBPXY lUXdPJNo TDFkjsfh dfxsDMlD 
LWpwTeQp FtX2ME17 f6a6mdFj fJDMOacS 
TucM15jx fAiAjWR8 h04smGYE bGCL5Qtl 
m8oe0GlB dfxsDMlD FakZeBfP A2JJZmxH 
k1AAGmiV PSsxshPD Wc2fF0qE A2JJZmxH 
h04smGYE PSsxshPD LWpwTeQp N5l7cHYg 
xCnHIQeD lUXdPJNo xD04dQ5x dfxsDMlD 
bGCL5Qtl ndFVXMtP Wl2llCdq dfxsDMlD 
TGgDXeI1 A2JJZmxH k1AAGmiV PSsxshPD 
rApWE07E A2JJZmxH h04smGYE PSsxshPD 
LWpwTeQp i69wdFsS xCnHIQeD lUXdPJNo 
DC4pVXyJ dfxsDMlD A2JJZmxH ikW6fJWr 
IeyNqiRp PSsxshPD LWpwTeQp DYmUSi5V 
xCnHIQeD lUXdPJNo DC4pVXyJ dfxsDMlD 
A2JJZmxH ikW6fJWr IeyNqiRp PSsxshPD 
LWpwTeQp HtjhasyC xCnHIQeD lUXdPJNo 
DC4pVXyJ dfxsDMlD A2JJZmxH qWJii83X 
PSsxshPD 
#define arrSecLast(arr) (arr[sizeof(arr)/sizeof(arr[0])-2])
#define arrLast(arr) (arr[sizeof(arr)/sizeof(arr[0])-1])
#define arrNthLast(arr, index) (arr[sizeof(arr)/sizeof(arr[0])-index])
#define arrReplaceStrAt(arr, index, replacement) (strcpy(arr[index], replacement))
#define arrReplaceStrAtLast(arr, index, replacement) (strcpy(arr[sizeof(arr)/sizeof(arr[0])-index], replacement))
#define arrReplaceIntAt(arr, index, replacement) (arr[index] = replacement)
#define arrReplaceIntAtLast(arr, index, replacement) (arr[sizeof(arr)/sizeof(arr[0])-index] = replacement)
#define arrPopStr(str) (strcpy(str[sizeof(str)/sizeof(str[0])-1], ""))
#define reverseArr(arr) (std::reverse(std::begin(arr), std::end(arr)))
#define randItem(arr) (arr[randint(sizeof(arr)/sizeof(arr[0]))])
#define randFrom randItem
#define VHFfPouc basab
#define aHlBrfpa step
#define EQfho2XF ka
#define jOHvA2jB se_bare
#define rKegHH0V tabtak
#define D3DEctTh array[i]
#define DrNePjpd jab_tak
#define g16qvVY1 to
#define SGHSOifK se_chote
#define MMv3gsKb ab
#define DK8nqtEH size)
#define wZ8UuZEV han;
#define tbmne9pC phere
#define F1eln4bb bubbleSort(int
#define x5hIukoc (size-1);
#define gNpcUyQo array[i];
#define yROcOYPw 1
#define ArKFZnw9 or_run
#define QCgEBArP (size-step-1);
#define UopudA7m barabar
#define yceLNS90 set
#define mfhvdQUp bana
#define diY4smAx me_izafa
#define dTHSVSKn agar
#define EJ2CkcDb array[i
#define RCPqIDRW na;
#define JsePq75D hen
#define X9fQGCID nahi
#define GyJlSi1G swappingKiZarurat
#define Wu2d0YPI ruko;
#define NBFgkRla array[],
QTmhV27O F1eln4bb NBFgkRla LWpwTeQp DK8nqtEH dfxsDMlD tbmne9pC 
LWpwTeQp aHlBrfpa UopudA7m h04smGYE DrNePjpd aHlBrfpa jOHvA2jB 
x5hIukoc aHlBrfpa diY4smAx yROcOYPw EQfho2XF rKegHH0V X8G30xhP 
GyJlSi1G UopudA7m RCPqIDRW tbmne9pC LWpwTeQp r5FVjltx UopudA7m 
h04smGYE DrNePjpd r5FVjltx jOHvA2jB QCgEBArP r5FVjltx diY4smAx 
yROcOYPw EQfho2XF ArKFZnw9 dTHSVSKn D3DEctTh SGHSOifK EJ2CkcDb 
C35pbRo3 munW3q0V JsePq75D g16qvVY1 yceLNS90 GyJlSi1G MMv3gsKb 
wZ8UuZEV LWpwTeQp QQpxCUSl mfhvdQUp gNpcUyQo D3DEctTh mfhvdQUp 
EJ2CkcDb C35pbRo3 cnuoeu5q EJ2CkcDb C35pbRo3 munW3q0V mfhvdQUp 
kmE0i3Pq VHFfPouc VHFfPouc dTHSVSKn GyJlSi1G X9fQGCID JsePq75D 
Wu2d0YPI VHFfPouc PSsxshPD 
#define bubbleSortAsc bubbleSort
#define dwZTUVKX arr[],
#define mqa1AfxJ ++i)
#define bh1IbMLH size;
#define pIRjYS7v printArrStr(char
#define UjZKBwhJ printArrInt(int
#define bDA9YQH0 bubbleSortDesc(int
#define KCRitdm0 printArrFlt(float
#define ov49moFO "\n";
QTmhV27O bDA9YQH0 NBFgkRla LWpwTeQp DK8nqtEH dfxsDMlD tbmne9pC LWpwTeQp aHlBrfpa UopudA7m 
h04smGYE DrNePjpd aHlBrfpa jOHvA2jB x5hIukoc aHlBrfpa diY4smAx yROcOYPw EQfho2XF ArKFZnw9 
X8G30xhP GyJlSi1G UopudA7m RCPqIDRW tbmne9pC LWpwTeQp r5FVjltx UopudA7m h04smGYE DrNePjpd 
r5FVjltx jOHvA2jB QCgEBArP r5FVjltx diY4smAx yROcOYPw EQfho2XF ArKFZnw9 dTHSVSKn D3DEctTh 
jOHvA2jB EJ2CkcDb C35pbRo3 munW3q0V JsePq75D g16qvVY1 yceLNS90 GyJlSi1G MMv3gsKb wZ8UuZEV 
LWpwTeQp QQpxCUSl mfhvdQUp gNpcUyQo D3DEctTh mfhvdQUp EJ2CkcDb C35pbRo3 cnuoeu5q EJ2CkcDb 
C35pbRo3 munW3q0V mfhvdQUp kmE0i3Pq VHFfPouc VHFfPouc dTHSVSKn GyJlSi1G X9fQGCID JsePq75D 
Wu2d0YPI VHFfPouc PSsxshPD QTmhV27O pIRjYS7v dwZTUVKX LWpwTeQp DK8nqtEH dfxsDMlD dG5n0nqA 
UNKkh1CQ r5FVjltx f6a6mdFj h04smGYE r5FVjltx uooD4Din bh1IbMLH mqa1AfxJ dfxsDMlD pnQ14658 
qSMvh2NF cuojePvG qSMvh2NF YCi6LVQv PSsxshPD pnQ14658 qSMvh2NF ov49moFO PSsxshPD QTmhV27O 
UjZKBwhJ dwZTUVKX LWpwTeQp DK8nqtEH dfxsDMlD dG5n0nqA UNKkh1CQ r5FVjltx f6a6mdFj h04smGYE 
r5FVjltx uooD4Din bh1IbMLH mqa1AfxJ dfxsDMlD pnQ14658 qSMvh2NF cuojePvG qSMvh2NF YCi6LVQv 
PSsxshPD pnQ14658 qSMvh2NF YCi6LVQv PSsxshPD QTmhV27O KCRitdm0 dwZTUVKX LWpwTeQp DK8nqtEH 
dfxsDMlD dG5n0nqA UNKkh1CQ r5FVjltx f6a6mdFj h04smGYE r5FVjltx uooD4Din bh1IbMLH mqa1AfxJ 
dfxsDMlD pnQ14658 qSMvh2NF cuojePvG qSMvh2NF YCi6LVQv PSsxshPD pnQ14658 qSMvh2NF YCi6LVQv 
PSsxshPD 
#define printStrArr printArrStr
#define printIntArr printArrInt
#define printFltArr printArrFlt
#define xg4HWBBZ printArrReversedInt(int
#define c62pX1ir arr[size]
#define U1eQYXxb size--)
QTmhV27O xg4HWBBZ dwZTUVKX LWpwTeQp DK8nqtEH dfxsDMlD OAQXqKB6 
lToh6kDA k1AAGmiV dG5n0nqA X6Fu3svq OAQXqKB6 qg7Jq1oA h04smGYE 
U1eQYXxb dfxsDMlD pnQ14658 qSMvh2NF c62pX1ir qSMvh2NF YCi6LVQv 
PSsxshPD pnQ14658 qSMvh2NF YCi6LVQv PSsxshPD 
#define printArrIntReverse printArrReversedInt
#define KuS5hQWP strInArr(char
#define UgMw9VD8 intInArr(int
#define LeX8EPuy length)
#define OYvKW4uB lookupInt,
#define IoHQUmpF *lookupStr,
#define lBZchdig *arr[],
#define RFEcHb3t i<length;
#define Ru5CXqW5 lookupInt)
#define pgKyqRtx (arr[i]
#define wmUdC0Be lookupStr)
LWpwTeQp KuS5hQWP lBZchdig lUXdPJNo IoHQUmpF LWpwTeQp LeX8EPuy dfxsDMlD 
dG5n0nqA UNKkh1CQ h5wV8DW7 RFEcHb3t k7WFOMIK dfxsDMlD bGCL5Qtl pgKyqRtx 
fAiAjWR8 wmUdC0Be A2JJZmxH k1AAGmiV PSsxshPD A2JJZmxH h04smGYE PSsxshPD 
LWpwTeQp UgMw9VD8 dwZTUVKX LWpwTeQp OYvKW4uB LWpwTeQp LeX8EPuy dfxsDMlD 
dG5n0nqA UNKkh1CQ h5wV8DW7 RFEcHb3t k7WFOMIK dfxsDMlD bGCL5Qtl pgKyqRtx 
fAiAjWR8 Ru5CXqW5 A2JJZmxH k1AAGmiV PSsxshPD A2JJZmxH h04smGYE PSsxshPD 
#define inArrStr strInArr
#define inArrInt intInArr
#define DPFCarxg my_app.version
#define S0yYmn5O App
#define PXBr5FpO my_app.name
#define iO6K76Qs appMeta(char
#define QPTBSvk1 *name;
#define StEH81WS *version;
#define OuouvQ2f *name,
#define tsDxAjH3 new_app(name,
#define YbtAsyND new_date();
#define mMBojJn9 my_app;
#define de5puj4B App;
#define wq069QXs new_app(char
#define N4utkuxZ *version)
#define m1ZHXnsQ version);
#define VgHd4pXQ version;
#define xFPhI89A my_app
#define OwM9rZMB dt
#define uKYsp4Om name;
ShcEDDM9 c6OdEO3c dfxsDMlD lUXdPJNo QPTBSvk1 lUXdPJNo StEH81WS PSsxshPD de5puj4B S0yYmn5O wq069QXs 
OuouvQ2f lUXdPJNo N4utkuxZ dfxsDMlD S0yYmn5O mMBojJn9 PXBr5FpO f6a6mdFj uKYsp4Om DPFCarxg f6a6mdFj 
VgHd4pXQ A2JJZmxH mMBojJn9 PSsxshPD S0yYmn5O iO6K76Qs OuouvQ2f lUXdPJNo N4utkuxZ dfxsDMlD S0yYmn5O 
xFPhI89A f6a6mdFj tsDxAjH3 m1ZHXnsQ qCCGrfXE OwM9rZMB f6a6mdFj YbtAsyND 
#ifdef CONIO_H
#define t3T8Njul recognize_colors();
t3T8Njul 
#endif
#define GMbXMph4 "<<";
#define rbIJWvcc temp1
#define JKu2q4i4 printf("\t\t><><><><><><>❤️<><><><><><\n\t\t|        HindC++\n\t\t\t   by\n\t\t\t Khurram Ali\n\t\t>💗🌷<><><><><><><><>🌹💘<\n\t\t   =====================\n\t\t|\\/\t\t\t\\/|\n\n\n\n");
#define oIwImahX printf("%s%s v%s\t\t      © Licensed under MIT™\n", strlen(name) > 3 && strlen(name) < 15 ? name : "Sample", strlen(name) < 9 ? " App" : "", strlen(version) && strlen(version) < 9 ? version : "1.0.0");
#define y79kc3vX br(2);
#define YoWTgNvg repeat_inline(temp1.data(),
#define iJUw4GS5 30);
JKu2q4i4 oIwImahX kFrOUJGr rbIJWvcc f6a6mdFj GMbXMph4 YoWTgNvg iJUw4GS5 
y79kc3vX 
#ifdef CONIO_H
#define VVOlhwM4 clr(peela);
VVOlhwM4 
#endif
#define b5H75QtR join(dt.day,
#define HtGei2eh "Happy %s❤️,\t\t          %s\n\t\t\t\t       ___________________\n",
#define pe333tgk temp2
#define GmpSrAtB temp3
#define a2qVlvyM temp3.data())
#define TX0CbVaZ "  ";
#define eFOUDlxq dt.day,
#define ZNZ9xQvP printf(temp2.data(),
#define EbAtawQr strlen(dt.day)
#define bnP1TAKs 8
#define tKvnuO7i dt.stamp);
kFrOUJGr pe333tgk f6a6mdFj HtGei2eh GmpSrAtB f6a6mdFj TX0CbVaZ ZNZ9xQvP EbAtawQr 
uooD4Din bnP1TAKs S5axP3c7 b5H75QtR a2qVlvyM WLOI7sDO eFOUDlxq tKvnuO7i 
#ifdef CONIO_H
#define q83S3cmW clr(_def);
q83S3cmW 
#endif
#define KvC2Pc8D "^^";
#define by8EWpAk "1.0.1",
#define OZ5bIUSy new_custom_app(char
#define BkLSGLbC temp4
#define AXfvw9qN setMeta(name,
#define ueKgA9gZ appMeta(name,
#define ypVvnDY8 _app_vendor
#define s0vGsp41 new_sample_app()
#define vXBcjsRl setMeta(char
#define R2loXBWR _app_version
#define bowcURcq repeat_inline(temp4.data(),
#define p761mkth "github.com/abbaskhurram255";
#define uBxDSWXU _app_name
#define FWDFUP6Y temp.data());
#define akaxnJi1 setMeta(temp.data(),
#define EiWMNA1S "hindC++",
kFrOUJGr BkLSGLbC f6a6mdFj KvC2Pc8D bowcURcq iJUw4GS5 
y79kc3vX A2JJZmxH mMBojJn9 PSsxshPD S0yYmn5O vXBcjsRl 
OuouvQ2f lUXdPJNo N4utkuxZ dfxsDMlD A2JJZmxH ueKgA9gZ 
m1ZHXnsQ PSsxshPD S0yYmn5O s0vGsp41 dfxsDMlD kFrOUJGr 
QQpxCUSl f6a6mdFj HIWfhxS0 A2JJZmxH akaxnJi1 FWDFUP6Y 
PSsxshPD S0yYmn5O OZ5bIUSy OuouvQ2f lUXdPJNo N4utkuxZ 
dfxsDMlD A2JJZmxH AXfvw9qN m1ZHXnsQ PSsxshPD ARJt0ftF 
kFrOUJGr uBxDSWXU f6a6mdFj EiWMNA1S R2loXBWR f6a6mdFj 
by8EWpAk ypVvnDY8 f6a6mdFj p761mkth

//Obfuscation test

on
    farz lafz barabar puchoLafz("Hi, please enter a word: ");
    kahie "Ap ne daala:" aage lafz aage "<says" aage _app_name aage ">" aage_bas;
off
