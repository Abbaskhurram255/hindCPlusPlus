#include <stdio.h>
#include <string.h>
#include <conio.h>

typedef struct
{
	char *name;
	char *version;
	char *vendor;
} app;

app new_app(char *name, char *version, char *vendor)
{
	app app;
	app.name = name;
	app.version = version;
	app.vendor = vendor;
	return app;
}

int main()
{
	app app;
	app = new_app("My Banking System", "1.0.0", "Khurram Ali");
	printf("\t\t%s\n", app.name);
	printf("\t\tv%s\n", app.version);
	printf("\t\tMade with 💕 by %s\n\n\n", app.vendor);

	float amount,
		balance = 8000.78;
	char isCardInserted[] = "";
	char okayToProceed[] = "";
	char method[] = "",
		 iban[] = "PK36SCBL0000001123456702";

	printf("\t\tPlease insert your card\n\t\t<Y means you've inserted the card,\n\t\tN means you haven't>: ");
	scanf("%s", &isCardInserted);
	if (strcasecmp(isCardInserted, "y") != 0 && strcasecmp(isCardInserted, "yes") != 0)
	{
		printf("\n\n\t\t** Goodbye! **");
		return 0;
	}
	printf("\n\n\t\t** Welcome aboard! **\n");
	while (1)
	{
		printf("\n\t\tPlease enter the amount\n\t\tyou would like transaction for: ");
		scanf("%f", &amount);
		printf("\n\t\tEnter the method\n\t\t<are you here for a\n\t\twithdrawal, or a deposit>: ");
		scanf("%s", &method);
		if ((strcasecmp(method, "d") == 0) || (strcasecmp(method, "deposit") == 0))
		{
			textcolor(YELLOW);
			printf("\n\t\tDepositing PKR %.1f to\n\t\tIBAN number %s\n\t\tWould you like to proceed? ", amount, iban);
			textcolor(WHITE);
			scanf("%s", &okayToProceed);
			if (strcasecmp(okayToProceed, "y") == 0 || strcasecmp(okayToProceed, "yes") == 0)
			{
				printf("\n\t\t__________\n");
				balance += amount;
				textcolor(GREEN);
				printf("\n\t\tDeposit successful!");
				textcolor(WHITE);
				printf("\n\t\tIBAN number: %s", iban);
				textbackground(8);
				printf("\n\t\tNew Balance: PKR %.1f\n\n\n", balance);
				textbackground(0);
				printf("\n\t\t__________\n\n\t\t");
			}
			else
			{
				printf("\n\t\tDeposit of PKR %.1f\n\t\tfrom IBAN %s\n\t\twas cancelled!", amount, iban);
				return 0;
			}
		}
		else if ((strcasecmp(method, "w") == 0) || (strcasecmp(method, "withdraw") == 0) || (strcasecmp(method, "withdrawal") == 0))
		{
			if (amount > balance)
			{
				textcolor(6);
				printf("\n\t\t❗ Insufficient balance!");
				textcolor(WHITE);
				return 0;
			}
			textcolor(YELLOW);
			printf("\n\t\tWithdrawal of PKR %.1f\n\t\tfrom IBAN number %s\n\t\tis ready to be made.\n\t\tAre you sure? ", amount, iban);
			textcolor(WHITE);
			scanf("%s", &okayToProceed);
			if (strcasecmp(okayToProceed, "y") == 0 || strcasecmp(okayToProceed, "yes") == 0)
			{
				printf("\n\t\t__________\n");
				balance -= amount;
				textcolor(GREEN);
				printf("\n\t\tWithdrawal successful!");
				textcolor(WHITE);
				printf("\n\t\tIBAN number: %s", iban);
				textbackground(8);
				printf("\n\t\tNew Balance: PKR %.1f", balance);
				textbackground(0);
				printf("\n\t\t__________\n\n\t\t");
			}
			else
			{
				printf("\n\t\tWithdrawal of PKR %.1f from IBAN\n\t\t%s\n\t\twas cancelled!", amount, iban);
				return 0;
			}
		}
		else
		{
			printf("\n\t\tInvalid method!");
			return 0;
		}
	}
}