#include "/storage/emulated/0/Download/C projs/template.c"

int createFile(char *fname, char *content)
{
    FILE *fptr;
    fptr = fopen(fname, "w");
    if (fprintf(fptr, content))
    {
        printf("\n[Message from HindC FileReader]:\n✔️ File \"%s\" banai ja chuki he, apki farmaish pe.\n", fname);
        fclose(fptr);
        return 1;
    }
    printf("\n[Message from HindC FileReader]:\n❌ Shayad apko is directory me files banane ki permission nahi😔\n");
    fclose(fptr);
    return 0;
}
int newFile(char *fname, char *content)
{
    return createFile(fname, content);
}
int addFile(char *fname, char *content)
{
    return createFile(fname, content);
}
char *readFile(char *fname)
{
    FILE *fptr;
    fptr = fopen(fname, "r");
    if (fptr)
    {
        char content[512];
        char contents[512];
        while (fgets(contents, 512, fptr))
        {
            strcat(content, contents);
        }
        fclose(fptr);
        return contents;
    }
    printf("\n[Message from HindC FileReader]:\n❌ File %s ko read karna na kaam raha. Mana ja sakta he, ya to apke pas file ko read karne ki permission nahi, ya to file ger mujood he.\n", fname);
    fclose(fptr);
    return "\0";
}
char *updateFile(char *fname, char *content)
{
    FILE *fptr;
    fptr = fopen(fname, "a");
    if (fprintf(fptr, content))
    {
        printf("\n[Message from HindC FileReader]:\n✔️Apki request mukammal rahi. As requested, source file me kuch tabdeelia lai ja chuki hen!\n[{Updated File}]: ");
        fclose(fptr);
        return readFile(fname);
    }
    printf("\n[Message from HindC FileReader]:\n❎ Failed! Shayad apko is directory me files banane ki mukammal ijaazat nahi😔\n");
    fclose(fptr);
    return "\0";
}
char *appendFile(char *fname, char *content)
{
    return updateFile(fname, content);
}
int deleteFile(char *fname)
{
    if (remove(fname) == 0)
    {
        printf("\n[Message from HindC FileReader]:\n✔️ File %s ko delete karna kaamyaab raha.\n", fname);
        return 1;
    }
    printf("\n[Message from HindC FileReader]:\n❌ File %s ki deletion na kaam rahi. Ya apke pas file ko delete karne ki permission nahi, ya file ger mojood he.\n", fname);
    return 0;
}
int copyFile(char *src, char *dest)
{
    if (strcasecmp(src, dest) == 0)
    {
        printf("\n[Message from HindC FileReader]:\n⚠️ Cannot replace the source with the destination!\n");
        return 0;
    }
    int c;
    FILE *stream_R;
    FILE *stream_W;
    stream_R = fopen(src, "r");
    if (!stream_R || stream_R == NULL)
    {
        printf("\n[Message from HindC FileReader]:\n❌ Source file ki ger mojoodgi ki soorat, file ko copy/move/rename karna na kaam raha!\n");
        return 0;
    }
    stream_W = fopen(dest, "w");
    if (!stream_W || stream_W == NULL)
    {
        printf("\n[Message from HindC FileReader]:\n❌ File ko copy/move/rename karna na kaam raha!\n");
        fclose(stream_R);
        return 0;
    }
    while ((c = fgetc(stream_R)) != EOF)
    {
        fputc(c, stream_W);
    }
    fclose(stream_R);
    fclose(stream_W);
    return 1;
}
int renameFile(char *oldName, char *newName)
{
    if (copyFile(oldName, newName) && deleteFile(oldName))
    {
        printf("\n[Message from HindC FileReader]:\n ✔️ File renamed successfully\n");
        return 1;
    }
    printf("\n[Message from HindC FileReader]:\n ❌ File failed to rename!\n");
    return 0;
}
int moveFile(char *fname, char *dest)
{
    if (copyFile(fname, dest) && deleteFile(fname))
    {
        printf("\n[Message from HindC FileReader]:\n ✔️ File moved successfully\n");
        return 1;
    }
    printf("\n[Message from HindC FileReader]:\n ❌ File failed to move!\n");
    return 0;
}
int fileBanao(char *fname, char *content)
{
    return newFile(fname, content);
}
int naiFile(char *fname, char *content)
{
    return newFile(fname, content);
}
int fileHatao(char *fname, char *content)
{
    return deleteFile(fname);
}

int main()
{
    App myApp;
    printMeta("HindC\n\t\t\t  by\n\t\t\tKhurram Ali", "1.0");
    Date dt = new_date();
    kaho("Welcome to my app!");
    
    
    printf("%s", readFile("k.txt"));
}