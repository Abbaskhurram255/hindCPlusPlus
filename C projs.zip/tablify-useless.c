#include "stdio.h"

typedef struct {
    char *name;
    char *version;
    char *owner;
} create_app;

int main() {
	create_app new_app = {"Tablifier", "1.0", "Khurram Ali"};
	    printf("\t\t><><><><><><>❤️<><><><><><\n\t\t|        %s\n\t\t\t  v%s\n\t\t\t   by\n\t\t\t%s\n\t\t>💗🌷<><><><><><><><>🌹💘<\n\t\t   =====================\n\t\t|\\/\t\t\t\\/|\n\n\n", new_app.name, new_app.version, new_app.owner);
	int n, i = 1;
	printf("\t\tPlease enter a number: ");
	scanf("%d", &n);
	if (!n || n < 1) n = 1;
	printf("\n\t\t*Tables %d through %d*", i, n);;
	for (; i<=n; i++) {
	    printf("\n\n\t\tTable of %d\n", i);
    	for (int j=1; j<=10; j++) printf("\t\t|| %d × %d = %d ||\n", i, j, i*j);
	}
}