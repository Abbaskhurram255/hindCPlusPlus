#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void itoa(int dataIn, char* bffr){
    int radix = 10;
    int temp_dataIn = dataIn;
    int stringLen=1;

    while ((int)temp_dataIn/radix != 0){
        temp_dataIn = (int)temp_dataIn/radix;
        stringLen++;
    }
    //printf("stringLen = %d\n", stringLen);
    temp_dataIn = dataIn;
    do {
        *(bffr+stringLen-1) = (temp_dataIn%radix)+'0';
        temp_dataIn = (int) temp_dataIn / radix;
    } while(stringLen--); }

const char *cur(int n) {
    char nAsStr[50] = "";
    itoa(n, nAsStr);
    /*
    char *result = strcat("Rs ", nAsStr);
    strcat(result, nAsStr);
    */
    return nAsStr;
}

int main() {
	char *product = "Samsung S10+";
    int n = 9.53e4;
    printf("Cost of the %s:\n%s\n", product, cur(n));
}