#include <stdio.h>
#include <stdbool.h>
bool isSeatBeltOn = false;
void wearSeatBelt() {
	if (!isSeatBeltOn) {
		isSeatBeltOn = true;
		printf("\n\nWearing the seat belt...\n");
	}
}
void checkSeatBelts() {
	printf("%s %d <%s>", "Is seat belt on? ", isSeatBeltOn, isSeatBeltOn ? "true" : "false");
	printf("\n%s %d <%s>", "Is seat belt off? ", !isSeatBeltOn, !isSeatBeltOn ? "true" : "false");
}
int main() {
	printf("%s", "Initially the seat belts are off...\n");
	checkSeatBelts();
	wearSeatBelt();
	checkSeatBelts();
}