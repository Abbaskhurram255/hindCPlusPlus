#include "/storage/emulated/0/Download/C projs/template.c"

int main() {
	App newApp;
	setMeta("HindC\n\t\t\t  by\n\t\t\tKhurram Ali", "1.0");
	Date dt = new_date();
	kaho("%s", dt.stamp);
	
	
}