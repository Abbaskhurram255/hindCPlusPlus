#include <stdio.h>
typedef struct
{
	int released;
	char *name;
	char *author;
} Book;

Book new_book(char *name, char *author, int released)
{
	Book book;
	book.name = name,
	book.author = author,
	book.released = released;
	return book;
}

int main()
{
	Book book1;
	book1 = new_book("The Subtle Art", "Mark Manson", 2007);
	printf("Book name: %s\nBook author: %s\nReleased: %d", book1.name, book1.author, book1.released);
}