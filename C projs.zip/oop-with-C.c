#include <stdio.h>

//open a class
typedef struct {
	int semester, batch;
	char *name, *field, *campus, *section;
} Student;

//create a constructor
Student new_student(char *name, char *field, char *campus, int semester, char *section, int batch) {
	Student student;
	student.name = name,
	student.field = field,
	student.campus = campus,
	student.semester = semester,
	student.section = section,
	student.batch = batch;
	return student;
}

//create a method
Student printData(char *name, char *field, char *campus, int semester, char *section, int batch) {
	Student student = new_student(name, field, campus, semester, section, batch);
	printf("Name: %s\nBatch: %i\nSemester: %i\nSection: %s\nCampus: %s\nField: %s\n<><><><><><><>\n", student.name, student.batch, student.semester, student.section, student.campus, student.field);
	return student;
}

int main()
{
	//Create a new instance of Student
	Student student1;
	
	//call the constructor, or a method
	printData("Khurram Ali", "BSCS", "BBSUL Chakiwara", 1, "A", 16);
}