#include <stdio.h>
int main()
{
	char itemsInStock[][512] = {"Sting 500ml", "Mirinda 2.25L"};
	printf("Welcome to *DrinkFuzz* by Khurram Ali\n\nAvailable items: \n");
	float cost, discount, shippingCharges, totalPay;
	for (int i=0; i < sizeof(itemsInStock)/sizeof(itemsInStock[0]); i++) {
		printf("%d. %s\n", i+1,itemsInStock[i]);
	}
	int choice;
	printf("\nEnter your choice: ");
	scanf("%d", &choice);
	printf("\n");
	if (choice == 1) {
		cost = 120;
		discount = 0;
		shippingCharges = cost * 10 / 100;
		totalPay = (cost-discount)+shippingCharges;
		printf("One %s was served! Here's the bill:\n-----------------\nCost: Rs %.1f\nDiscount: Rs %.1f\nShipping Charge: Rs %.1f\nTotal Payment: PKR %.1f\n-----------------", itemsInStock[0], cost, discount, shippingCharges, totalPay);
	}
	else if (choice == 2) {
		cost = 250;
		discount = cost * 12 / 100;
		//how about a 12 percent discount for the user? That is, a 30 rupee discount
		shippingCharges = cost * 20 / 100;
		//and a ten percent shipping cut
		totalPay = (cost-discount)+shippingCharges;
		printf("One %s was served! Here's the bill:\n-----------------\nCost: Rs %.1f\nDiscount: Rs %.1f\nShipping Charge: Rs %.1f\nTotal Payment: PKR %.1f\n-----------------", itemsInStock[1], cost, discount, shippingCharges, totalPay);
	}
	else {
		printf("Out of stock, apologies!");
	}
}