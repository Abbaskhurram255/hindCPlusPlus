#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

char starRating[] = "";
void starrify(float score)
{
	if (score > 4.5)
		strcpy(starRating, "⭐⭐⭐⭐⭐");
	else if (score > 3.5)
		strcpy(starRating, "⭐⭐⭐⭐");
	else if (score > 2.5)
		strcpy(starRating, "⭐⭐⭐");
	else if (score > 1.5)
		strcpy(starRating, "⭐⭐");
	else strcpy(starRating, "⭐");
}
void criticizeYourTeacher()
{
	char teacher[] = "",
	    comment[] = "";
	float rating;

	while (true)
	{
		printf("\tPlease enter the name of the teacher:\n\t");
		scanf("%s", teacher);
		for (int i=0; teacher[i]; i++) teacher[i] = tolower(teacher[i]);
		if (strcmp(teacher, "maria") == 0)
		{
			strcpy(comment, "The best coach");
			rating = 4.5;
			starrify(rating);
			printf("\t| %s | Rating: %.1f (%s)\n\n", comment, rating, starRating);
		}
		else if (strcmp(teacher, "gulam") == 0) {
			strcpy(comment,"A great coach");
			rating = 4.0;
			starrify(rating);
			printf("\t| %s | Rating: %.1f (%s)\n\n", comment, rating, starRating);
		}
		else if (strcmp(teacher, "sharif") == 0)
		{
			strcpy(comment, "Utne bure bhi nahi");
			rating = 3.7;
			starrify(rating);
			printf("\t| %s | Rating: %.1f (%s)\n\n", comment, rating, starRating);
		}
		else if (strcmp(teacher, "afzal") == 0)
		{
			strcpy(comment, "Utne bhi koi \"afzal\"\n\to khaas nahi");
			rating = .9;
			starrify(rating);
			printf("\t| %s | Rating: %.1f (%s)\n\n", comment, rating, starRating);
		}
		else
		{
			printf("\t| Can't comment on that one.\n\n");
		}
	}
}

int main()
{
	char app_name[] = "Teacher Ranking System",
	app_version[] = "1.0.0";
	printf("\n\n\t        %s     \n\t        |_|_|   v%s   |_|_|\n\n\n", app_name, app_version);
	criticizeYourTeacher();
	return 0;
}