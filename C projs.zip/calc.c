#include <stdio.h>
#include <stdbool.h>

int main()
{
	double numA, numB, result;
	char op;
	while (true)
	{
		printf("\t\t***************************\n");
		printf("\t\t* Enter operand 1: ");
		scanf("%lf", &numA);
		printf("\t\t* Enter operand 2: ");
		scanf("%lf", &numB);
		printf("\t\t* Enter an operator <+-*/>: ");
		scanf("%s", &op);
		switch (op)
		{
		case '+':
			result = numA + numB;
			printf("\t\t* == Result: %.1f\n\t\t* == Rebooting...\n\n", result);
			break;
		case '-':
			result = numA - numB;
			printf("\t\t* == Result: %.1f\n\t\t* == Rebooting...\n\n", result);
			break;
		case '/':
			result = numA / numB;
			printf("\t\t* == Result: %.1f\n\t\t* == Rebooting...\n\n", result);
			break;
		case '*':
			result = numA * numB;
			printf("\t\t* == Result: %.1f\n\t\t* == Rebooting...\n\n", result);
			break;
		default:
			printf("\t\t* == Not a valid operator\n\t\t* == Rebooting...\n\n");
		}
	}
	return 0;
}