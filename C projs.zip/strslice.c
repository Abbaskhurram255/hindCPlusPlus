#include <stdio.h>
#include <string.h>
int main(int argc, char *argv[])
{
	char name[] = "someone";
	printf("Name <first char sliced>: %s\n", &name[1]);
	printf("Name <first two chars sliced>: %s\n", &name[2]);
	printf("Name <last two chars only>: %s\n", &name[strlen(name)-2]);
	printf("Name <last char only>: %s", &name[strlen(name)-1]);
}