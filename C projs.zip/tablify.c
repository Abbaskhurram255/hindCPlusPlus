#include "stdio.h"

typedef struct {
    char *name;
    char *version;
    char *owner;
} create_app;

int main() {
	create_app new_app = {"Tablifier", "1.0", "Khurram Ali"};
	    printf("\t\t><><><><><><>❤️<><><><><><\n\t\t|        %s\n\t\t\t  v%s\n\t\t\t   by\n\t\t\t%s\n\t\t>💗🌷<><><><><><><><>🌹💘<\n\t\t   =====================\n\t\t|\\/\t\t\t\\/|\n\n\n", new_app.name, new_app.version, new_app.owner);
	int n;
	printf("Please enter a number to tablify: ");
	scanf("%d", &n);
	printf("\n\nTable of %d\n", n);
	for (int i=1; i<=10; i++) printf("|| %d × %d = %d ||\n", n, i, n*i);
}