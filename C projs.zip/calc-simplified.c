#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#ifdef __has_include
    #if __has_include (<conio.h>)
        #include <conio.h>
    #endif
#endif

int main()
{
	float numA, numB, reslt;
	char op;
	printf("\n\n");
	#ifdef CONIO_H
	    textcolor(YELLOW);
	#endif
	printf("\t\tK   K\tH    H\tU    U\n");
	printf("\t\tK  K\tH    H\tU    U\n");
	printf("\t\tK K\tH HH H\tU    U\n");
	printf("\t\tK  K\tH    H\tU    U\n");
	printf("\t\tK   K\tH    H\t  U U\n\n");
	printf("\t\t CCCC\t  A\t|\t CCCC\n");
	printf("\t\tC\t A  A\t|\tC\n");
	printf("\t\tC\tA __ A\t|\tC\n");
	printf("\t\tC\tA    A\t|\tC\n");
	printf("\t\t CCCC\tA    A\t______\t CCCC\n\n");
	#ifdef CONIO_H
	    textcolor(3);
	#endif
	printf("\t\tVersion: ");
	#ifdef CONIO_H
	    textcolor(7);
	#endif
	printf("1.0.0\n\n\n");
	#ifdef CONIO_H
	    textcolor(WHITE);
	#endif
	printf("\t\t____ __🌺🌺 ____ ____\n\n");
	while (true)
	{
		printf("\t\t* Enter operand 1: ");
		scanf("%f", &numA);
		if (numA != numA) {
			printf("\t\t❌ Invalid input!");
			break;
		}
		printf("\t\t* Enter operand 2: ");
		scanf("%f", &numB);
		if (numB != numB) {
			printf("\t\t❌ Invalid input!");
			break;
		}
		printf("\t\t∆ Enter an operator: \n\t\t  ");
		scanf("%s", &op);
		switch (op)
		{
		case '+':
			reslt = numA + numB;
			printf("\t\t§ Sum of A(%.1f)\n\t\t  and B(%.1f) = ", numA, numB);
			if (!!reslt) {
				#ifdef CONIO_H
				    textcolor(YELLOW);
				#endif
			} else {
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
			}
			printf("%.1f", reslt);
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '-':
			reslt = numA - numB;
			printf("\t\t§ Left of A(%.1f)\n\t\t  and B(%.1f) = ", numA, numB);
			if (!!reslt) {
				#ifdef CONIO_H
				    textcolor(YELLOW);
				#endif
			}
			else {
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
			}
			printf("%.1f", reslt);
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '*':
		case 'x':
		case '.':
			reslt = numA * numB;
			printf("\t\t§ Product of A(%.1f)\n\t\t  and B(%.1f) = ", numA, numB);
			if (!!reslt) {
				#ifdef CONIO_H
				    textcolor(YELLOW);
				#endif
			}
			else {
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
			}
			printf("%.1f", reslt);
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '/':
			reslt = numA / numB;
			if (reslt != reslt)
				reslt = 0;
			printf("\t\t§ Quotient of A(%.1f)\n\t\t  and B(%.1f) = ", numA, numB);
			if (!!reslt) {
				#ifdef CONIO_H
				    textcolor(YELLOW);
				#endif
			}
			else {
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
			}
			printf("%.1f", reslt);
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '^':
			reslt = pow(numA, numB);
			printf("\t\t§ A(%.1f) to the\n\t\t  power of B(%.1f) =\n\t\t  ", numA, numB);
			#ifdef CONIO_H
			    textcolor(YELLOW);
			#endif
			printf("%.1f", reslt);
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '%':
			if (numB > numA)
			{
				float temp;
				temp = numB;
				numB = numA;
				numA = temp;
			}
			reslt = fabs(remainder(numA, numB));
			printf("\t\t§ A(%.1f) mod \n\t\t  B(%.1f) = ", numA, numB);
			if (reslt == 0)
			{
				#ifdef CONIO_H
				    textcolor(GREEN);
				#endif
				printf("%.1f\n\t\t  <Perfect mod>", reslt);
			}
			else
			{
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
				printf("%.1f\n\t\t  <imperfect mod>", reslt);
			}
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case 'p':
			if (numB > numA) {
				reslt = numA / numB * 100;
				printf("\t\t§ A(%.1f) is\n\t\t  what percent of \n\t\t  B(%.1f) = ", numA, numB);
			}
			else {
				reslt = numA * (numB / 100);
			    printf("\t\t§ B(%.1f%%) of \n\t\t  A(%.1f) = ", numB, numA);
			}
			if (!!reslt)
			{
				#ifdef CONIO_H
				    textcolor(GREEN);
				#endif
				printf("%.1f%s", reslt, numB>numA ? "%" : "");
			}
			else
			{
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
				printf("%.1f", reslt);
			}
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '&':
			reslt = !!numA && !!numB;
			printf("\t\t§ A(%.1f) && \n\t\t  B(%.1f) = ", numA, numB);
			if (!!reslt)
			{
				#ifdef CONIO_H
				    textcolor(GREEN);
				#endif
				printf("%s", "TRUE");
			}
			else
			{
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
				printf("%s", "FALSE");
			}
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '|':
			reslt = !!numA || !!numB;
			printf("\t\t§ A(%.1f) || \n\t\t  B(%.1f) = ", numA, numB);
			if (!!reslt)
			{
				#ifdef CONIO_H
				    textcolor(GREEN);
				#endif
				printf("%s", "TRUE");
			}
			else
			{
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
				printf("%s", "FALSE");
			}
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '>':
			reslt = numA > numB;
			printf("\t\t§ A(%.1f) > \n\t\t  B(%.1f) = ", numA, numB);
			if (!!reslt)
			{
				#ifdef CONIO_H
				    textcolor(GREEN);
				#endif
				printf("%s", "TRUE");
			}
			else
			{
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
				printf("%s", "FALSE");
			}
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '<':
			reslt = numA < numB;
			printf("\t\t§ A(%.1f) < \n\t\t  B(%.1f) = ", numA, numB);
			if (!!reslt)
			{
				#ifdef CONIO_H
				    textcolor(GREEN);
				#endif
				printf("%s", "TRUE");
			}
			else
			{
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
				printf("%s", "FALSE");
			}
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		case '=':
			reslt = numA == numB;
			printf("\t\t§ A(%.1f) == \n\t\t  B(%.1f) = ", numA, numB);
			if (!!reslt)
			{
				#ifdef CONIO_H
				    textcolor(GREEN);
				#endif
				printf("%s", "TRUE");
			}
			else
			{
				#ifdef CONIO_H
				    textcolor(RED);
				#endif
				printf("%s", "FALSE");
			}
			#ifdef CONIO_H
			    textcolor(WHITE);
			#endif
			printf("\n\t\t° Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
			break;
		default:
			printf("\t\t❌ Unsupported Operator\n\t\t~ Rebooting...\n\t\t____ ____ ____ ____ \n\n\n\n");
		}
	}
}