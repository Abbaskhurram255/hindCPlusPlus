#include "/storage/emulated/0/Download/C projs/hindC.c"

typedef struct {
    char *name;
    char *version;
} App;

App new_app(char *name, char *version) {
    App my_app;
    my_app.name = name;
    my_app.version = version;
    return my_app;
}

App appMeta(char *name, char *version) {
    App my_app = new_app(name, version);
    Date dt = new_date();
    #ifdef CONIO_H
        recognize_colors();
    #endif
    kaho("\t\t><><><><><><>❤️<><><><><><\n\t\t|        HindC\n\t\t\t   by\n\t\t\t Khurram Ali\n\t\t>💗🌷<><><><><><><><>🌹💘<\n\t\t   =====================\n\t\t|\\/\t\t\t\\/|\n\n");
    kaho("%s%s v%s\t\t      © Licensed under MIT™\n", len(name) > 3 && len(name) < 15 ? name : "Sample", len(name) < 9 ? " App" : "", len(version) && len(version) < 9 ? version : "1.0.0");
	repeat_inline("<<", 30);
	br(2);
	#ifdef CONIO_H
        clr(peela);
    #endif
	kaho("Happy %s❤️,\t\t      %s\n\t\t\t\t       ___________________\n", len(dt.day) < 8 ? join(dt.day, "  ") : dt.day, dt.stamp);
    #ifdef CONIO_H
        clr(_def);
    #endif
	repeat_inline("^^", 30);
	br(2);
    return my_app;
}
App setMeta(char *name, char *version) {
    return appMeta(name, version);
}
App new_sample_app() {
    return setMeta("", "");
}
App new_custom_app(char *name, char *version) {
    return setMeta(name, version);
}

/*
int main() {
    new_sample_app();
}
*/