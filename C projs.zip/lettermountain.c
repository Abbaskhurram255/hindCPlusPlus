#include "stdio.h"

int main() {
    char chr = 'A';
    for (int i=0; i<=10; i++) {
        for (int j=15; j>i; j--) {
            printf(" ");
        }
        for (int k=0; k<=i; k++) printf("%c ", (chr+k));
        printf("\n");
    }
}