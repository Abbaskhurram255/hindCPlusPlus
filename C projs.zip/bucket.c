#include <stdio.h>
#include <time.h>

int main()
{
   time_t ds = time(NULL);
   struct tm tmn;
   localtime_r(&ds, &tmn);
   char timestamp[100];
   strftime(timestamp, sizeof(timestamp), "%Y-%d-%m_2-13-PM_SUN", &tmn);
	char payment_method[] = "Sindhbank wallet";
	char bucketed_items[] = {"Head & Shoulders 400ml", "HairCare's Hairconditioner", "Jumbo Oatmeals", "1KG of Powered Milk", "Tampons"};
	double payment_amount = 1759.54;
	double amount_paid = 0;
	char client_id[] = "B91E0D";
	printf("----- Some new client walks into the supermarket stumbling through stuff...\n* They are ready to make their order\nClient ID: %s\nTimestamp: %s\nSelected Payment Method: %s\nPaid yet: %s\n\nBucket overview: %s, among others.", client_id, timestamp, payment_method, amount_paid == payment_amount && !(amount_paid < payment_amount) ? "Payment Success" : "Processing transaction...", bucketed_items);
	
}