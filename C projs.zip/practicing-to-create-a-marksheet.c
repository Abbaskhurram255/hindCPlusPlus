#include <stdio.h>
int main(int argc, char *argv[])
{
	float sum, percentage, maxMarks = 600;
	int marksInEng = 83,
	  marksInCalc = 53,
	  marksInICT = 64,
	  marksInDS = 83,
	  marksInPhysX = 59,
	  marksInPF = 86;
	  sum = marksInEng + marksInCalc + marksInICT + marksInDS + marksInPhysX + marksInPF;
	  percentage = sum / maxMarks * 100;
	  char name[] = "Khurram Ali",
	    section[] = "A";
	  int rollno = 44,
	    batch = 16,
	    semester = 1;
	  printf("Name: %s\nSection: %s\nRollno: %d\nBatch: %d\nSemester: %d\n--------------------\nMarks Obt:\n%.1f out of %.1f\nPercentage: %.1f%%\n•••••\nEnglish: %d\nCalculus: %d\nICT: %d\nDiscrete: %d\nPhysics: %d\nProgramming F. : %d\n•••••\n--------------------", name, section, rollno, batch, semester, sum, maxMarks, percentage, marksInEng, marksInCalc, marksInICT, marksInDS, marksInPhysX, marksInPF);
}