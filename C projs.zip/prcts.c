#include <stdio.h>

int main(int argc, char *argv[])
{
	int pin, correctPin = 0000;
	char method;
	float amount, balance = 7500.4;
	printf("Please enter your pin: \n");
	scanf("%d", &pin);
	if (pin != correctPin) {
		printf("😡Abe o, daket!");
		return 0;
		//exit!
	}
	printf("Please enter the method\n{are you here for a <w>ithdrawal,\nor a <d>eposit,\nor just to know your current <b>alance?}: \n");
	scanf("%s", &method);
	printf("\n");
	if (method == 'd') {
		printf("Please enter the amount you would like to deposit: ");
	    scanf("%f", &amount);
		balance += amount;
		printf("Deposit of PKR %.1f was successful!\nNew balance: Rs %.1f", amount, balance);
	}
	else if (method == 'w') {
		printf("Please enter the amount you would like to withdraw: ");
	    scanf("%f", &amount);
		if (amount > balance) {
			printf("Withdrawal failed.\nNot enough balance for this withdrawal!\nCurrent balance: Rs %.1f", balance);
			return 0;
		}
		balance -= amount;
		printf("Withdrawal successful!\n New balance: Rs %.1f", balance);
	}
	else if (method == 'b') {
		printf("*Balance*: %.1f", balance);
	}
	else {
		printf("\nInvalid method!");
		return 0;
	}
}