#include "/storage/emulated/0/Download/C projs/template.c"

char *greet(char *period, int hh)
{
    char *greeting = "";
    if (he(period, "pm"))
    {
        if (hh >= 9)
            greeting = "Good night";
        else if (hh >= 4)
            greeting = "Good evening";
        else
            greeting = "Good afternoon";
    }
    else
    {
        if (hh >= 5)
            greeting = "Good morning";
        else
            greeting = "Good start of an early morning!";
    }
    return greeting;
}

typedef struct
{
    char *day, *date, *time, *mo, *greet, stamp[100];
    int hh, mm, yy;
} Date;

Date new_date()
{
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    char s[64];
    size_t ret = strftime(s, sizeof(s), "%c", tm);
    assert(ret);
    char *ampm = "am",
         *day = slice(s, 0, 3),
         *month = slice(s, 4, 7),
         *date = slice(s, 8, 10),
         *year = &s[20],
         *tim = slice(s, 11, 16),
         hh = atoi(slice(time, 0, 2)),
         mm = atoi(slice(time, 3, 5));

    if (he(month, "jan"))
        strmilao(month, "uary");
    else if (he(month, "feb"))
        strmilao(month, "ruary");
    else if (he(month, "mar"))
        strmilao(month, "ch");
    else if (he(month, "apr"))
        strmilao(month, "il");
    else if (he(month, "may"))
        strmilao(month, "");
    else if (he(month, "jun"))
        strmilao(month, "e");
    else if (he(month, "jul"))
        strmilao(month, "y");
    else if (he(month, "aug"))
        strmilao(month, "ust");
    else if (he(month, "sep"))
        strmilao(month, "tember");
    else if (he(month, "oct"))
        strmilao(month, "ober");
    else if (he(month, "nov"))
        strmilao(month, "ember");
    else if (he(month, "dec"))
        strmilao(month, "ember");

    if (hh >= 12)
    {
        ampm = "pm";
        hh -= 12;
    }
    if (hh == 0)
        hh = 12;

    nai(date, connect(connect(connect(connect(month, " "), date), " "), year));
    join(join(join(date, " ("), day), ")");
    time_t ds = time(NULL);
    struct tm tmn;
    localtime_r(&ds, &tmn);
    char timestamp[100];
    strftime(timestamp, sizeof(timestamp), "%Y-%d-%m", &tmn);
    

    Date this;
    this.day = day;
    this.date = date;
    this.mo = slice(month, 0, 5);
    this.yy = atoi(year);
    this.time = merge(merge(slice(s, 11, 16), " "), ampm);
    this.time = merge(slice(this.time, 0, strlen(this.time) - 3), ampm);
    this.hh = hh;
    this.mm = mm;
    this.greet = greet(ampm, hh);
    strcpy(this.stamp, timestamp);
    merge(merge(merge(merge(this.stamp, "-"), day), "-"), this.time);
    strcpy(this.stamp, upper(replace(this.stamp, ":", "-")));
    return this;
}
char *today()
{
    Date dt = new_date();
    return dt.date;
}
char *tareekh()
{
    return today();
}
char *din()
{
    char *day = new_date().day;
    if (he(day, "sun") || he(day, "mon") || he(day, "fri"))
        makeone(day, "day");
    if (he(day, "tue"))
        makeone(day, "sday");
    if (he(day, "wed"))
        makeone(day, "nesday");
    else if (he(day, "thu"))
        makeone(day, "rsday");
    else
        makeone(day, "urday");
    return day;
}

int main(){
    App myApp;
    setMeta("App Name", "1.0");
    kaho("Welcome to my app!");
    
    Date dt = new_date();
    char *time = new_date().time;
    printf("Time: %s\n", time);
    printf("Date: %s\nTimegreet: %s\nDin: %s", dt.date, dt.greet, din());
}