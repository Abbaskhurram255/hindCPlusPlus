#include <stdio.h>
#include <string.h>

char grade[] = "";
void gradify(float score) {
	if (score >= 90) strcpy(grade, "A1");
	else if (score >= 80) strcpy(grade, "A-plus");
	else if (score >= 70) strcpy(grade, "A");
	else if (score >= 60) strcpy(grade, "B");
	else if (score >= 50) strcpy(grade, "C");
	else if (score >= 40) strcpy(grade, "D");
	else if (score >= 33) strcpy(grade, "E");
	else strcpy(grade, "F");
}

int main(int argc, char *argv[])
{
	float pct;
	printf("\n\nEnter the percentage you got: ");
	scanf("%f", &pct);
	gradify(pct);
	printf("Grade: %s", grade);
}