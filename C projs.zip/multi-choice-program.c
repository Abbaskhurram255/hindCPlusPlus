#include <stdio.h>
#include <string.h>
#include <conio.h>

void br(n) {
	for (int i=0; i<n; i++) printf("\n");
}
void tb(n) {
	for (int i=0; i<n; i++) printf("\t");
}
void clr(int c) {
	textcolor(c);
}
int main(int argc, char *argv[])
{
	br(1);
	printf("\t\t    *   ---- ---- ----  *");
	br(2);
	printf("\t\t    Multi-Choice Program\n\t\t    __      v1.0       __");
	printf("\n\t\t    ||                 ||");
	printf("\n\t\t    \\\\                 //");
	printf("\n\t\t    ____             ____");
	printf("\n\t\t        ||         ||");
	printf("\n\t\t          __     __");
	printf("\n\t\t            || ||");
	printf("\n\t\t              _         ");
	br(2);
	int green = GREEN, red = RED, def = WHITE;
	
	char choice;
	char topic[] = "C Language";
	char questions[32][512] = {"Who built C?", "When did they build it?", "Where did they built it?"};
	char choices[][256][512] = {{"Jeff Bezzos", "Mark Zuckerberg", "Steve Jobs", "Dennis Ritchie"}, {"1940", "1954", "1972", "2001"}, {"At Michigan University", "At Belle Laboratories", "At Microsoft", "At College of Hamilton"}};
	printf("\t\t\t\t   <|Subject: %s|>", topic);
	br(3);
	printf("\tQuestion 1: %s\n", questions[0]);
	printf("\t\t    a: %s\tb: %s\n\t\t    c: %s\td: %s\n\tAnswer: ", choices[0][0], choices[0][1], choices[0][2], choices[0][3]);
	scanf("%c", &choice);
	choice = tolower(choice);
	if (choice == 'd') {
		clr(green);
		printf("\t\t    ✔️ Correct!");
		clr(def);
		br(2);
	}
	else {
		clr(red);
		printf("\t\t    ❌ Not a valid choice!");
		clr(def);
		br(2);
	}
	printf("\tQuestion 2: %s\n", questions[1]);
	printf("\t\t    a: %s\tb: %s\n\t\t    c: %s\td: %s\n\tAnswer: ", choices[1][0], choices[1][1], choices[1][2], choices[1][3]);
	scanf(" %c", &choice);
	choice = tolower(choice);
	if (choice == 'c') {
		clr(green);
		printf("\t\t    ✔️ Correct!");
		clr(def);
		br(2);
	}
	else {
		clr(red);
		printf("\t\t    ❌ Not a valid choice!");
		clr(def);
		br(2);
	}
	printf("\tQuestion 3: %s\n", questions[2]);
	printf("\t\t    a: %s\n\t\t    b: %s\n\t\t    c: %s\n\t\t    d: %s\n\tAnswer: ", choices[2][0], choices[2][1], choices[2][2], choices[2][3]);
	scanf(" %c", &choice);
	choice = tolower(choice);
	if (choice == 'b') {
		clr(green);
		printf("\t\t    ✔️ Correct!");
		clr(def);
		br(2);
	}
	else {
		clr(red);
		printf("\t\t    ❌ Not a valid choice!");
		clr(def);
		br(2);
	}
}