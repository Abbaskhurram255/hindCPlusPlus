#include <stdio.h>
int main()
{
	int dayOfWeek = 1;
	char day[][512] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
	switch (dayOfWeek) {
		case 0:
		    printf("It's %s", day[0]);
		    break;
		case 1:
		    printf("It's %s", day[1]);
		    break;
		case 2:
		    printf("It's %s", day[2]);
		    break;
		case 3:
		    printf("It's %s", day[3]);
		    break;
		case 4:
		    printf("It's %s", day[4]);
		    break;
		case 5:
		    printf("It's %s", day[5]);
		    break;
		default:
		    printf("It's %s", day[6]);
	}
}