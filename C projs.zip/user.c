#include <stdio.h>
typedef struct {
	int age;
	char* name;
} user;
user new_user(char* name, int age) {
	user user;
	user.name = name;
	user.age = age;
	return user;
}
int main(int argc, char *argv[])
{
	user user1;
	user1 = new_user("Sunny", 24);
	printf("User: %s\nAge: %d", user1.name, user1.age);
}