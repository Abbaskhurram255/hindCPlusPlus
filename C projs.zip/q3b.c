#include <stdio.h>

int main() {
    int sum = 0;
    int i = 0;
    int nums[] = {1, 2, 3, 4, 5};
    int sizeofArray = sizeof(nums)/sizeof(nums[0]);
    while (i<sizeofArray) {
        sum += nums[i];
        i++;
    }
    printf("1+2+3+4+5 = %i", sum);
}