#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

char grade[] = "";
void gradify(float score) {
	if (score >= 90) strcpy(grade, "A1");
	else if (score >= 80) strcpy(grade, "A-plus");
	else if (score >= 70) strcpy(grade, "A");
	else if (score >= 60) strcpy(grade, "B");
	else if (score >= 50) strcpy(grade, "C");
	else if (score >= 40) strcpy(grade, "D");
	else if (score >= 33) strcpy(grade, "E");
	else strcpy(grade, "F");
}
int main()
{
	int rollno = rand()%9999;
	float myMarksInEnglish = 66, myMarksInCalculus = 70, myMarksInPhysics = 71.4, myMarksInDiscreteStructures = 96.2, myMarksInICT = 78.2;
	float sum = myMarksInEnglish + myMarksInCalculus + myMarksInPhysics + myMarksInDiscreteStructures + myMarksInICT;
	float requiredToPass = 500;
	float percentage = sum / requiredToPass * 100;
	for (int i = 0; i < 45; i++)
		printf("=");
	printf("\n ==     Subject | Marks Obtained |  Max    ==");
	printf("\n");
	printf("\n = \tEnglish         %.1f\t    100     =", myMarksInEnglish);
	printf("\n = \tCalculus        %.1f\t    100     =", myMarksInCalculus);
	printf("\n = \tPhysics         %.1f\t    100     =", myMarksInPhysics);
	printf("\n = \tDisc. Strcts.   %.1f\t    100     =", myMarksInDiscreteStructures);
	printf("\n ==\tICT             %.1f\t    100    ==\n ===\t\t\t\t\t  ===", myMarksInICT);
	printf("\n ==");
	for (int i = 0; i < 42; i++)
		printf("=");
	printf("\n\n");
	for (int i = 0; i < 45; i++)
		printf("^");
	printf("\n");
	for (int i = 0; i < 23; i++)
		printf("= ");
	gradify(percentage);
	printf("\n==\t\t\t\t\t    =\n== \tObtained:\t%.1f out of %.0f    =", sum, requiredToPass);
	printf("\n== \tPercentage: \t%.1f%%\t\t    =", percentage);
	printf("\n== \tGrade: \t\t%s\t\t    =", grade);
	printf("\n== \tRoll no: \t%i\t    \t    =\n==\t\t\t\t\t    =\n", rollno);
	for (int i = 0; i < 23; i++)
		printf("= ");
	printf("\n");
	for (int i = 0; i < 45; i++)
	    printf("^");
}