#include <stdio.h>
int dec2bin(int n)
{
	if (!n)
	{
		printf("%d", 0);
	}
	int i = 0;
	int bin[32];
	for (; n;)
	{
		bin[i++] = n % 2;
		n /= 2;
	}
	for (int j = i-1; j >= 0; j--)
		printf("%d", bin[j]);
	printf("\n");
}
int main()
{
	//printf("\t\tDECIMAL TO BINARY FROM 0 THRU 100");
	printf("\t****   *****  ***  *****  ****   ***   **   *\n");
	printf("\t*   *  *     *         *  *   *   *    * *  *\n");
	printf("\t*   *  ****  *     *****  *****   *    *  * *\n");
	printf("\t*   *  *     *     *      *   *   *    *   **\n");
	printf("\t****   *****  ***  *****  ****  *****  *    *\n\n");
	printf("\t\t\t****  *   *\n");
	printf("\t\t\t*   *  * *\n");
	printf("\t\t\t*****   *\n");
	printf("\t\t\t*   *   *\n");
	printf("\t\t\t****    *\n\n");
	
	printf("\t*   *  *   *  *   *  ****   ****     *     *     *\n");
	printf("\t*  *   *   *  *   *  *   *  *   *   * *    *    **\n");
	printf("\t* *    *---*  *   *  ****   ****   *****   **  * *\n");
	printf("\t*  *   *   *  *   *  *  *   *  *   *    *  * * * *\n");
	printf("\t*   *  *   *   ***   *   *  *   *  *    *  *  *  *\n\n");
	for (int n = 0; n <= 1000; ) {
		printf("%i: ", n);
		dec2bin(n++);
	}
}