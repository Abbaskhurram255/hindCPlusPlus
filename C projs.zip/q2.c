#include <stdio.h>

int main() {
    int i=2;
    while (i<=20) {
        printf("%d\n", i);
        i++;
    }
}