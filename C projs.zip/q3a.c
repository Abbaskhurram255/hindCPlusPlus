#include <stdio.h>

int main() {
    int iterations = 0;
    int needed = 1+2+3+4+5;
    while (iterations<needed) {
        iterations++;
    }
    printf("1+2+3+4+5 = %i", iterations);
}