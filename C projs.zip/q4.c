#include <stdio.h>

int main() {
    int n=3;
    printf("Table of %d\n", n);
    int i=1;
    while (i<=10) {
        printf("| %d × %d = %d |\n", n, i, i*n);
        i++;
    }
}